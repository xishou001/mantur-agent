// Distribution adapter: public registry metadata only; no business HTTP, tokens or orchestration.
import assert from 'node:assert/strict';
import { existsSync, lstatSync, mkdirSync, readFileSync, realpathSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { dirname, delimiter, isAbsolute, join, parse, resolve } from 'node:path';
import { homedir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { spawn } from 'node:child_process';

export const isSkillId = value => typeof value === 'string' && value.length <= 64 && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value);
export function hostSource(value) {
  assert(typeof value === 'string' && !/[\x00-\x1f\x7f-\x9f]/.test(value), 'Invalid host source');
  const source = value.trim().toLowerCase();
  assert(source.length <= 64 && /^[a-z0-9]+(?:[._-][a-z0-9]+)*$/.test(source), 'Invalid host source');
  return source === 'claude' ? 'claude-code' : source;
}

// Package-private opt-in: old profiles retain their original unclassified entry.
export function registrationEntryCode(product, channel) {
  assert(isSkillId(product) && ['standalone', 'connector'].includes(channel), 'Invalid registration product/channel');
  const code = `${product}-${channel === 'connector' ? 'connector' : 'skill'}`;
  assert(isSkillId(code), 'Registration entry code exceeds 64 characters');
  return code;
}
function registrationBusinessCode(p) {
  if (p.registrationBusinessCode !== undefined) {
    assert(p.schemaVersion === 2 && p.registrationBusinessCode === registrationEntryCode(p.product, p.channel), 'Invalid registration entry code');
  }
  return p.registrationBusinessCode ?? p.product;
}
export function registrationContext(p, source) {
  const businessCode = registrationBusinessCode(p);
  const from = p.channel === 'connector' ? 'workbuddy' : hostSource(source ?? 'unknown');
  const url = new URL('/login', p.baseUrl);
  url.searchParams.set('from', from); url.searchParams.set('businessCode', businessCode);
  return { from, businessCode, registrationUrl: url.href };
}

// Compare stable SemVer numerically; prereleases never satisfy the supported floor.
export function isSupportedCliVersion(version, minimum) {
  const stable = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
  const actual = typeof version === 'string' && version.match(stable);
  const floor = typeof minimum === 'string' && minimum.match(stable);
  if (!actual || !floor) return false;
  for (let i = 1; i <= 3; i++) {
    if (BigInt(actual[i]) !== BigInt(floor[i])) return BigInt(actual[i]) > BigInt(floor[i]);
  }
  return true;
}

export function validateProfile(p) {
  assert([1, 2].includes(p?.schemaVersion) && ['connector', 'standalone'].includes(p.channel), 'Invalid access profile');
  if (p.schemaVersion === 2) {
    assert(isSkillId(p.businessCode) && p.skillCode === p.product && /^\d+\.\d+\.\d+$/.test(p.skillVersion), 'Invalid attribution metadata');
    assert(['generic', 'mantur', 'standalone', 'connector'].includes(p.distributionTarget)
      && p.accessMode === (p.channel === 'connector' ? 'connector' : 'existing-cli'), 'Invalid attribution target');
    assert(isSupportedCliVersion(p.cliMinimumVersion, '1.2.8'), 'Attribution profile requires the released CLI with attribution support');
  }
  assert(isSkillId(p.product), 'Invalid product');
  registrationBusinessCode(p); // Validate optional entry metadata, including legacy profiles.
  assert(p.baseUrl === 'https://hub.mantur.ai' && /^\d+\.\d+\.\d+$/.test(p.cliVersion)
    && /^\d+\.\d+\.\d+$/.test(p.cliMinimumVersion)
    && isSupportedCliVersion(p.cliVersion, p.cliMinimumVersion), 'Unsupported site/CLI contract');
  assert(p.cliInstallTag === undefined || p.cliInstallTag === 'latest', 'Unsupported CLI installation channel');
  if (p.channel === 'connector') {
    assert(typeof p.configDir === 'string' && /^\.manturhub-workbuddy(?:-[a-z0-9-]+)?$/.test(p.configDir), 'Unsafe connector config directory');
  } else assert(p.configDir === undefined, 'Standalone uses the existing CLI config, not a product credential directory');
  assert(Array.isArray(p.operators) && p.operators.length && p.operators.every(x => /^op\.[a-z0-9]+(?:[.-][a-z0-9]+)*$/.test(x)), 'Invalid operators');
  assert(p.operators.includes(p.probeOperator), 'Invalid authorization probe');
  return p;
}

function noLinks(path) {
  const absolute = resolve(path);
  let cursor = parse(absolute).root;
  for (const part of absolute.slice(cursor.length).split(/[\\/]/).filter(Boolean)) {
    cursor = join(cursor, part);
    if (existsSync(cursor)) assert(!lstatSync(cursor).isSymbolicLink(), 'Symbolic links are not allowed in managed directories');
  }
}

// Optional absolute paths pin the environment discovered by check; never pass credentials.
export function parseAccessArgs(argv) {
  const binding = {};
  let index = 0, source, businessCode;
  while (['--existing-cli', '--config-dir', '--source', '--business-code'].includes(argv[index])
    || /^--(?:source|business-code)=/.test(argv[index] ?? '')) {
    const token = argv[index], nameToken = token.split('=')[0];
    if (['--source', '--business-code'].includes(nameToken)) {
      const equal = token.indexOf('='), value = equal === -1 ? argv[index + 1] : token.slice(equal + 1);
      if (nameToken === '--business-code') {
        assert(businessCode === undefined, 'Business code cannot be repeated');
        assert(isSkillId(value), 'Invalid business code'); businessCode = value;
        index += equal === -1 ? 2 : 1; continue;
      }
      assert(source === undefined, 'Host source cannot be repeated');
      source = hostSource(value); index += equal === -1 ? 2 : 1; continue;
    }
    const name = argv[index] === '--existing-cli' ? 'cliPath' : 'configDir';
    assert(!Object.hasOwn(binding, name) && typeof argv[index + 1] === 'string'
      && isAbsolute(argv[index + 1]), 'Reuse requires unique absolute CLI and config directory paths');
    binding[name] = argv[index + 1]; index += 2;
  }
  assert(Boolean(binding.cliPath) === Boolean(binding.configDir), 'Provide both --existing-cli and --config-dir');
  return { binding: binding.cliPath ? binding : undefined, ...(source === undefined ? {} : { source }),
    ...(businessCode === undefined ? {} : { businessCode }), args: argv.slice(index) };
}

// WorkBuddy's ${HOME}/... expansion can mix separators on Windows. Only paths normalize.
export function assertConnectorEnvironment(env, fixed, resolvePath = resolve) {
  for (const [key, value] of Object.entries(fixed)) {
    if (key === 'MANTURHUB_BUSINESS_CODE') continue; // Per invocation; immutable package/identity fields remain checked.
    assert(env[key], `Missing connector environment: ${key}`);
    const matches = key === 'MANTURHUB_CONFIG_DIR'
      ? resolvePath(env[key]) === resolvePath(value) : env[key] === value;
    assert(matches, `Conflicting channel environment: ${key}`);
  }
}

export function context(profile, env = process.env, home = homedir(), binding, source, businessCode) {
  const p = validateProfile(profile);
  assert(businessCode === undefined || p.schemaVersion === 2, 'Business context requires attribution profile v2');
  assert(!env.MANTURHUB_KEY, 'External MANTURHUB_KEY is not allowed; do not print or copy it');
  if (binding) {
    assert(p.channel === 'standalone', 'Connector cannot reuse an external CLI or identity');
    assert(typeof binding.cliPath === 'string' && isAbsolute(binding.cliPath)
      && typeof binding.configDir === 'string' && isAbsolute(binding.configDir), 'Reuse requires absolute paths');
  }
  const connector = p.channel === 'connector';
  if (source !== undefined) source = hostSource(source);
  if (connector) assert(source === undefined || source === 'workbuddy', 'Connector host source must be workbuddy');
  const selectedDir = binding?.configDir || env.MANTURHUB_CONFIG_DIR || join(home, '.manturhub');
  const configDir = connector ? resolve(home, p.configDir) : resolve(selectedDir);
  if (!connector) assert(!configDir.split(/[\\/]/).some(s => /^\.manturhub-workbuddy(?:-|$)/.test(s)),
    'CONNECTOR_IDENTITY: use the connector host, not the standalone Skill');
  noLinks(configDir);
  if (env.MANTURHUB_CONFIG_DIR) assert(resolve(env.MANTURHUB_CONFIG_DIR) === configDir, 'Conflicting channel environment: MANTURHUB_CONFIG_DIR');
  if (env.MANTURHUB_BASE) assert(env.MANTURHUB_BASE.replace(/\/$/, '') === p.baseUrl, 'Conflicting channel environment: MANTURHUB_BASE');
  if (env.MANTURHUB_IDENTITY_MODE) assert(env.MANTURHUB_IDENTITY_MODE === 'standalone', 'Conflicting channel environment: MANTURHUB_IDENTITY_MODE');
  const fixed = { MANTURHUB_CONFIG_DIR: configDir, MANTURHUB_IDENTITY_MODE: 'standalone',
    MANTURHUB_DISABLE_UPDATE_CHECK: '1', MANTURHUB_DISABLE_SKILL_UPDATE_CHECK: '1' };
  if (p.schemaVersion === 2) Object.assign(fixed, {
    MANTURHUB_BUSINESS_CODE: businessCode ?? env.MANTURHUB_BUSINESS_CODE ?? p.businessCode, MANTURHUB_SKILL_CODE: p.skillCode,
    MANTURHUB_SKILL_VERSION: p.skillVersion, MANTURHUB_DISTRIBUTION_TARGET: p.distributionTarget,
    MANTURHUB_ACCESS_MODE: p.accessMode,
    ...(connector ? { MANTURHUB_SOURCE: 'workbuddy' }
      : source !== undefined || env.MANTURHUB_SOURCE !== undefined
        ? { MANTURHUB_SOURCE: hostSource(source ?? env.MANTURHUB_SOURCE) } : {}),
  });
  if (p.schemaVersion === 2) assert(isSkillId(fixed.MANTURHUB_BUSINESS_CODE), 'Invalid business code');
  if (p.schemaVersion === 2) for (const [key, value] of Object.entries(fixed)) {
    if (key.startsWith('MANTURHUB_') && !['MANTURHUB_BUSINESS_CODE', 'MANTURHUB_CONFIG_DIR', 'MANTURHUB_IDENTITY_MODE', 'MANTURHUB_DISABLE_UPDATE_CHECK', 'MANTURHUB_DISABLE_SKILL_UPDATE_CHECK'].includes(key))
      assert((key === 'MANTURHUB_SOURCE' && !connector && source !== undefined)
        || env[key] === undefined || env[key] === value, `Conflicting product attribution: ${key}`);
  }
  if (connector) {
    fixed.MANTURHUB_BASE = p.baseUrl;
    assertConnectorEnvironment(env, fixed);
  }
  // Do not hide a stored nonproduction base by overriding it before auth status.
  return { env: { ...env, ...fixed }, configDir, existingCli: binding?.cliPath };
}

// No shell invocation, including Windows: execute the package's JS entry with the current Node.
export function packageEntry(folder, minimumVersion) {
  const meta = JSON.parse(readFileSync(join(folder, 'package.json'), 'utf8'));
  assert(meta.name === '@manturhub/cli' && isSupportedCliVersion(meta.version, minimumVersion)
    && meta.bin?.manturhub === 'bin/cli.js', `CLI version or executable mismatch: requires stable CLI >=${minimumVersion}`);
  const entry = join(folder, 'bin/cli.js');
  assert(existsSync(entry), 'CLI executable missing');
  return entry;
}

const installedVersion = entry => JSON.parse(readFileSync(resolve(dirname(entry), '../package.json'), 'utf8')).version;

export function locateCli(p, ctx, platform = process.platform) {
  const fromPath = path => {
    const actual = realpathSync(path);
    const folder = platform === 'win32' && !actual.endsWith('/bin/cli.js') && !actual.endsWith('\\bin\\cli.js')
      ? join(dirname(actual), 'node_modules/@manturhub/cli') : resolve(dirname(actual), '..');
    return packageEntry(folder, p.cliMinimumVersion);
  };
  if (ctx.existingCli) {
    assert(p.channel === 'standalone', 'Connector cannot reuse an external CLI or identity');
    assert(existsSync(ctx.existingCli), 'EXISTING_CLI_MISSING: repair the selected CLI; no fallback was attempted');
    return fromPath(ctx.existingCli);
  }
  for (const dir of (ctx.env.PATH || '').split(platform === 'win32' ? ';' : delimiter).filter(Boolean)) {
    const shim = join(dir, platform === 'win32' ? 'manturhub.cmd' : 'manturhub');
    if (!lstatSync(shim, { throwIfNoEntry: false })) continue;
    assert(isAbsolute(dir), 'CLI_PATH_AMBIGUOUS: use an absolute PATH entry or explicitly select the CLI');
    return fromPath(shim); // First PATH entry wins; never silently seek another identity/runtime.
  }
  throw new Error(p.channel === 'connector' ? 'CONNECTOR_CLI_MISSING: reinitialize the connector in WorkBuddy'
    : `CLI_NOT_INSTALLED: install @manturhub/cli@${p.cliInstallTag ?? p.cliVersion} in this command environment, then rerun check; see references/channel.md`);
}

// Public npm metadata only. This function never installs software or touches CLI credentials.
export async function checkCliUpdate(p, currentVersion, { home = homedir(), env = process.env,
  fetchMetadata = globalThis.fetch, now = Date.now() } = {}) {
  if (p.cliInstallTag !== 'latest') return { status: 'PINNED_PROFILE' };
  if (env.MANTURHUB_DISABLE_SKILL_CLI_UPDATE_CHECK === '1') return { status: 'DISABLED' };
  const directory = join(home, '.cache', 'manturhub'), file = join(directory, 'cli-latest.json');
  const registry = 'https://registry.npmjs.org/@manturhub/cli/latest';
  const validVersion = value => typeof value === 'string' && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(value);
  let cache;
  try {
    noLinks(file);
    const saved = JSON.parse(readFileSync(file, 'utf8'));
    if (saved.registry === registry && Number.isSafeInteger(saved.checkedAt) && saved.checkedAt <= now
      && now - saved.checkedAt < (saved.failed ? 5 * 60_000 : 24 * 60 * 60_000)
      && (saved.failed === true || validVersion(saved.latestVersion))) cache = saved;
  } catch { /* Missing or unusable advisory cache never blocks the CLI. */ }
  if (!cache) {
    try {
      const response = await fetchMetadata(registry, { signal: AbortSignal.timeout(2500), redirect: 'error',
        headers: { Accept: 'application/json' } });
      assert(response.ok, 'Registry unavailable');
      const data = await response.json();
      assert(data.name === '@manturhub/cli' && validVersion(data.version), 'Invalid stable release metadata');
      cache = { registry, checkedAt: now, latestVersion: data.version,
        ...(typeof data.engines?.node === 'string' ? { nodeRequirement: data.engines.node.slice(0, 100) } : {}) };
    } catch { cache = { registry, checkedAt: now, failed: true }; }
    let temporary;
    try {
      noLinks(file); mkdirSync(directory, { recursive: true, mode: 0o700 });
      temporary = join(directory, '.cli-latest-' + randomUUID());
      writeFileSync(temporary, JSON.stringify(cache), { flag: 'wx', mode: 0o600 }); renameSync(temporary, file);
    } catch { /* Read-only homes still receive the current advisory result. */ }
    finally { try { if (temporary) rmSync(temporary, { force: true }); } catch { /* Advisory cache cleanup is best effort. */ } }
  }
  return { status: cache.failed ? 'CHECK_UNAVAILABLE'
    : isSupportedCliVersion(cache.latestVersion, p.cliMinimumVersion)
      ? isSupportedCliVersion(currentVersion, cache.latestVersion) ? 'UP_TO_DATE' : 'UPDATE_AVAILABLE'
      : 'REGISTRY_BELOW_MINIMUM', currentVersion, minimumVersion: p.cliMinimumVersion,
    ...(cache.latestVersion ? { latestVersion: cache.latestVersion } : {}),
    ...(cache.nodeRequirement ? { nodeRequirement: cache.nodeRequirement } : {}), checkedAt: cache.checkedAt };
}

export function child(entry, args, env, { capture = false, timeout = 0 } = {}) {
  return new Promise((resolveResult, reject) => {
    const proc = spawn(process.execPath, [entry, ...args], { env, shell: false, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '', canceled = false, overflow = false, forceTimer;
    const cancel = signal => {
      canceled = true; proc.kill(signal);
      forceTimer ??= setTimeout(() => proc.kill('SIGKILL'), 2_000);
    };
    const onInt = () => cancel('SIGINT'); const onTerm = () => cancel('SIGTERM');
    process.on('SIGINT', onInt); process.on('SIGTERM', onTerm);
    const timer = timeout ? setTimeout(onTerm, timeout) : undefined;
    proc.stdout.on('data', b => { if (!capture) process.stdout.write(b); else { stdout += b; if (stdout.length > 2_000_000) { overflow = true; onTerm(); } } });
    proc.stderr.on('data', b => { if (!capture) process.stderr.write(b); else { stderr += b; if (stderr.length > 2_000_000) { overflow = true; onTerm(); } } });
    const clean = () => { clearTimeout(timer); clearTimeout(forceTimer); process.removeListener('SIGINT', onInt); process.removeListener('SIGTERM', onTerm); };
    proc.on('error', error => { clean(); reject(error); });
    proc.on('close', (code, signal) => { clean(); resolveResult({ code: canceled || signal || overflow ? 1 : (code ?? 1), stdout, stderr }); });
  });
}

export async function status(entry, ctx, run = child) {
  const r = await run(entry, ['auth', 'status', '--json'], ctx.env, { capture: true, timeout: 10_000 });
  let s;
  try { s = JSON.parse(r.stdout); } catch { throw new Error('Invalid CLI auth status; no business call was made'); }
  assert(typeof s.authenticated === 'boolean' && typeof s.operatorReady === 'boolean', 'Invalid auth status contract');
  assert(s.baseUrl === 'https://hub.mantur.ai', 'CLI_SITE_MISMATCH: current CLI is not on the production site; no environment was switched');
  return { code: r.code, authenticated: s.authenticated, operatorReady: s.operatorReady, baseUrl: s.baseUrl,
    ready: r.code === 0 && s.authenticated && s.operatorReady };
}

function readinessReport(p, entry, ctx, s, source, home) {
  const attributionSource = p.schemaVersion === 2 ? ctx.env.MANTURHUB_SOURCE : source;
  const sourceArgs = attributionSource ? ['--source', attributionSource] : [];
  const businessArgs = p.schemaVersion === 2 ? ['--business-code', ctx.env.MANTURHUB_BUSINESS_CODE] : [];
  const registration = registrationContext(p, attributionSource);
  const loginInstructions = p.schemaVersion === 2 && p.channel === 'standalone' && !s.authenticated
    ? { command: process.execPath, args: [entry, 'auth', 'login', '--from', registration.from, '--business-code', registration.businessCode],
      env: { MANTURHUB_CONFIG_DIR: ctx.configDir, MANTURHUB_IDENTITY_MODE: 'standalone', MANTURHUB_BASE: p.baseUrl } } : undefined;
  // The short command is valid only in the PATH/environment just checked. Keep
  // the complete binding for external terminals, explicit CLI paths and recovery.
  const quickLoginInstructions = loginInstructions && !ctx.existingCli && ctx.configDir === resolve(home, '.manturhub')
    ? { command: process.platform === 'win32' ? 'manturhub.cmd' : 'manturhub', args: loginInstructions.args.slice(1),
      scope: 'same-command-environment' } : undefined;
  return { channel: p.channel, product: p.product,
    accessMode: p.channel === 'connector' ? 'connector' : 'existing-cli',
    cliPath: entry, configDir: ctx.configDir,
    bindingArgs: p.channel === 'connector' ? businessArgs : [...sourceArgs, ...businessArgs, '--existing-cli', entry, '--config-dir', ctx.configDir],
    ...(p.schemaVersion === 2 ? { invocationAttribution: { businessCode: ctx.env.MANTURHUB_BUSINESS_CODE, skillCode: p.skillCode,
      skillVersion: p.skillVersion, distributionTarget: p.distributionTarget, accessMode: p.accessMode } } : {}),
    ...(attributionSource ? { source: attributionSource } : {}),
    ...(loginInstructions ? { loginInstructions, ...registration } : {}),
    ...(quickLoginInstructions ? { quickLoginInstructions } : {}),
    status: s.ready ? 'READY' : !s.authenticated ? 'LOGIN_REQUIRED' : !s.operatorReady ? 'OPERATOR_AUTH_REQUIRED' : 'AUTH_CHECK_FAILED',
    cliVersion: installedVersion(entry), cliMinimumVersion: p.cliMinimumVersion, ...s };
}

// CLI status accepts a URL. Restrict it to the configured gateway's job route;
// callers still have to bind it to an actual submission, not a model-made URL.
export function validateJobStatusUrl(value, p) {
  assert(typeof value === 'string' && value.length <= 512, 'Invalid job status URL');
  const path = value.startsWith(`${p.baseUrl}/`) ? value.slice(p.baseUrl.length) : value;
  assert(/^\/api\/openapi\/v1\/jobs\/[a-zA-Z0-9_-]{1,256}$/.test(path), 'Use the original same-site job status URL');
  return value;
}

export function validateExec(args, p) {
  assert(args.length, 'Missing CLI command');
  const action = args[0];
  assert(['describe', 'quote', 'run', 'resume', 'status', 'doctor', '--version'].includes(action), 'Unsupported business CLI command');
  if (['describe', 'quote', 'run'].includes(action)) assert(p.operators.includes(args[1]), 'Operator outside this Skill');
  if (action === 'resume') assert(args.length === 2 && /^[a-zA-Z0-9-]+$/.test(args[1]), 'Use the original recovery ID, not a URL');
  if (action === 'status') {
    assert(args.length === 2, 'Use status with only the original poll URL');
    validateJobStatusUrl(args[1], p);
  }
  if (action === 'doctor') assert(args.length === 2 && args[1] === '--json', 'Use doctor --json');
  if (action === '--version') assert(args.length === 1, 'Unexpected version arguments');
  return args;
}

const defaultUpdateCheck = (p, version, options) => process.env.MANTURHUB_DISABLE_SKILL_CLI_UPDATE_CHECK === '1'
  ? { status: 'DISABLED' } : checkCliUpdate(p, version, options);

export async function runAccess(p, argv, { env = process.env, home = homedir(), run = child, checkUpdates = defaultUpdateCheck,
  output = x => console.log(JSON.stringify(x)) } = {}) {
  assert(Number(process.versions.node.split('.')[0]) >= 20, 'Node >=20 required');
  const { binding, source, businessCode, args: parsed } = parseAccessArgs(argv);
  const ctx = context(p, env, home, binding, source, businessCode);
  const [action, ...rest] = parsed;
  if (['install', 'login', 'logout'].includes(action)) {
    throw new Error(p.channel === 'connector' ? 'Use the connector host installation/authentication controls'
      : 'CLI is user-managed: follow references/channel.md; no install, login or logout through this Skill');
  }
  assert(['registration', 'check', 'authorize', 'exec'].includes(action), 'Use registration, check, authorize or exec');
  if (action === 'registration') {
    assert(rest.length === 0, 'registration accepts no flags');
    output(registrationContext(p, source ?? ctx.env.MANTURHUB_SOURCE));
    return 0; // A link only: no CLI discovery, login, network or credential access.
  }
  if (p.schemaVersion === 2 && p.channel === 'standalone') {
    assert(ctx.env.MANTURHUB_SOURCE, 'HOST_SOURCE_REQUIRED: pass --source workbuddy|codex|claude-code|unknown for the current host');
  }
  if (action === 'authorize') {
    assert(p.channel === 'standalone', 'Use the connector host installation/authentication controls');
    assert(rest.length === 1 && rest[0] === '--approve-key', 'Requires explicit user approval: --approve-key');
  }
  const entry = locateCli(p, ctx);
  if (action === 'check') {
    assert(rest.length === 0, 'check accepts no flags');
    const s = await status(entry, ctx, run);
    const report = readinessReport(p, entry, ctx, s, source, home);
    if (p.cliInstallTag === 'latest') {
      report.cliUpdate = checkUpdates ? await checkUpdates(p, report.cliVersion, { home, env }) : { status: 'NOT_CHECKED' };
      report.upgradeInstructions = { requiresApproval: true, executor: p.channel === 'connector' ? 'connector-host' : 'user-agent',
        command: process.platform === 'win32' ? 'npm.cmd' : 'npm', args: ['install', '-g', '@manturhub/cli@latest',
          '--include=optional', '--engine-strict', '--registry=https://registry.npmjs.org'],
        cliPath: report.cliPath, configDir: report.configDir, verifyGlobalRoot: resolve(dirname(entry), '..'),
        explicitCliBinding: Boolean(ctx.existingCli), rerunCheckRequired: true };
    }
    output(report);
    return s.ready ? 0 : 1;
  }
  if (action === 'authorize') {
    const s = await status(entry, ctx, run);
    if (s.ready) { output({ status: 'ALREADY_READY' }); return 0; }
    if (!s.authenticated && p.schemaVersion === 2) output(readinessReport(p, entry, ctx, s, source, home));
    assert(s.authenticated, p.schemaVersion === 2
      ? 'LOGIN_REQUIRED: present the complete loginInstructions command/args/env from check; preserve --from and --business-code'
      : 'LOGIN_REQUIRED: ask the user to run auth login in that same environment');
    assert(!s.operatorReady && [0, 1].includes(s.code), 'Invalid readiness; inspect auth status before authorizing');
    const verifiedCtx = { ...ctx, env: { ...ctx.env, MANTURHUB_BASE: p.baseUrl } };
    // CLI owns the credential creation contract; describe is not a billable invocation.
    const probe = await run(entry, ['describe', p.probeOperator, '--json'], verifiedCtx.env, { capture: true, timeout: 60_000 });
    if (probe.code !== 0) { process.stderr.write('Operator authorization/contract check failed; inspect platform Key state before retrying.\n'); return probe.code; }
    const ready = await status(entry, verifiedCtx, run); output({ status: ready.ready ? 'OPERATOR_READY' : 'AUTHORIZATION_INCOMPLETE', ...ready });
    return ready.ready ? 0 : 1;
  }
  assert(rest[0] === '--', 'Use exec -- <CLI arguments>');
  const args = validateExec(rest.slice(1), p);
  if (p.schemaVersion === 2) {
    const fixedOptions = { 'business-code': ctx.env.MANTURHUB_BUSINESS_CODE, 'skill-code': p.skillCode, 'skill-version': p.skillVersion,
      'distribution-target': p.distributionTarget, 'access-mode': p.accessMode, source: ctx.env.MANTURHUB_SOURCE };
    for (let i = 1; i < args.length; i++) {
      const token = args[i], match = /^--([^=]+)(?:=(.*))?$/.exec(token);
      if (match && Object.hasOwn(fixedOptions, match[1])) {
        const actual = match[2] ?? args[++i];
        assert(actual === fixedOptions[match[1]], `Conflicting product attribution: --${match[1]}`);
      }
    }
  }
  if (!['doctor', '--version'].includes(args[0])) {
    const s = await status(entry, ctx, run);
    if (!s.ready && p.schemaVersion === 2) output(readinessReport(p, entry, ctx, s, source, home));
    assert(s.ready, p.schemaVersion === 2
      ? 'Authorization not ready; use check and its complete loginInstructions, or the connector host controls; preserve registration context'
      : 'Authorization not ready; follow this channel login instructions');
  }
  const execEnv = ['doctor', '--version'].includes(args[0]) ? ctx.env : { ...ctx.env, MANTURHUB_BASE: p.baseUrl };
  return (await run(entry, args, execEnv)).code; // Preserve exit 3 and separate streams; never retry.
}

if (process.argv[1] && existsSync(process.argv[1]) && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  try {
    const p = JSON.parse(readFileSync(new URL('./access-profile.json', import.meta.url), 'utf8'));
    process.exitCode = await runAccess(p, process.argv.slice(2), { checkUpdates: defaultUpdateCheck });
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
