import assert from 'node:assert/strict';
import {hash,json,fact} from './production-state.mjs';

export function imageQuoteGroup(input){
  assert(!Object.hasOwn(input,'n')&&!Object.hasOwn(input,'count'),'Use imageCount for new image requests');
  const imageCount=input.imageCount??1;
  assert(Number.isSafeInteger(imageCount)&&imageCount>0,'imageCount must be a positive integer');
  assert(input.model===undefined||typeof input.model==='string'&&input.model.trim(),'Invalid image model');
  return {model:input.model??null,imageCount};
}

// One preparation session only. Actual inputs, CLI confirmations and run calls
// remain per operation; uniform image prices do not depend on prompt/media/size.
export function imageBatchQuoteHost(root,batchId,host){
  const groups=new Map();
  return {...host,cli:async(args,...rest)=>{
    if(args[0]!=='quote'||args[1]!=='op.image.generate')return host.cli(args,...rest);
    const path=args[args.indexOf('--json-file')+1],input=json(root,path);
    const group=imageQuoteGroup(input),key=hash(group);
    if(!groups.has(key))groups.set(key,(async()=>{
      const result=await host.cli(args,...rest);
      return {...result,quote_evidence:{schema_version:1,policy:'uniform-image-model-count-v1',batch_id:batchId,group,
        representative_input:fact(root,path).path,representative_input_sha256:hash(input),checked_at:new Date().toISOString()}};
    })());
    // Cache failures too: retrying preparation starts a fresh session instead of
    // issuing the same failed quote for every member of this group.
    return structuredClone(await groups.get(key));
  }};
}
