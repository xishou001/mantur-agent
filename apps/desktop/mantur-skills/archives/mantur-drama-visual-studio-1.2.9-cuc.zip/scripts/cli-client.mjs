// Public CLI subprocess services. Credentials and authenticated HTTP remain in the CLI.
import assert from 'node:assert/strict';
import { linkSync, lstatSync, mkdirSync, readFileSync, realpathSync, unlinkSync, writeFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { dirname, isAbsolute, join, parse, resolve } from 'node:path';
import { homedir } from 'node:os';
import { spawn } from 'node:child_process';
import { child, context, isSkillId, locateCli, parseAccessArgs, runAccess, validateProfile } from './access.mjs';
import { createArtifactDownloader } from './artifact-download.mjs';

const testModeUrl = new URL('./test-mode.mjs', import.meta.url);
const testMode = lstatSync(testModeUrl, { throwIfNoEntry: false }) ? await import(testModeUrl.href) : undefined;
export const publicCapabilities = Object.freeze({ upload: true, updates: true, singleJobStatus: true,
  boundedRecoveryQuery: false, accountBoundBalance: false, artifactDownload: true });
const balanceContractUnsupported = () => Object.assign(new Error('当前公开工具未提供可核验的账户绑定余额合同。'),
  { code: 'BALANCE_CONTRACT_UNSUPPORTED' });

export function executionEnvironment(profile, env = process.env) {
  const businessCode=env.MANTURHUB_BUSINESS_CODE;
  if(businessCode!==undefined)assert(isSkillId(businessCode), 'Invalid business code');
  if(profile?.channel==='connector'){
    assert(!env.MANTURHUB_CLI_ENTRY, 'Connector cannot reuse an external CLI or identity');
    assert(env.MANTURHUB_SOURCE===undefined||env.MANTURHUB_SOURCE==='workbuddy', 'Connector host source must be workbuddy');
    return {project:env.MANTURHUB_PROJECT,bindingArgs:[],businessCode};
  }
  const bindingArgs = ['--source', env.MANTURHUB_SOURCE || 'unknown'];
  if (env.MANTURHUB_CLI_ENTRY) bindingArgs.push('--existing-cli', env.MANTURHUB_CLI_ENTRY,
    '--config-dir', env.MANTURHUB_CONFIG_DIR || join(homedir(), '.manturhub'));
  return { project: env.MANTURHUB_PROJECT, bindingArgs, businessCode };
}

function installedProfile(){
  const file=new URL('./access-profile.json',import.meta.url),stat=lstatSync(file);
  assert(stat.isFile()&&!stat.isSymbolicLink()&&stat.size<=32768,'Invalid installed access profile');
  return validateProfile(JSON.parse(readFileSync(file,'utf8')));
}

/** Non-secret defaults from this installed package, without authentication or CLI dispatch. */
export function installedExecutionEnvironment(env=process.env){
  const profile=installedProfile(),defaults=executionEnvironment(profile,env);
  if(profile.channel==='connector'){
    context(profile,env);
    if(profile.schemaVersion===2)assert(env.MANTURHUB_BUSINESS_CODE!==undefined,'Missing connector environment: MANTURHUB_BUSINESS_CODE');
  }
  return defaults;
}

const processKeys=['PATH','HOME','USERPROFILE','LANG'];
const publicKeys=['MANTURHUB_PROJECT','MANTURHUB_CLI_ENTRY','MANTURHUB_BASE','MANTURHUB_CONFIG_DIR','MANTURHUB_IDENTITY_MODE','MANTURHUB_SKILL_ENV',
  'MANTURHUB_DISABLE_UPDATE_CHECK','MANTURHUB_DISABLE_SKILL_UPDATE_CHECK','MANTURHUB_SOURCE','MANTURHUB_BUSINESS_CODE',
  'MANTURHUB_SKILL_CODE','MANTURHUB_SKILL_VERSION','MANTURHUB_DISTRIBUTION_TARGET','MANTURHUB_ACCESS_MODE'];
/** IPC contains only public context. The receiver validates it against its own package again. */
function publicProcessContext(profile,selected){
  const values={...selected.env,...(profile.environmentPolicy ? selected.bindingEnv : {}),
    ...(profile.channel!=='connector'&&selected.existingCli?{MANTURHUB_CLI_ENTRY:selected.existingCli}:{})};
  return Object.fromEntries([...processKeys,...publicKeys].filter(key=>typeof values[key]==='string').map(key=>[key,values[key]]));
}
export function installedExecutionContext(env=process.env,{received=false,businessCode,projectDir,bindingPath}={}){
  assert(env&&typeof env==='object'&&!Array.isArray(env),'Invalid execution context');
  const allowed=[...processKeys,...publicKeys];
  if(received)assert(Object.keys(env).every(key=>allowed.includes(key)),'Unexpected execution context field');
  for(const key of allowed)if(env[key]!==undefined)assert(typeof env[key]==='string'&&env[key].length<=32768&&!/[\x00-\x1f\x7f-\x9f]/.test(env[key]),'Invalid execution context value');
  const profile=installedProfile(),defaults=executionEnvironment(profile,env),parsed=parseAccessArgs(defaults.bindingArgs);
  if(received){
    assert(typeof env.PATH==='string','Incomplete execution context');
    const required=['MANTURHUB_CONFIG_DIR','MANTURHUB_IDENTITY_MODE','MANTURHUB_DISABLE_UPDATE_CHECK','MANTURHUB_DISABLE_SKILL_UPDATE_CHECK',
      ...(profile.environmentPolicy ? ['MANTURHUB_SKILL_ENV','MANTURHUB_BASE'] : []),
      ...(profile.schemaVersion===2?['MANTURHUB_SOURCE','MANTURHUB_BUSINESS_CODE','MANTURHUB_SKILL_CODE','MANTURHUB_SKILL_VERSION','MANTURHUB_DISTRIBUTION_TARGET','MANTURHUB_ACCESS_MODE']:[])];
    assert(required.every(key=>typeof env[key]==='string'&&env[key]),'Incomplete execution context');
    for(const key of ['HOME','USERPROFILE'])if(process.env[key]!==undefined)assert(env[key]===process.env[key],'Conflicting process home');
  }
  if(profile.channel==='connector'){
    context(profile,env);
    if(profile.schemaVersion===2)assert(env.MANTURHUB_BUSINESS_CODE!==undefined,'Missing connector environment: MANTURHUB_BUSINESS_CODE');
  }
  assert(businessCode===undefined||profile.schemaVersion===2&&isSkillId(businessCode),'Invalid execution context business');
  assert(!received||businessCode===undefined,'Received context cannot override business');
  assert((projectDir===undefined)===(bindingPath===undefined),'Execution context requires an explicit project binding path');
  if(projectDir!==undefined){
    const args=[...defaults.bindingArgs,...(businessCode===undefined?[]:['--business-code',businessCode])];
    return createPublicCli({profile,env,bindingArgs:args,projectDir,bindingPath}).executionContext();
  }
  const selected=context(profile,env,undefined,parsed.binding,parsed.source,businessCode??defaults.businessCode);
  return publicProcessContext(profile,selected);
}

export function parseJsonOutput(text) {
  try { return JSON.parse(text); } catch { return undefined; }
}

export function confirmationFrom(text) {
  let start=-1,depth=0,quoted=false,escaped=false;
  for(let i=0;i<text.length;i++){
    const character=text[i];
    if(start<0){if(character==='{'){start=i;depth=1;}continue;}
    if(quoted){if(escaped)escaped=false;else if(character==='\\')escaped=true;else if(character==='"')quoted=false;continue;}
    if(character==='"'){quoted=true;continue;}
    if(character==='{')depth++;
    else if(character==='}'&&--depth===0){
      const value=i-start<65536?parseJsonOutput(text.slice(start,i+1)):undefined;
      if(value?.error==='CONFIRMATION_REQUIRED'&&typeof value.confirmation_token==='string'&&value.confirmation_token)return value;
      start=-1;
    }
  }
}

// The original access adapter stays byte-for-byte unchanged for existing products.
// Only cancellable background callers use this process owner.
function cancellableRun(signal) {
  assert(typeof signal.addEventListener === 'function' && typeof signal.removeEventListener === 'function', 'Invalid CLI cancellation signal');
  return (entry,args,env,{capture=false,timeout=0}={}) => new Promise((resolveResult,reject)=>{
    if(signal.aborted){resolveResult({code:1,stdout:'',stderr:'',canceled:true});return;}
    const proc=spawn(process.execPath,[entry,...args],{env,shell:false,stdio:['ignore','pipe','pipe']});
    let stdout='',stderr='',stdoutBytes=0,stderrBytes=0,canceled=false,overflow=false,forceTimer,settled=false;
    const cancel=()=>{
      if(settled)return;
      canceled=true;proc.kill('SIGTERM');
      forceTimer??=setTimeout(()=>proc.kill('SIGKILL'),2000);forceTimer.unref?.();
    };
    const cleanup=()=>{
      settled=true;clearTimeout(timer);clearTimeout(forceTimer);
      signal.removeEventListener('abort',cancel);process.removeListener('SIGINT',cancel);process.removeListener('SIGTERM',cancel);
    };
    const timer=timeout?setTimeout(cancel,timeout):undefined;
    signal.addEventListener('abort',cancel,{once:true});process.on('SIGINT',cancel);process.on('SIGTERM',cancel);
    if(signal.aborted)cancel();
    proc.stdout.setEncoding('utf8');proc.stderr.setEncoding('utf8');
    proc.stdout.on('data',value=>{
      if(!capture){process.stdout.write(value);return;}
      stdoutBytes+=Buffer.byteLength(value);if(stdoutBytes<=2_000_000)stdout+=value;else{overflow=true;cancel();}
    });
    proc.stderr.on('data',value=>{
      if(!capture){process.stderr.write(value);return;}
      stderrBytes+=Buffer.byteLength(value);if(stderrBytes<=2_000_000)stderr+=value;else{overflow=true;cancel();}
    });
    proc.once('error',error=>{cleanup();reject(error);});
    proc.once('close',(code,exitSignal)=>{
      cleanup();resolveResult({code:canceled||overflow||exitSignal?1:code??1,stdout,stderr,...(canceled?{canceled:true}:{})});
    });
  });
}

export function createPublicCli({ profile, bindingArgs = [], projectDir, bindingPath, env = process.env, run = child, signal } = {}) {
  assert(!profile.environmentPolicy || testMode, 'Incomplete test environment package');
  const usesDefaultRunner = run === child;
  if(signal && run===child)run=cancellableRun(signal);
  assert(profile.readOnlyQueries === undefined || Array.isArray(profile.readOnlyQueries)
    && profile.readOnlyQueries.length === 1 && profile.readOnlyQueries[0] === 'balance', 'Invalid read-only query capability');
  const capabilities = profile.readOnlyQueries?.includes('balance')
    ? Object.freeze({ ...publicCapabilities, balanceQuery: true }) : publicCapabilities;
  const downloadArtifact = createArtifactDownloader({ trustedOrigins: profile.artifactOrigins ?? [] });
  const parsed = parseAccessArgs(bindingArgs);
  assert(parsed.args.length === 0, 'Only access binding arguments are accepted');
  if(profile.channel==='connector'){
    assert(!parsed.binding&&!env.MANTURHUB_CLI_ENTRY, 'Connector cannot reuse an external CLI or identity');
    assert(env.MANTURHUB_SOURCE===undefined||env.MANTURHUB_SOURCE==='workbuddy', 'Connector host source must be workbuddy');
  }
  if(bindingPath!==undefined)assert(projectDir&&typeof bindingPath==='string'&&bindingPath.length
    &&!isAbsolute(bindingPath)&&!/[\\:\x00-\x1f\x7f-\x9f]/.test(bindingPath)
    &&bindingPath.split('/').every(part=>part&&part!=='.'&&part!=='..'&&/^[a-zA-Z0-9_.-]+$/.test(part)), 'Unsafe project CLI binding path');
  let selectedArgs = [...bindingArgs], pinnedBinding, persistedBusiness;
  const bindingFile = projectDir&&bindingPath ? join(realpathSync(projectDir),bindingPath) : undefined;
  function assertBusiness(saved,persisted=false){
    if(!persisted&&persistedBusiness===undefined)return;
    if(persistedBusiness!==undefined)assert(saved.businessCode===persistedBusiness, 'CLI_BINDING_CONFLICT: business context changed');
    if(saved.businessCode===undefined)return;
    const requested=parsed.businessCode??env.MANTURHUB_BUSINESS_CODE;
    if(requested!==undefined)assert(requested===saved.businessCode, 'CLI_BINDING_CONFLICT: business context changed');
    if(persisted)persistedBusiness=saved.businessCode;
  }
  function safeBindingPath() {
    let cursor = parse(bindingFile).root;
    for (const part of bindingFile.slice(cursor.length).split(/[\\/]/).filter(Boolean)) {
      cursor = join(cursor, part);
      assert(!lstatSync(cursor, { throwIfNoEntry: false })?.isSymbolicLink(), 'Unsafe CLI binding path');
    }
  }
  function applyBinding(args,persisted=false) {
    const saved = parseAccessArgs(args);
    assert(saved.args.length === 0 && (profile.channel === 'connector' ? !saved.binding : saved.binding), 'Invalid saved CLI binding');
    assertBusiness(saved,persisted);
    if (pinnedBinding) assert(saved.binding && pinnedBinding.cliPath === saved.binding.cliPath
      && pinnedBinding.configDir === saved.binding.configDir, 'CLI_BINDING_CONFLICT: the pinned CLI/configuration changed');
    if (parsed.binding) assert(saved.binding && realpathSync(parsed.binding.cliPath) === realpathSync(saved.binding.cliPath)
      && resolve(parsed.binding.configDir) === resolve(saved.binding.configDir), 'CLI_BINDING_CONFLICT: continue the original CLI/configuration');
    if (profile.environmentPolicy) {
      assert(!parsed.environmentBinding || parsed.environmentBinding === saved.environmentBinding, 'ENVIRONMENT_BINDING_CONFLICT: preserve the checked environment');
      assert(!saved.project || projectDir && resolve(saved.project) === resolve(projectDir), 'PROJECT_ENVIRONMENT_CONFLICT: preserve the original project');
      // Historical public-runtime projects could only use production. Never
      // relabel their frozen calls as test requests or rewrite their binding.
      assert(!persisted || saved.environmentBinding || (env.MANTURHUB_SKILL_ENV ?? 'production') === 'production',
        'LEGACY_ENVIRONMENT_BINDING: old public projects must continue in their original production environment');
    }
    const source = parsed.source ?? env.MANTURHUB_SOURCE ?? saved.source;
    const business = saved.businessCode ?? parsed.businessCode ?? (profile.schemaVersion===2 ? env.MANTURHUB_BUSINESS_CODE : undefined);
    selectedArgs = [...(source ? ['--source', source] : []),
      ...(business ? ['--business-code', business] : []),
      ...(saved.binding ? ['--existing-cli', saved.binding.cliPath, '--config-dir', saved.binding.configDir] : []),
      ...(profile.environmentPolicy && saved.environmentBinding ? ['--environment-binding', saved.environmentBinding] : []),
      ...(profile.environmentPolicy && projectDir ? ['--project', resolve(projectDir)] : [])];
    pinnedBinding = saved.binding;
  }
  function readBinding() {
    if (!bindingFile) return;
    safeBindingPath();
    const info = lstatSync(bindingFile, { throwIfNoEntry: false });
    if (!info) return;
    assert(info.isFile() && info.size <= 32768, 'Invalid CLI binding file');
    const saved = JSON.parse(readFileSync(bindingFile, 'utf8'));
    assert(saved.schemaVersion === 1 && saved.product === profile.product && Array.isArray(saved.bindingArgs)
      && Object.keys(saved).every(key => ['schemaVersion', 'product', 'bindingArgs'].includes(key)), 'Invalid CLI binding file');
    applyBinding(saved.bindingArgs,true);
  }
  readBinding();
  const current = () => {
    const selected = parseAccessArgs(selectedArgs);
    const ctx = context(profile, env, undefined, selected.binding, selected.source, selected.businessCode);
    if (profile.environmentPolicy) {
      const identity = testMode.environmentIdentity(profile, ctx);
      assert(!selected.environmentBinding || selected.environmentBinding === testMode.environmentDigest(identity),
        'ENVIRONMENT_BINDING_CONFLICT: restore the original test/production gateway and config');
      testMode.projectEnvironment(projectDir, identity);
    }
    return ctx;
  };
  function entry() { return locateCli(profile, current()); }
  function persistBinding() {
    if (!bindingFile) return;
    if (lstatSync(bindingFile, { throwIfNoEntry: false })) { readBinding(); return; }
    safeBindingPath(); mkdirSync(dirname(bindingFile), { recursive: true }); safeBindingPath();
    const temporary = `${bindingFile}.${randomUUID()}.tmp`;
    let created = false;
    try {
      writeFileSync(temporary, JSON.stringify({ schemaVersion: 1, product: profile.product, bindingArgs: selectedArgs }) + '\n', { flag: 'wx', mode: 0o600 });
      created = true;
      try { linkSync(temporary, bindingFile); } catch (error) { if (error.code !== 'EEXIST') throw error; }
    } finally { if (created) unlinkSync(temporary); }
    const intended = parseAccessArgs(selectedArgs).binding;
    readBinding();
    const winner = parseAccessArgs(selectedArgs).binding;
    assert(profile.channel === 'connector' || intended && winner && intended.cliPath === winner.cliPath && intended.configDir === winner.configDir,
      'CLI_BINDING_CONFLICT: another invocation selected a different CLI/configuration');
  }
  async function inspect(checkRunner) {
    readBinding();
    if (profile.environmentPolicy) current();
    assertBusiness(parseAccessArgs(selectedArgs));
    let observation;
    const code = await runAccess(profile, [...selectedArgs, 'check'], { env, run: checkRunner, output: value => { observation = value; } });
    if (observation?.bindingArgs) applyBinding(observation.bindingArgs);
    // auth status can exit 0 while authenticated/operatorReady is false. Keep
    // ACCESS's readiness exit code; the status payload must not overwrite it.
    return { ...observation, code, capabilities };
  }
  async function check() { return inspect(run); }
  async function remoteReady() {
    assert(!projectDir||bindingFile, 'PROJECT_CLI_BINDING_PATH_REQUIRED: provide the project binding path explicitly');
    assert((await check()).code === 0, 'Authorization is not ready');
    persistBinding();
    if (profile.environmentPolicy) testMode.projectEnvironment(projectDir, testMode.environmentIdentity(profile, current()), { commit: true });
  }
  async function exec(args, { timeout = 0 } = {}) {
    if (!['doctor', '--version'].includes(args[0])) await remoteReady();
    let result;
    const code = await runAccess(profile, [...selectedArgs, 'exec', '--', ...args], { env,
      run: async (file, argv, selectedEnv, options = {}) => {
        const response = await run(file, argv, selectedEnv, { ...options, capture: true, timeout: options.timeout ?? timeout });
        if (!(argv[0] === 'auth' && argv[1] === 'status')) result = response;
        return response;
      } });
    return { ...result, code, json: parseJsonOutput(result?.stdout ?? '') };
  }
  async function upload(file) {
    assert(isAbsolute(file), 'Upload requires an absolute user-selected file');
    const selected = realpathSync(file);
    assert(lstatSync(selected).isFile(), 'Upload requires a regular file');
    await remoteReady();
    const ctx = current();
    const result = await run(entry(), ['upload', selected, '--json'], { ...ctx.env, MANTURHUB_BASE: ctx.baseUrl ?? profile.baseUrl }, { capture: true, timeout: 300_000 });
    const receipt = parseJsonOutput(result.stdout);
    assert(result.code === 0 && receipt?.status === 'AVAILABLE' && typeof receipt.fileId === 'string', 'Public CLI upload did not return an AVAILABLE file');
    return receipt;
  }
  async function updates() {
    readBinding(); const ctx = current();
    const result = await run(entry(), ['skill', 'outdated', '--json'], ctx.env, { capture: true, timeout: 15_000 });
    const value = parseJsonOutput(result.stdout);
    assert(result.code === 0 && Array.isArray(value?.skills), 'Public CLI update check failed');
    return value;
  }
  async function balanceIdentity(_options) { throw balanceContractUnsupported(); }
  async function balance(_expectedIdentity, _options) { throw balanceContractUnsupported(); }
  async function queryBalance({ signal: querySignal } = {}) {
    const failure = code => Object.assign(new Error(code), { code });
    if (!capabilities.balanceQuery) throw failure('BALANCE_QUERY_UNSUPPORTED');
    for (const selected of [signal, querySignal]) assert(selected === undefined
      || typeof selected.addEventListener === 'function' && typeof selected.aborted === 'boolean', 'Invalid balance cancellation signal');
    const controller = new AbortController(), listeners = [];
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; controller.abort(); }, 15_000); timer.unref?.();
    for (const parent of [signal, querySignal].filter(Boolean)) {
      const abort = () => controller.abort();
      if (parent.aborted) abort();
      else { parent.addEventListener('abort', abort, { once: true }); listeners.push([parent, abort]); }
    }
    const cancellation = controller.signal;
    const canceled = () => failure(timedOut ? 'BALANCE_QUERY_TIMEOUT' : 'BALANCE_QUERY_CANCELED');
    const queryRunner = usesDefaultRunner ? cancellableRun(cancellation) : run;
    try {
      if (cancellation.aborted) throw canceled();
      const observed = await inspect(queryRunner);
      if (cancellation.aborted) throw canceled();
      if (![0, 1].includes(observed.code) || observed.status === 'AUTH_CHECK_FAILED') throw failure('BALANCE_QUERY_FAILED');
      if (!observed.authenticated) throw failure('BALANCE_QUERY_AUTH_REQUIRED');
      const ctx = current();
      assert(observed.baseUrl === (ctx.baseUrl ?? profile.baseUrl) && typeof observed.cliPath === 'string', 'Invalid balance query context');
      assert(ctx.configDir === observed.configDir && entry() === observed.cliPath, 'Balance query context changed');
      // A balance read needs an authenticated account, not an operator Key or a project write.
      const result = await queryRunner(observed.cliPath, ['balance', '--json'],
        { ...ctx.env, MANTURHUB_BASE: observed.baseUrl }, { capture: true, timeout: 15_000, signal: cancellation });
      if (cancellation.aborted) throw canceled();
      readBinding();
      assert(current().configDir === observed.configDir && entry() === observed.cliPath, 'Balance query context changed');
      const { parseBalanceQueryResult } = await import('./balance-query.mjs');
      return parseBalanceQueryResult(result);
    } catch (error) {
      if (cancellation.aborted) throw canceled();
      if (/^BALANCE_QUERY_[A-Z_]+$/.test(error.code ?? '')) throw error;
      throw failure('BALANCE_QUERY_FAILED');
    } finally {
      clearTimeout(timer);
      for (const [parent, abort] of listeners) parent.removeEventListener('abort', abort);
    }
  }
  const download = (url, target) => downloadArtifact(url, target, { projectDir, signal });
  return { check, exec, upload, updates, download, balanceIdentity, balance, queryBalance,
    executionContext:()=>publicProcessContext(profile,current()),capabilities };
}

export function installedPublicCli(options = {}) {
  const profile = installedProfile();
  return createPublicCli({ bindingArgs: executionEnvironment(profile, options.env ?? process.env).bindingArgs, ...options, profile });
}
