import assert from 'node:assert/strict';
import {lstatSync} from 'node:fs';
import {productionHost} from './production-host.mjs';
import {prepareProduction,continueProduction,loadProduction,productionStatus,recoverAttachments} from './production.mjs';
import {batchActions,batchEntry} from './production-batch.mjs';
import {recoverLegacyProduction} from './production-legacy.mjs';
import {checked,directory} from './production-state.mjs';
import {productionReviewBaseline} from './production-review.mjs';
const stages={'asset-extraction':'extraction','asset-operation':'material','clip-compilation':'clips','video-generation':'video'};
export const productionActions=['asset-review-baseline','query-account-balance','recover-clip-attachments','recover-legacy-production',...batchActions,...Object.keys(stages).flatMap(name=>['prepare-'+name,'submit-'+name,'resume-'+name,name+'-status'])];
export async function productionEntry(root,action,tokens,host=productionHost(root)){
  if(action==='asset-review-baseline'){
    assert(tokens.length===2&&tokens[0]==='--operation-id'&&tokens[1],'Use --operation-id <original completed material ID>');
    return productionReviewBaseline(root,tokens[1]);
  }
  if(action==='recover-legacy-production')return recoverLegacyProduction(root,tokens,host);
  if(batchActions.includes(action))return batchEntry(root,action,tokens,host);
  if(action==='recover-clip-attachments'){
    assert(tokens[0]==='--operation-id'&&tokens[1]&&(tokens.length===2||tokens.length===3&&tokens[2]==='--local-only'),'Use --operation-id <original ID> [--local-only]');
    return recoverAttachments(root,tokens[1],host,{localOnly:tokens[2]==='--local-only'});
  }
  if(action==='query-account-balance'){
    assert(tokens.length===0,'query-account-balance accepts no arguments');
    try{return {ok:true,available:true,...await host.queryBalance()};}
    catch{return {ok:false,available:false,error:{code:'BALANCE_QUERY_UNAVAILABLE'},message:'余额暂不可用，可稍后重试；不影响制作与原任务恢复。'};}
  }
  const name=Object.keys(stages).find(name=>action.endsWith(name)||action===name+'-status');assert(name,'Unknown production action');
  const values={},flags=new Set();
  for(let i=0;i<tokens.length;i++){
    const key=tokens[i];assert(!Object.hasOwn(values,key)&&!flags.has(key),'Duplicate production argument');
    if(key==='--local-only'||key==='--no-write'){flags.add(key);continue;}
    assert(['--input','--operation-id','--confirm','--manifest-review','--attempt','--retry-of'].includes(key),'Use public CLI confirmation; private approval/batch/upload approval files are retired');
    const value=tokens[++i];assert(value&&!value.startsWith('--'),'Missing production argument');values[key]=value;
  }
  if(action.startsWith('prepare-'))return prepareProduction(root,stages[name],values['--input'],host,{attempt:values['--attempt'],retryOf:values['--retry-of'],manifestReview:values['--manifest-review'],noWrite:flags.has('--no-write'),localOnly:flags.has('--local-only')});
  const id=values['--operation-id'];
  if(!lstatSync(checked(root,directory(id)+'/operation.json'),{throwIfNoEntry:false})){
    if(name==='video-generation'&&action.startsWith('resume-')&&flags.has('--local-only')){
      const {resumeVideoLocally}=await import('../runtime/video-generation-operation.mjs');
      return resumeVideoLocally(root,id,{noWrite:flags.has('--no-write'),refresh:host.refresh});
    }
    return {ok:false,code:1,operation_id:id,error:{code:'LEGACY_RECOVERY_REQUIRED'},next_action:'inspect_original_receipt',message:'有原 operation.json、Job 受理回执和 pollUrl 时，使用 recover-legacy-production 查询与下载原结果；未知提交仍交匹配稳定版本，不转换批准或重提。'};
  }
  assert(!flags.has('--no-write'),'Public production status is read-only; use the stage status action');
  assert(loadProduction(root,id).plan.stage===stages[name],'Operation belongs to another stage');
  if(action.endsWith('-status'))return productionStatus(loadProduction(root,id));
  return continueProduction(root,id,action.startsWith('submit-')?'submit':'resume',host,{confirm:values['--confirm'],manifestReview:values['--manifest-review'],localOnly:flags.has('--local-only')});
}
