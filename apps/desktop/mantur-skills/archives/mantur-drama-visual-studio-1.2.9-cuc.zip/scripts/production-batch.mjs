// Local orchestration only. Pricing, per-request consent and submission remain CLI-owned.
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {lstatSync,readdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {withProductionWriter} from './production-writer.mjs';
import {confirmationFrom} from './cli-client.mjs';
import {business,assertVideoProvider} from './production-plans.mjs';
import {prepareProduction,continueProduction,loadProduction,productionStatus,feeSummary,preparationQuote} from './production.mjs';
import {imageBatchQuoteHost,imageQuoteGroup} from './image-batch-quote.mjs';
import {videoBatchQuotes} from './video-batch-quote.mjs';
import {rechargeForFailure} from './recharge.mjs';
import {hash,json,save,immutable,checked,fact,fail,operations,stripped} from './production-state.mjs';

export const batchActions=['quote-asset-batch','prepare-asset-batch','activate-asset-batch','asset-operation-queue-status','step-asset-operation-queue','plan-video-batch','prepare-video-batch','approve-video-batch','video-batch-status','step-video-batch'];
const base=id=>{assert(/^[a-f0-9]{64}$/.test(id),'Invalid public batch ID');return `.pipeline-state/runtime/public-batches/${id}`;};
const exists=(root,path)=>!!lstatSync(checked(root,path),{throwIfNoEntry:false});
const units=value=>{assert(typeof value==='number'&&value>=0&&Number.isFinite(value)&&Number.isSafeInteger(Math.round(value*1e6))&&Math.abs(value*1e6-Math.round(value*1e6))<1e-6,'Invalid batch amount');return Math.round(value*1e6);};
const sum=values=>{const total=values.reduce((a,b)=>a+units(b),0);assert(Number.isSafeInteger(total),'Batch amount overflow');return total/1e6;};
const inFlight=new Set(['accepted','submission_unknown','result_pending']);
const materialOperators={image:'op.image.generate','voice-design':'op.voice.design',audio:'op.audio.generate',understanding:'op.video.understand-v2'};
const inquiryPolicies=new Set(['image-inquiry-v1','material-inquiry-v1']);
function inquiryInput(d){
  assert(Object.hasOwn(materialOperators,d.kind),'Unsupported material kind');
  if(d.kind==='image'){
    assert(d.parameters.mode===undefined||['generate','edit'].includes(d.parameters.mode),'Invalid image mode');
    // This is a price sample, never a production input. References do not affect
    // image pricing; actual edit inputs are built only after production approval.
    return business.assetInput('image',{...d.parameters,mode:'generate'},[]);
  }
  assert(d.references===undefined||Array.isArray(d.references),'Invalid material references');
  const refs=(d.references??[]).map(ref=>{
    const url=new URL(ref.remote_url);
    assert(url.protocol==='https:'&&!url.username&&!url.password&&!url.search&&!url.hash,'Stable public reference URL required');
    return {kind:ref.kind,url:ref.remote_url};
  });
  return business.assetInput(d.kind,d.parameters,refs);
}
function materialQuoteGroup(kind,input,pricing){
  if(kind==='image')return imageQuoteGroup(input);
  const parameters={...input};
  if(kind==='voice-design'&&pricing==='fixed-call'){delete parameters.description;delete parameters.preview_text;}
  return parameters;
}
const fixedVoiceQuote=q=>q?.chargeType===1&&!q.postExecutionSettlement;
// CLI renders prepaid formula text differently in quote and confirmation. Price
// version/amount are authoritative; deferred settlement retains its full formula.
const quoteKey=q=>hash({points:feeSummary(q).cost_points,kind:feeSummary(q).cost_kind,version:q?.priceVersionTag??null,settlement:q?.postExecutionSettlement??null});
const opFor=(root,item)=>item.operation_id?loadProduction(root,item.operation_id):null;
function unsubmittedHistory(root,op){
  const history=new Set([null]);let id=op.not_submitted_id;
  while(id){
    assert(/^[a-f0-9]{64}$/.test(id)&&!history.has(id),'Invalid non-submission chain');history.add(id);
    const proof=json(root,`.pipeline-state/runtime/public-production/${op.operation_id}/not-submitted/${id}.json`);
    assert(hash(proof)===id&&proof.schema_version===1&&proof.operation_id===op.operation_id&&proof.input_sha256===op.input_sha256&&
      ['cli_confirmation','original_dispatch_not_submitted','not_dispatched','cli_not_submitted'].includes(proof.reason),'Invalid non-submission evidence');
    id=proof.previous;
  }
  return history;
}
function load(root,id){
  const r=json(root,base(id)+'/batch.json');assert(r.schema_version===1&&r.transport==='public-cli-batch-v1'&&r.batch_id===id&&r.project===resolve(root)&&hash(r.plan)===id&&hash(json(root,base(id)+'/plan.json'))===id,'Batch binding changed');
  // Recover a crash between append-only reservation evidence and the mutable progress pointer.
  const folder=base(id)+'/reservations',reserved={},original={},proofs=new Map();
  if(exists(root,folder))for(const name of readdirSync(checked(root,folder)).filter(name=>/^[a-f0-9]{64}\.json$/.test(name))){
    const row=json(root,folder+'/'+name);assert(hash(row)+'.json'===name&&row.batch_id===id&&Number.isInteger(row.index)&&r.plan.items[row.index]&&/^[a-f0-9]{64}$/.test(row.operation_id)&&/^[a-f0-9]{64}$/.test(row.authorization_id),'Invalid budget reservation');
    const a=json(root,base(id)+`/approval-${row.authorization_id}.json`),approved=a.proposal?.items?.find(item=>item.index===row.index);
    assert(hash(a)===row.authorization_id&&a.batch_id===id&&approved?.binding===hash(r.plan.items[row.index])&&row.points===approved.cost_points,'Reservation approval changed');units(row.points);
    const prior=original[String(row.index)];assert(!prior||prior.operation_id===row.operation_id,'Reservation attempt changed');
    original[String(row.index)]={operation_id:row.operation_id,points:Math.max(prior?.points??0,row.points)};
    if(!proofs.has(row.operation_id)){const op=loadProduction(root,row.operation_id);proofs.set(row.operation_id,{latest:op.not_submitted_id??null,history:unsubmittedHistory(root,op)});}
    const proof=proofs.get(row.operation_id),atReservation=row.not_submitted_id??null;
    assert(proof.history.has(atReservation),'Reservation disposition changed');
    // Only a later, append-only proof of no invocation releases this reservation.
    // Unknown/accepted/failed/completed calls cannot create such proof.
    if(proof.latest!==atReservation)continue;
    const active=reserved[String(row.index)];
    reserved[String(row.index)]={operation_id:row.operation_id,points:Math.max(active?.points??0,row.points)};
  }
  for(const [index,row]of Object.entries(r.reservations??{}))assert(original[index]?.operation_id===row.operation_id&&original[index].points>=row.points,'Budget progress has no original reservation');
  r.reservations=reserved;return r;
}
function persist(root,r){r.updated_at=new Date().toISOString();save(root,base(r.batch_id)+'/batch.json',r);}
function assertSources(root,item){for(const f of item.files)assert(fact(root,f.path).sha256===f.sha256,'Batch input changed; prepare a new explicit batch');}
async function videoItem(root,path){
  const descriptor=json(root,path);
  assert(descriptor.schema_version===1&&typeof descriptor.clip_id==='string'&&typeof descriptor.generation_intent==='string'&&descriptor.generation_intent&&Number.isSafeInteger(descriptor.attempt)&&descriptor.attempt>0&&!descriptor.batch_id,'Invalid video item descriptor');
  const c=await business.videoSelection(root,descriptor.clip_id);
  assertVideoProvider(c.project);
  const request=business.buildVideoQuoteRequest(c.request,c.previous).input;
  return {target:descriptor.clip_id,previous:c.previous??'',binding:c.reviewBinding,template:c.request,request,
    pricing:business.videoPricingParameters(request),files:[fact(root,path),...c.media.map(m=>fact(root,m.path))]};
}
async function assertVideoItem(root,item){
  assertSources(root,item);const current=await videoItem(root,item.input);
  assert(current.previous===item.previous&&hash(current.template)===hash(item.template)&&await business.matchingVideoBinding(root,await business.videoSelection(root,item.target),hash(item.binding)),'Batch video inputs changed');
  return current;
}
async function initialize(root,stage,input,{preview=false}={}){
  const d=json(root,input);assert(d.schema_version===1&&Array.isArray(d.items)&&d.items.length>0&&d.items.length<=1000&&Object.keys(d).every(k=>['schema_version','items','concurrency'].includes(k)),'Use a batch descriptor with items[{input,attempt?,retry_of?}]');
  const concurrency=d.concurrency??2;assert(Number.isInteger(concurrency)&&concurrency>=1&&concurrency<=4,'Concurrency must be 1..4');
  const items=[],targets=new Set();
  for(const raw of d.items){
    assert(raw&&typeof raw.input==='string'&&Object.keys(raw).every(k=>['input','attempt','retry_of'].includes(k)),'Invalid batch item');
    const inputFile=fact(root,raw.input),descriptor=json(root,inputFile.path);
    const details=stage==='video'?await videoItem(root,inputFile.path):{target:descriptor.asset_id,kind:descriptor.kind,files:[inputFile]};
    const targetKey=stage==='video'?details.target:details.kind+':'+details.target;
    assert(typeof details.target==='string'&&!targets.has(targetKey),'Duplicate batch target');targets.add(targetKey);
    const attempt=raw.attempt??'initial';assert(/^[A-Za-z0-9_-]{1,128}$/.test(attempt),'Invalid attempt');
    if(raw.retry_of)assert(/^[a-f0-9]{64}$/.test(raw.retry_of),'Invalid predecessor');
    items.push({input:inputFile.path,attempt,...(raw.retry_of?{retry_of:raw.retry_of}:{}),...details});
  }
  // Dependency cycles or a changed template cannot silently produce an empty scheduler.
  for(const item of items){const seen=new Set([item.target]);let previous=item.previous;while(previous&&targets.has(previous)){assert(!seen.has(previous),'Video dependency cycle');seen.add(previous);previous=items.find(i=>i.target===previous).previous;}}
  const plan={schema_version:1,project:resolve(root),stage,concurrency,source:fact(root,input),items},id=hash(plan);
  if(preview)return {ok:true,read_only:true,batch_id:id,plan};
  if(exists(root,base(id)+'/batch.json'))return load(root,id);
  const r={schema_version:1,transport:'public-cli-batch-v1',batch_id:id,project:resolve(root),plan,items:items.map(()=>({})),reservations:{}};
  immutable(root,base(id)+'/plan.json',plan);persist(root,r);return r;
}
function currentQuote(root,r,index){const state=r.items[index],op=opFor(root,state);return state.quote_only?state.quote:op?productionStatus(op).quote:state.quote;}
function dependency(root,r,index){
  const item=r.plan.items[index];if(!item.previous)return null;
  const previous=r.plan.items.findIndex(i=>i.target===item.previous);if(previous<0)return null;
  const op=opFor(root,r.items[previous]);
  if(op?.state!=='completed')return {index:previous,clip_id:item.previous,code:op?.state==='terminal'?'BATCH_PREVIOUS_FAILED':'BATCH_PREVIOUS_PENDING',next_action:op?.state==='terminal'?'prepare_authorized_successor_batch':'wait_for_previous_clip'};
  const expected=`VIDEO-${op.operation_id}-0`,selected=json(root,'.pipeline-state/project.json').selected_runs?.[item.previous]??null;
  if(selected!==expected)return {index:previous,clip_id:item.previous,code:'BATCH_PREVIOUS_SELECTION_REQUIRED',next_action:'adopt_batch_previous_run',expected_run_id:expected,selected_run_id:selected};
  return null;
}
async function assertPrevious(root,r,index,current){
  const blocked=dependency(root,r,index);if(blocked)throw fail(blocked.code,blocked.next_action);
  const item=r.plan.items[index],previous=r.plan.items.findIndex(i=>i.target===item.previous);
  if(!item.previous||previous<0)return;
  const expected=`VIDEO-${opFor(root,r.items[previous]).operation_id}-0`,tail=await business.adoptedVideoTail(root,item.previous);
  assert(tail.run_id===expected,'Batch predecessor changed');
  if(current&&(current.plan.metadata.tail?.run_id!==expected||current.plan.metadata.tail?.sha256!==tail.sha256))throw fail('BATCH_PREVIOUS_INPUT_CHANGED','原待提交输入绑定了另一前序版本；保留原操作，使用新 attempt 准备新批次。');
}
function proposal(root,r){
  const items=r.plan.items.map((item,index)=>{
    const state=r.items[index],op=opFor(root,state),quote=currentQuote(root,r,index),fees=feeSummary(quote);
    return {index,target:item.target,operation_id:op?.operation_id??null,quote:quote??null,quote_key:fees.cost_points===null?null:quoteKey(quote),cost_points:fees.cost_points,
      ...(state.quote_only?{quote_only:true}:{}),
      ...(state.quote_only&&state.quote_evidence?{quote_evidence:state.quote_evidence}:op&&productionStatus(op).quote_evidence?{quote_evidence:op.quote_evidence}:{}),
      ...(!op&&!state.quote_only&&state.quote_evidence?{quote_evidence:state.quote_evidence}:{}),
      binding:hash(item),input_sha256:state.quote_only?null:op?.input_sha256??null,state:state.quote_only?(state.error?'quote_failed':quote?'quoted':'quote_pending'):op?.state??'pending',error:state.quote_only?state.error??null:['completed','terminal'].includes(op?.state)?null:state.error??op?.error??null};
  });
  const pending=items.filter(item=>!['completed','terminal'].includes(item.state));
  const ready=pending.length>0&&pending.every(item=>!item.error&&item.cost_points!==null&&(r.plan.stage==='video'||item.input_sha256||item.quote_only&&inquiryPolicies.has(item.quote_evidence?.policy))&&!inFlight.has(item.state));
  const total=items.every(item=>!item.error&&item.cost_points!==null)?sum(items.map(item=>item.cost_points)):null;
  return {schema_version:1,batch_id:r.batch_id,plan_sha256:r.batch_id,items,approval_ready:ready,total_points:total};
}
export function batchStatus(root,id){
  const r=load(root,id),p=proposal(root,r);
  const items=p.items.map(item=>{
    const op=opFor(root,r.items[item.index]),authorized=!!r.items[item.index].authorization_id;
    const generationDependency=!inFlight.has(item.state)&&!['completed','terminal'].includes(item.state)?dependency(root,r,item.index):null;
    const blocked=authorized?generationDependency:null;
    const repair=item.error?.code==='BATCH_PRICE_CHANGED'?'prepare_and_approve_batch':['BATCH_PREVIOUS_INPUT_CHANGED','PUBLIC_INPUT_CHANGED'].includes(item.error?.code)?'prepare_new_unsubmitted_batch':'repair_and_retry_item';
    const next_action=item.state==='completed'?'continue_authorized_scope':item.state==='terminal'?'prepare_authorized_successor_batch':inFlight.has(item.state)?'resume_original_operation':blocked?.next_action??(!authorized?(p.approval_ready?'approve_batch':'prepare_batch'):item.error?repair:'step_batch');
    return {...item,...(op?{operation:productionStatus(op)}:{}),authorized,generation_dependency:generationDependency,blocked_by:blocked,next_action};
  });
  const reserved=sum(Object.values(r.reservations).map(v=>v.points));
  const completed=items.every(i=>i.state==='completed'),canStep=items.some(i=>['step_batch','resume_original_operation'].includes(i.next_action));
  const next=canStep?'step_batch':items.some(i=>i.state==='terminal')?'prepare_authorized_successor_batch':items.some(i=>i.blocked_by?.code==='BATCH_PREVIOUS_SELECTION_REQUIRED')?'adopt_batch_previous_run':p.approval_ready?'approve_batch':'repair_or_prepare_batch';
  return {ok:items.every(i=>i.state!=='terminal'&&!i.error&&(!i.operation?.error||i.quote_only)&&!i.blocked_by?.code?.includes('SELECTION_REQUIRED')),batch_id:id,stage:completed?'completed':canStep?'pending':p.approval_ready&&items.some(i=>i.quote_only)?'quoted':'needs_attention',items,
    completed:items.filter(i=>i.state==='completed').length,total:items.length,approval_ready:p.approval_ready,
    proposal:p,proposal_sha256:hash(p),total_points:p.total_points,reserved_points:reserved,budget_points:r.budget_points??null,
    notice:'批次预算是本地提交上限；仅明确未提交证据可解除预留，未知提交及已提交失败仍保留，不代表实际扣费。',next_action:completed?'continue_authorized_scope':next};
}
async function batchFees(root,r,host){
  const status=batchStatus(root,r.batch_id);let balance={available:false};
  try{const value=await host.queryBalance();if(Number.isFinite(Number(value.totalBalance))&&value.totalBalance!==null)balance={available:true,points:Number(value.totalBalance),checked_at:value.checked_at};}catch{}
  const insufficient=status.items.some(item=>item.error?.recharge||!item.error&&item.quote?.enoughBalance===false);
  const fees=feeSummary({estimatedPoints:status.total_points,billable:status.total_points!==0,...(insufficient?{enoughBalance:false}:{})},balance);
  if(status.total_points!==null&&status.items.some(item=>feeSummary(item.quote).cost_kind==='maximum')){
    fees.cost_kind='maximum';fees.notice='整批按各项最高费用与普通预计费用合计估算；各项结算合同保留在 items[].quote，不代表实际扣费。';
  }
  return {...status,fees};
}
async function quoteAssets(root,r,host){
  const pending=r.plan.items.map((item,index)=>({item,index})).filter(({index})=>{
    const op=opFor(root,r.items[index]);return !op||!inFlight.has(op.state)&&!['completed','terminal'].includes(op.state);
  });
  // Invalidate the previous inquiry before any asynchronous work. Original
  // operations, accepted jobs and immutable approval records remain untouched.
  for(const {index}of pending){const state=r.items[index];state.quote_only=true;delete state.quote;delete state.quote_evidence;delete state.authorization_id;delete state.error;}
  persist(root,r);
  const groups=new Map(),contracts=new Map(),round=randomUUID();
  try{
    if(pending.length){
      const access=await host.cli(['check']);if(access.code!==0)throw fail('PUBLIC_ACCESS_NOT_READY');
      for(const entry of pending){
        const state=r.items[entry.index];
        try{
          assertSources(root,entry.item);const d=json(root,entry.item.input);
          assert(d.schema_version===1&&d.kind===entry.item.kind&&d.asset_id===entry.item.target&&d.parameters&&typeof d.parameters==='object'&&!Array.isArray(d.parameters),'Invalid material descriptor');
          const operator=materialOperators[d.kind];assert(operator,'Unsupported material kind');
          if(!contracts.has(operator)){
            contracts.set(operator,(async()=>{
              const detail=await host.cli(['describe',operator,'--json']);if(detail.code!==0)throw fail('PUBLIC_DESCRIBE_FAILED');
              const contract=detail.json?.data??detail.json;assert(!contract.apiCode||contract.apiCode===operator,'Operator description mismatch');return contract;
            })());
          }
          const contract=await contracts.get(operator),input=inquiryInput(d);business.validateAssetSchema(contract.inputSchema,input);
          if(d.kind==='image')assert(typeof input.prompt==='string'&&input.prompt.trim(),'Image prompt required');
          const group=materialQuoteGroup(d.kind,input,'fixed-call'),key=hash({kind:d.kind,group});
          if(!groups.has(key))groups.set(key,{kind:d.kind,operator,members:[]});groups.get(key).members.push({...entry,input});
        }catch(error){state.error={code:error.code??'ASSET_QUOTE_INPUT_INVALID',message:'修正本项计费参数或询价输入后重新询价。'};}
      }
      for(const {kind,operator,members}of groups.values()){
        try{
          let shared;
          for(const member of members){
            if(!shared){
              const path=base(r.batch_id)+`/inquiries/${round}/input-${member.index}.json`;immutable(root,path,member.input);
              const result=await host.cli(['quote',operator,'--json','--json-file',resolve(root,path)]);
              if(result.code!==0)throw Object.assign(fail('PUBLIC_QUOTE_FAILED'),{recharge:rechargeForFailure(result)});
              const quote=preparationQuote(result),pricing=kind==='voice-design'&&fixedVoiceQuote(quote)?'fixed-call':'exact-input';
              const evidence={schema_version:1,policy:kind==='image'?'image-inquiry-v1':'material-inquiry-v1',batch_id:r.batch_id,round,
                ...(kind==='image'?{}:{kind,operator,pricing}),group:materialQuoteGroup(kind,member.input,pricing),
                representative_input:path,representative_input_sha256:hash(member.input),checked_at:new Date().toISOString()};
              shared={quote,quote_evidence:evidence};
            }
            assertSources(root,member.item);Object.assign(r.items[member.index],shared);
            // Only the platform's fixed-call voice quote can ignore description
            // and preview text. Usage/unknown pricing is quoted per actual input.
            if(kind!=='image'&&!(kind==='voice-design'&&fixedVoiceQuote(shared.quote)))shared=null;
          }
        }catch(error){for(const {index}of members){const state=r.items[index];delete state.quote;delete state.quote_evidence;state.error={code:error.code??'PUBLIC_QUOTE_FAILED',message:'本组报价暂不可用，重新询价后再确认费用。',...(error.recharge?{recharge:error.recharge}:{})};}}
        persist(root,r);
      }
    }
  }catch(error){for(const {index}of pending){const state=r.items[index];delete state.quote;delete state.quote_evidence;state.error={code:error.code??'PUBLIC_DESCRIBE_FAILED',message:'接入或参数合同不可用，修复后重新询价。'};}}
  persist(root,r);return batchFees(root,r,host);
}
async function prepareBatch(root,r,host,{refreshQuotes=false}={}){
  let videoDetail;
  const describeVideo=()=>videoDetail??=host.cli(['describe','op.video.generate','--json']);
  const images=r.plan.stage==='material'&&r.plan.items.every(item=>item.kind==='image'),shared=new Map();let balance;
  const preparationHost=imageBatchQuoteHost(root,r.batch_id,{...host,
    queryBalance:()=>images?(balance??=host.queryBalance()):host.queryBalance(),
    cli:(args,...rest)=>{
      if(r.plan.stage==='video'&&args[0]==='describe'&&args[1]==='op.video.generate')return describeVideo();
      if(images&&(args[0]==='check'||args[0]==='describe'&&args[1]==='op.image.generate')){
        const key=JSON.stringify(args);if(!shared.has(key))shared.set(key,host.cli(args,...rest));return shared.get(key);
      }
      return host.cli(args,...rest);
    }});
  const pendingVideos=r.plan.stage==='video'?r.plan.items.map((item,index)=>({item,index})).filter(({index})=>!opFor(root,r.items[index])):[];
  if(pendingVideos.length){
    const resume=r.video_quote_incomplete===true&&!refreshQuotes;
    if(!resume||!r.video_quote_round)r.video_quote_round=randomUUID();
    r.video_quote_incomplete=true;persist(root,r);
    let cache,detail;
    try{
      // Finish discovery/binding before parallel quotes; share only this round's
      // contract. Every actual request is still validated and quoted separately.
      detail=await describeVideo();if(detail.code!==0)throw fail('PUBLIC_DESCRIBE_FAILED');
      cache=videoBatchQuotes(root,r.batch_id,stripped(detail.json),{resume,round:r.video_quote_round});
    }catch(error){
      for(const {index}of pendingVideos)r.items[index].error={code:error.code??'BATCH_ITEM_PREPARE_FAILED',phase:'describe',message:'修正此项后再次准备；已成功项与原任务保留。'};
      persist(root,r);
    }
    if(cache){
      let cursor=0;
      const prepareNext=async()=>{
        const {item,index}=pendingVideos[cursor++],state=r.items[index];
        let phase='validate_input';
        try{
          await assertVideoItem(root,item);
          phase='input_schema';
          business.validateAssetSchema((detail.json?.data??detail.json).inputSchema,item.request);
          const input=base(r.batch_id)+`/quote-input-${index}.json`;immutable(root,input,item.request);
          phase='quote_cache';
          let receipt=cache.get(state,item.request);const reused=!!receipt;
          if(!receipt){
            phase='quote_request';
            const result=await host.cli(['quote','op.video.generate','--json','--json-file',resolve(root,input)]);
            if(result.code!==0)throw Object.assign(fail('BATCH_ITEM_PREPARE_FAILED'),{recharge:rechargeForFailure(result)});
            phase='quote_parse';const quote=preparationQuote(result);
            phase='revalidate_input';
            await assertVideoItem(root,item);
            phase='quote_save';
            const saved=cache.save(item.request,quote);state.video_quote_receipt=saved.id;receipt=saved.receipt;
          }
          state.quote=receipt.quote;state.quote_evidence={policy:'exact-video-input-v1',request_sha256:receipt.request_sha256,
            quoted_at:receipt.quoted_at,expires_at:receipt.expires_at,reused};delete state.error;
        }catch(error){state.error={code:error.code??'BATCH_ITEM_PREPARE_FAILED',phase,message:'修正此项后再次准备；已成功项与原任务保留。',...(error.recharge?{recharge:error.recharge}:{})};}
        persist(root,r);
      };
      // The first public quote creates a new project's workflow. Do not race
      // its exclusive creation with another quote using a different fresh ID.
      while(cursor<pendingVideos.length&&!exists(root,'skill-business-context.json'))await prepareNext();
      const worker=async()=>{while(cursor<pendingVideos.length)await prepareNext();};
      // Drain every worker before releasing the scheduler lock, even on disk errors.
      const workers=await Promise.allSettled(Array.from({length:Math.min(r.plan.concurrency,pendingVideos.length)},worker));
      for(const result of workers)if(result.status==='rejected')throw result.reason;
      for(const {index}of pendingVideos){const state=r.items[index];
        if(!state.error&&Date.parse(state.quote_evidence.expires_at)<=Date.now())state.error={code:'VIDEO_QUOTE_EXPIRED',message:'报价已过期，请重新准备。'};
      }
      try{cache.unchanged();}catch(error){for(const {index}of pendingVideos)r.items[index].error={code:'BATCH_QUOTE_CONTEXT_CHANGED',message:'执行环境或项目已变化，请重新准备。'};}
    }
  }
  for(const [index,item]of r.plan.items.entries()){
    const state=r.items[index],op=opFor(root,state);
    if(r.plan.stage==='video'&&!op)continue;
    if(op&&(inFlight.has(op.state)||['completed','terminal'].includes(op.state)))continue;
    if(state.quote_only){delete state.quote_only;delete state.quote;delete state.quote_evidence;}
    try{
      assertSources(root,item);
      if(r.plan.stage==='video')await assertVideoItem(root,item);
      const result=op?await continueProduction(root,op.operation_id,'prepare',preparationHost):await prepareProduction(root,'material',item.input,preparationHost,{attempt:item.attempt,retryOf:item.retry_of});
      if(result.operation_id)state.operation_id=result.operation_id;
      if(!result.ok)throw Object.assign(fail(result.error?.code??'BATCH_ITEM_PREPARE_FAILED'),{recharge:result.error?.recharge});
      delete state.error;
    }catch(error){state.error={code:error.code??'BATCH_ITEM_PREPARE_FAILED',message:'修正此项后再次准备；已成功项与原任务保留。',...(error.recharge?{recharge:error.recharge}:{})};}
    persist(root,r);
  }
  if(r.plan.stage==='video'){r.video_quote_incomplete=!proposal(root,r).approval_ready;persist(root,r);}
  return batchFees(root,r,preparationHost);
}
function approve(root,r,path){
  const a=json(root,path),p=proposal(root,r);
  assert(p.approval_ready&&a.schema_version===1&&a.approved===true&&a.batch_id===r.batch_id&&a.proposal_sha256===hash(p)&&Number.isFinite(Date.parse(a.approved_at)),'Approve the current complete batch proposal');
  const limit=a.max_points??p.total_points;units(limit);
  const selected=p.items.filter(i=>!['completed','terminal'].includes(i.state));
  for(const approved of selected)if(approved.quote_only){
    const item=r.plan.items[approved.index],evidence=approved.quote_evidence;assertSources(root,item);
    const input=json(root,evidence.representative_input);
    assert(inquiryPolicies.has(evidence.policy)&&evidence.batch_id===r.batch_id&&hash(input)===evidence.representative_input_sha256&&
      hash(materialQuoteGroup(item.kind,input,evidence.pricing))===hash(evidence.group)&&
      hash(materialQuoteGroup(item.kind,inquiryInput(json(root,item.input)),evidence.pricing))===hash(evidence.group),'Material inquiry evidence changed');
    if(evidence.pricing==='fixed-call')assert(item.kind==='voice-design'&&fixedVoiceQuote(approved.quote),'Invalid fixed-call voice quote');
  }
  const commitments={...r.reservations};for(const item of selected)commitments[String(item.index)]={points:Math.max(commitments[String(item.index)]?.points??0,item.cost_points)};
  assert(sum(Object.values(commitments).map(v=>v.points))<=limit,'Batch budget too small');
  const authorization={schema_version:1,batch_id:r.batch_id,proposal:p,max_points:limit,approved_at:a.approved_at,approved:true};
  const id=hash(authorization);immutable(root,base(r.batch_id)+`/approval-${id}.json`,authorization);
  for(const item of selected){r.items[item.index].authorization_id=id;delete r.items[item.index].error;}
  r.budget_points=limit;persist(root,r);return {...batchStatus(root,r.batch_id),authorization_id:id,next_action:'step_batch'};
}
async function step(root,r,host){
  // Recovery is independent of budget, stale quotation and changed new-production inputs.
  const recoverable=r.items.filter(item=>item.operation_id&&inFlight.has(loadProduction(root,item.operation_id).state));
  for(let offset=0;offset<recoverable.length;offset+=r.plan.concurrency){
    await Promise.all(recoverable.slice(offset,offset+r.plan.concurrency).map(async item=>{
      try{const result=await continueProduction(root,item.operation_id,'resume',host);if(result.error)item.error=result.error;else delete item.error;}
      catch(error){item.error={code:error.code??'BATCH_RECOVERY_FAILED',message:'继续查询或接入原任务，不重新提交。'};}
      persist(root,r);
    }));
  }
  // Each item gets at most one attempt per step. A pre-dispatch failure releases
  // this round's slot so later independent work is not starved by list ordering.
  const attempted=new Set();
  while(attempted.size<r.plan.items.length){
    // Remote success awaiting local intake still needs recovery and duplicate
    // protection, but no longer consumes a generation slot or releases budget.
    const count=operations(root).filter(op=>inFlight.has(op.state)&&op.state!=='result_pending').length;
    let slots=Math.max(0,r.plan.concurrency-count);const selected=[];
    for(const [index,item]of r.plan.items.entries()){
      const state=r.items[index],op=opFor(root,state);
      if(!slots||attempted.has(index)||!state.authorization_id||op&&(inFlight.has(op.state)||['completed','terminal'].includes(op.state)))continue;
      if(dependency(root,r,index))continue;
      selected.push({index,item,state});attempted.add(index);slots--;
    }
    if(!selected.length)break;
    await Promise.all(selected.map(async({index,item,state})=>{
      try{
        const a=json(root,base(r.batch_id)+`/approval-${state.authorization_id}.json`);assert(hash(a)===state.authorization_id&&a.batch_id===r.batch_id,'Batch authorization changed');
        const approved=a.proposal.items.find(i=>i.index===index);assert(approved&&approved.binding===hash(item),'Item outside batch approval');
        assertSources(root,item);if(r.plan.stage==='video'){await assertVideoItem(root,item);await assertPrevious(root,r,index);}
        let op=opFor(root,state);
        if(!op||['preparing','awaiting_manifest_review'].includes(op.state)){
          const prepared=op?await continueProduction(root,op.operation_id,'prepare',host):await prepareProduction(root,r.plan.stage,item.input,host,{attempt:item.attempt,retryOf:item.retry_of});
          if(prepared.operation_id)state.operation_id=prepared.operation_id;persist(root,r);
          if(!prepared.ok)throw Object.assign(fail(prepared.error?.code??'BATCH_ITEM_PREPARE_FAILED'),{recharge:prepared.error?.recharge});op=opFor(root,state);
        }
        if(!op||!['ready','confirmation_required'].includes(op.state)){if(op&&!op.error)delete state.error;persist(root,r);return;}
        if(state.quote_only){delete state.quote_only;delete state.quote;delete state.quote_evidence;persist(root,r);}
        const guard=async current=>{
          if(r.plan.stage==='video'){await assertVideoItem(root,item);await assertPrevious(root,r,index,current);}
          // Compare terms from the preserved original approval, including v1 approvals.
          if(quoteKey(approved.quote)!==quoteKey(productionStatus(current).quote))throw fail('BATCH_PRICE_CHANGED','重新询价并批准当前费用。');
          if(r.plan.stage==='video')assert(hash(business.videoPricingParameters(json(root,`.pipeline-state/runtime/public-production/${current.operation_id}/input.json`)))===hash(item.pricing),'Video pricing parameters changed');
          else if(approved.quote_only){
            const evidence=approved.quote_evidence;
            assert(inquiryPolicies.has(evidence?.policy)&&current.plan.operator===materialOperators[item.kind],'Invalid material inquiry approval');
            if(item.kind!=='image')assert((current.quote?.chargeType??null)===(approved.quote?.chargeType??null),'Material pricing mode changed');
            if(evidence.pricing==='fixed-call')assert(item.kind==='voice-design'&&fixedVoiceQuote(current.quote),'Voice pricing mode changed');
            assert(hash(materialQuoteGroup(item.kind,json(root,`.pipeline-state/runtime/public-production/${current.operation_id}/input.json`),evidence.pricing))===hash(evidence.group),'Approved material pricing parameters changed');
            assert(current.plan.files.some(file=>file.path===item.input&&file.sha256===item.files[0].sha256),'Approved material descriptor changed');
          }else assert(approved.input_sha256===current.input_sha256,'Approved material input changed');
          r.reservations=load(root,r.batch_id).reservations;
          const prior=r.reservations[String(index)];assert(!prior||prior.operation_id===current.operation_id,'Batch attempt changed');
          const reservations={...r.reservations,[String(index)]:{operation_id:current.operation_id,points:Math.max(prior?.points??0,approved.cost_points)}};
          const total=sum(Object.values(reservations).map(v=>v.points));assert(total<=r.budget_points&&total<=a.max_points,'Batch budget exceeded');
          const receipt={schema_version:1,batch_id:r.batch_id,index,operation_id:current.operation_id,authorization_id:state.authorization_id,points:approved.cost_points,not_submitted_id:current.not_submitted_id??null};
          immutable(root,base(r.batch_id)+`/reservations/${hash(receipt)}.json`,receipt);
          r.reservations=reservations;persist(root,r);
        };
        let result=await continueProduction(root,op.operation_id,'submit',host,{submissionGuard:guard});
        if(result.code===3&&result.cli){
          const confirmation=confirmationFrom(result.cli.stderr??'');assert(confirmation,'Missing original CLI confirmation');
          if(quoteKey(result.quote)!==quoteKey(approved.quote))throw fail('BATCH_PRICE_CHANGED','重新询价并批准当前费用。');
          result=await continueProduction(root,op.operation_id,'submit',host,{confirm:confirmation.confirmation_token,submissionGuard:guard});
        }
        if(!result.ok||result.code===3)throw Object.assign(fail(result.error?.code??'BATCH_ITEM_NEEDS_ATTENTION'),{recharge:result.error?.recharge});
        delete state.error;
      }catch(error){state.error={code:error.code??'BATCH_ITEM_NEEDS_ATTENTION',message:'核对本项输入、报价或授权后继续；原在途任务只恢复，不重新提交。',...(error.recharge?{recharge:error.recharge}:{})};}
      persist(root,r);
    }));
  }
  r.reservations=load(root,r.batch_id).reservations;persist(root,r);
  return batchStatus(root,r.batch_id);
}
export async function batchEntry(root,action,tokens,host){
  const values={},flags=new Set();for(let i=0;i<tokens.length;i++){
    const key=tokens[i];assert(!Object.hasOwn(values,key)&&!flags.has(key),'Duplicate batch argument');
    if(key==='--no-write'||key==='--local-only'||key==='--refresh-quotes'){flags.add(key);continue;}
    assert(['--input','--batch-id','--approval'].includes(key),'Use --input, --batch-id or --approval');const value=tokens[++i];assert(value&&!value.startsWith('--'),'Missing batch argument');values[key]=value;
  }
  assert(!flags.has('--refresh-quotes')||action==='prepare-video-batch','--refresh-quotes requires prepare-video-batch');
  const stage=action.includes('video')?'video':'material',id=values['--batch-id'];
  if(action.endsWith('-status')){assert(id,'Batch ID required');const r=load(root,id);assert(r.plan.stage===stage,'Batch stage differs');return batchStatus(root,id);}
  const preview=flags.has('--no-write')||flags.has('--local-only');
  if(preview){assert(values['--input'],'Preview requires --input');return initialize(root,stage,values['--input'],{preview:true});}
  return withProductionWriter(root,async()=>{
    const r=id?load(root,id):await initialize(root,stage,values['--input']);assert(r.plan.stage===stage,'Batch stage differs');
    if(action==='plan-video-batch')return {...batchStatus(root,r.batch_id),plan:r.plan,next_action:'prepare-video-batch'};
    if(action==='activate-asset-batch'||action==='approve-video-batch')return approve(root,r,values['--approval']);
    if(action.startsWith('step-'))return step(root,r,host);
    if(action==='quote-asset-batch')return quoteAssets(root,r,host);
    return prepareBatch(root,r,host,{refreshQuotes:flags.has('--refresh-quotes')});
  });
}
