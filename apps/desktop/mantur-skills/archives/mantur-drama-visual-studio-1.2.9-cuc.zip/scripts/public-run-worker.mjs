// Supervise the public CLI until its output pipes close, independently of the host.
// Importing a CLI module does not wait for an asynchronously started main().
import {spawn} from 'node:child_process';
import {ownProcessIdentity} from '../runtime/process-identity.mjs';
import {save,hash,stripped} from './production-state.mjs';
import {confirmationFrom} from './cli-client.mjs';
let started=false,stdout='',stderr='',bytes=0,overflow=false,context;
const writable={stdout:true,stderr:true};
for(const stream of ['stdout','stderr'])process[stream].on('error',()=>{writable[stream]=false;});
function persist(value){if(context)save(context.root,context.path,{...context.binding,...value});}
process.on('disconnect',()=>{if(!started)process.exit(1);});
function finish(code,signal){
  code=overflow||signal||!Number.isInteger(code)?1:code;
  let json;try{json=JSON.parse(stdout);}catch{}
  const confirmation=confirmationFrom(stderr),recovery=/调用恢复 ID:\s*([a-f0-9-]{36})/i.exec(stderr)?.[1];
  persist({state:'finished',code,json:stripped(json),recovery_id:recovery,
    ...(confirmation?{confirmation_sha256:hash(confirmation.confirmation_token)}:{}),
    pre_submit_failure:!recovery&&code===1&&/报价已变化或确认标识无效|报价响应缺少 priceVersionTag|参数校验失败:|余额不足：/.test(stderr)});
  process.exitCode=code;
  // Deliver while the event loop is alive; exit handlers cannot flush an IPC message.
  if(process.connected)try{
    process.send({type:'result',result:{code,stdout,stderr}},()=>{if(process.connected)process.disconnect();});
  }catch{if(process.connected)process.disconnect();}
}
process.once('message',message=>{
  if(message?.type!=='go'||!Array.isArray(message.args)||message.args[0]!=='run'||!message.args.includes('--no-wait')||message.args.includes('--file'))process.exit(1);
  context=message.context;started=true;persist({state:'running'});
  // Keep the exact entry, arguments and environment selected by the unified adapter.
  const cli=spawn(process.execPath,[message.entry,...message.args],{env:process.env,stdio:['ignore','pipe','pipe'],windowsHide:true});
  let recovery,forceTimer;
  const stop=()=>{cli.kill();forceTimer??=setTimeout(()=>cli.kill('SIGKILL'),2000);forceTimer.unref();};
  const timer=setTimeout(stop,300_000);timer.unref();
  for(const stream of ['stdout','stderr']){
    cli[stream].setEncoding('utf8');
    cli[stream].on('data',text=>{
      bytes+=Buffer.byteLength(text);
      if(bytes>4_000_000){overflow=true;stop();return;}
      if(stream==='stdout')stdout+=text;else stderr+=text;
      const id=/调用恢复 ID:\s*([a-f0-9-]{36})/i.exec(stderr)?.[1];
      if(id&&id!==recovery){recovery=id;persist({state:'running',recovery_id:recovery});}
      if(writable[stream])process[stream].write(text);
    });
  }
  cli.on('error',error=>{stderr+='\nCLI process error: '+error.message;});
  cli.once('close',(code,signal)=>{clearTimeout(timer);clearTimeout(forceTimer);finish(code,signal);});
});
process.send({type:'ready',pid:process.pid,identity:(await ownProcessIdentity()).identity});
