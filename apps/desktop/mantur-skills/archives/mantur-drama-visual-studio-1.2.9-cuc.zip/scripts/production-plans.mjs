import assert from 'node:assert/strict';
import * as business from '../runtime/public-business.mjs';
import {fact,json,hash,fail,immutable} from './production-state.mjs';

const materials={image:'op.image.generate',understanding:'op.video.understand-v2','voice-design':'op.voice.design',audio:'op.audio.generate'};
const projectFact=(root,path)=>fact(root,path);
// Call after videoSelection validates the archived report, model and media.
// Interpret an omitted legacy field without changing its historical binding.
export function assertVideoProvider(project){
  assert(project.video_provider===undefined||project.video_provider==='manturhub:op.video.generate','Video provider changed');
}
export async function planProduction(root,stage,path,host,observations={},frozenPlan){
  const descriptor=json(root,path),source=projectFact(root,path),project=json(root,'.pipeline-state/project.json');
  if(stage==='extraction'){
    const p=await business.planAssetExtraction(root,path);
    const sources=await business.inspectSourceState(root);business.requireSources(sources);
    if(sources.sources.clipCompileReport||sources.sources.videoResults.length||sources.sources.normalizedRuns||sources.sources.deliveries)throw fail('EXTRACTION_DOWNSTREAM_EXISTS','已有下游产物；保留原项目并使用原结果，不重新提取。');
    return {stage,operator:'op.drama.asset-extract',target:'project',files:p.files,uploads:p.files.slice(1).map(f=>({path:f.path})),
      parameters:p.d.parameters??{},metadata:{script:p.d.script,episodes:p.scope,references:p.d.reference_images??[],style:p.style?.prompt??null}};
  }
  if(stage==='material'){
    const p=await business.planAssetOperation(root,path,{validateReferences:host.validateReferences});
    const parameters={...p.d.parameters};
    if(p.kind==='image')parameters.prompt=business.appendCreativeStyleText([parameters.prompt,...(p.plan?.guards??[])].join('\n'),p.style?.prompt);
    // URL-based operator modes require a supplied public reference. The CLI has no fileId-to-URL command.
    if(p.kind==='understanding'||p.kind==='audio')for(const ref of p.refs){
      if(!ref.remote_url)throw fail('PUBLIC_REFERENCE_URL_REQUIRED','此模式需要已有公开媒体 URL；当前 CLI 不提供文件 URL 查询。可使用无需参考音频的生成模式，或提供与本地原件匹配的公开媒体。');
      const url=new URL(ref.remote_url);assert(url.protocol==='https:'&&!url.username&&!url.password&&!url.search&&!url.hash,'Use a stable public URL without credentials or a signed query');
    }
    const files=[source,...p.refs.map(ref=>({path:ref.original,sha256:ref.fact.sha256,bytes:ref.fact.bytes}))];
    if(p.d.reference_manifest)files.push(fact(root,p.d.reference_manifest));
    business.assetInput(p.kind,parameters,p.refs.map(r=>({kind:r.fact.kind,fileId:'validation-only',url:r.remote_url})));
    const voiceBaseline=['voice-design','audio'].includes(p.kind)&&frozenPlan?.metadata.baseline!==null?await business.assetSelectionBaseline(root,p.d.asset_id,true):null;
    return {stage,operator:materials[p.kind],target:p.d.asset_id,files,uploads:p.kind==='image'?p.refs.map(ref=>({path:ref.original})):[],parameters,
      metadata:{kind:p.kind,asset_id:p.d.asset_id,target_hash:p.p.targetHash,voice:p.kind==='voice-design'||p.kind==='audio',
        ...(p.kind==='image'&&p.d.generation_intent?{generation_intent:p.d.generation_intent}:{}),
        refs:p.refs.map(ref=>({path:ref.original,kind:ref.fact.kind,url:ref.remote_url??null})),
        reference_base_sha256:p.kind==='image'&&p.p.base!==p.d.asset_id?p.refs[0]?.fact.sha256:null,
        baseline:p.kind==='image'?await business.imageSelectionBaseline(root,p.d.asset_id):
          voiceBaseline?{target_hash:voiceBaseline.target_hash,expected_previous_sha256:voiceBaseline.expected_previous_sha256}:null}};
  }
  if(stage==='clips'&&descriptor.production_asset_table){
    assert(descriptor.schema_version===1&&Object.keys(descriptor).every(k=>['schema_version','script','production_asset_table','episodes','parameters','media_mapping'].includes(k)),'Invalid WAN descriptor');
    const inspection=await business.inspectWanAssetTable(root,descriptor.production_asset_table);
    assert(inspection.explicit_voice_bindings_ready,'Expand the approved voice bindings before preparing WAN');
    const scope=await business.assertProjectEpisodeScope(root,project),episodes=descriptor.episodes??scope;
    assert(Array.isArray(episodes)&&episodes.length&&episodes.every((e,i)=>scope.includes(e)&&(!i||e===episodes[i-1]+1)),'Invalid WAN scope');
    // Already prepared requests retain their original parameter bytes on resume.
    const normalized=!frozenPlan?.metadata.wan||frozenPlan.metadata.parameters_normalized===1;
    const parameters=normalized?business.clipParameters(project,descriptor.parameters??{}):descriptor.parameters??{};
    assert(!['scriptFileId','productionAssetManifestFileId','requirementsResultId','episodeStart','episodeEnd'].some(k=>k in parameters),'File fields are derived from the plan');
    const script=fact(root,descriptor.script),table=fact(root,descriptor.production_asset_table);
    assert(json(root,descriptor.production_asset_table).sourceScriptSha256===script.sha256,'WAN script identity changed');
    return {stage,operator:'op.drama.clip-wan-compile',target:episodes.join(','),files:[source,script,table,...(descriptor.media_mapping?[fact(root,descriptor.media_mapping)]:[])],uploads:[{path:script.path},{path:table.path}],parameters,
      metadata:{wan:true,...(normalized?{parameters_normalized:1}:{}),script:script.path,production_asset_table:table.path,episodes,media_mapping:descriptor.media_mapping??null}};
  }
  if(stage==='clips'){
    const p=await business.planClipCompilation(root,path),candidate=p.candidate;
    observations.has_existing_report=p.hasExistingReport;
    assert(p.model.id==='seedance-2.0','WAN uses the full production_asset_table descriptor');
    return {stage,operator:p.model.clipOperator,target:p.episodes.join(','),files:p.files,
      uploads:[{path:p.script.path},...candidate.selections.filter((s,i,a)=>a.findIndex(x=>x.path===s.path)===i).map(s=>({path:s.path}))],
      parameters:candidate.compilation_parameters??{},metadata:{candidate,candidate_sha256:p.candidateHash,script:p.script.path,requirements:p.requirements.path,episodes:p.episodes}};
  }
  if(stage==='video'){
    assert(descriptor.schema_version===1&&typeof descriptor.clip_id==='string'&&typeof descriptor.generation_intent==='string'
      &&Number.isSafeInteger(descriptor.attempt)&&descriptor.attempt>0&&!descriptor.batch_id,'Use a single Clip intent and attempt; the batch owns its separate scope and budget');
    const c=await business.videoSelection(root,descriptor.clip_id);
    // Advisory output is deliberately outside the immutable plan and operation identity.
    observations.material_warnings=c.materialWarnings??[];
    assertVideoProvider(c.project);
    const tail=c.previous?await business.adoptedVideoTail(root,c.previous):null;
    // Keep the existing template and real-tail planner; do not synthesize mediaRef from a fileId.
    if(tail&&!tail.media_ref)throw fail('PUBLIC_TAIL_REFERENCE_UNAVAILABLE','原尾帧缺少公开媒体引用；保留前序结果，使用原稳定版本完成此连续镜头。');
    const preview=business.buildVideoRequest(c.request,c.previous,tail??undefined);
    return {stage,operator:'op.video.generate',target:descriptor.clip_id,
      files:[source,...c.media.map(m=>fact(root,m.path)),...(tail?[fact(root,tail.path)]:[])],
      uploads:c.imagesReplaced?c.media.map(m=>({path:m.path,token:m.token})):[],parameters:preview.request.input,
      metadata:{descriptor,profile:business.videoProfile(project),project_binding:business.videoBinding(root,project),binding:c.reviewBinding,
        template:c.request,previous:c.previous,tail,media:c.media,imagesReplaced:c.imagesReplaced,
        storyboard_revision:c.storyboard_revision??null,episode:c.episode,order:c.order}};
  }
  throw fail('PUBLIC_STAGE_UNSUPPORTED');
}

export async function buildProductionInput(root,plan,base,uploads,host){
  const uploaded=path=>{const found=uploads.find(row=>row.path===path);assert(found?.receipt?.fileId,'Upload is not complete');return found.receipt;};
  if(plan.stage==='extraction'){
    const input={...plan.parameters,scriptFileId:uploaded(plan.metadata.script).fileId};
    if(plan.metadata.style)input.projectStyle=business.appendCreativeStyleText(input.projectStyle,plan.metadata.style);
    if(plan.metadata.references.length)input.referenceImages=plan.metadata.references.map(ref=>({fileId:uploaded(ref.path).fileId,label:ref.label,...(ref.note?{note:ref.note}:{})}));
    return input;
  }
  if(plan.stage==='material')return business.assetInput(plan.metadata.kind,plan.parameters,
    plan.metadata.refs.map(ref=>({kind:ref.kind,url:ref.url??undefined,...(plan.metadata.kind==='image'?{fileId:uploaded(ref.path).fileId}:{})})));
  if(plan.stage==='clips'){
    let manifestId;
    if(plan.metadata.wan)manifestId=uploaded(plan.metadata.production_asset_table).fileId;
    else {
      const c=plan.metadata.candidate;
      const manifest={schemaVersion:'drama.production-asset-manifest.v2',requirementsResultId:c.requirements_result_id,sourceRequirementsSha256:c.requirements_sha256,
        manifestRevision:c.manifest_revision,review:{status:'APPROVED',mode:'HUMAN_CONFIRMED'},overrides:c.overrides??[],
        bindings:c.selections.map(s=>({assetId:s.asset_id,role:s.role,fileId:uploaded(s.path).fileId,sha256:s.sha256,reusePolicy:s.reuse_policy}))};
      immutable(root,base+'/manifest.json',manifest);
      immutable(root,base+'/mapping.json',{schema_version:1,items:c.selections.map(s=>({asset_id:s.asset_id,role:s.role,file_id:uploaded(s.path).fileId,sha256:s.sha256,path:s.path}))});
      const result=await host.upload(base+'/manifest.json',base.split('/').at(-1));
      if(!result.ok)throw Object.assign(fail(result.error?.code??'UPLOAD_RESULT_UNCONFIRMED'),{detail:result});
      manifestId=result.receipt.fileId;
    }
    return {...(plan.metadata.wan?{}:{missingVoicePolicy:plan.metadata.candidate.missing_voice_policy??'error',requirementsResultId:plan.metadata.candidate.requirements_result_id}),
      ...plan.parameters,scriptFileId:uploaded(plan.metadata.script).fileId,productionAssetManifestFileId:manifestId,
      episodeStart:plan.metadata.episodes[0],episodeEnd:plan.metadata.episodes.at(-1)};
  }
  const m=plan.metadata;
  let files;
  if(m.imagesReplaced){
    // The public request accepts fileId; do not manufacture a missing mediaRef for local evidence.
    files=new Map(m.media.map(item=>[item.token,{fileId:uploaded(item.path).fileId,mediaRef:undefined,sha256:item.sha256}]));
  }
  const result=business.buildVideoRequest(m.template,m.previous,m.tail??undefined,files);
  immutable(root,base+'/actual.json',result.actual);
  return result.request.input;
}

export function validateProductionInput(detail,plan,input){
  const value=detail?.data??detail;
  assert(value&&(!value.apiCode||value.apiCode===plan.operator),'Operator description mismatch');
  business.validateAssetSchema(value.inputSchema,input);
  return value.outputSchema??null;
}
export async function verifyPlanSources(root,plan){for(const expected of plan.files)assert(fact(root,expected.path).sha256===expected.sha256,'SOURCE_CHANGED');}
export {business};

// A restored review label is not a new video input. Keep every other plan fact,
// including byte hashes, paths, explicit adoption, template and actual tail identity.
export function equivalentProductionPlans(left,right){
  const legacyVoice=(left.metadata?.baseline===null||right.metadata?.baseline===null)&&left.stage==='material'&&right.stage==='material'&&left.metadata?.voice===true&&right.metadata?.voice===true;
  const normalized=plan=>{
    if(legacyVoice)return {...plan,metadata:{...plan.metadata,baseline:null}};
    if(plan.stage!=='video'||plan.metadata.binding?.reference_policy!=='request-input-v2')return plan;
    return {...plan,metadata:{...plan.metadata,media:plan.metadata.media.map(({review_id,...media})=>media)}};
  };
  return hash(normalized(left))===hash(normalized(right));
}
