// Presentation only. This link never performs payment, login or submission.
import {readFileSync} from 'node:fs';

const links=JSON.parse(readFileSync(new URL('../assets/account-links.json',import.meta.url),'utf8'));
export const recharge=Object.freeze({url:links.rechargeUrl,label:'前往充值',message:'余额不足，可前往充值页面补充馒头。'});

export function rechargeForFailure(result){
  return result?.code===1&&/^\s*余额不足[：:]/m.test(result.stderr??'')?recharge:undefined;
}
