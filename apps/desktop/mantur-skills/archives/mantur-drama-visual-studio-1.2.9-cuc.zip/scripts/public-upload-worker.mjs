// Execute only the public CLI entry in this process. No CLI library or credentials are read.
// The parent records this PID before sending go; an orphan that never received go cannot upload.
import { readFileSync, writeFileSync, renameSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { ownProcessIdentity } from '../runtime/process-identity.mjs';

let started = false, stdout = '', overflow = false, receiptFile, expected;
process.stdout.write = function (chunk, encoding, callback) {
  const text = Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk);
  if (stdout.length + text.length <= 2_000_000) stdout += text;
  else overflow = true;
  // Do not depend on the parent's output pipe surviving a host interruption.
  const done = typeof encoding === 'function' ? encoding : callback;
  if (done) queueMicrotask(done);
  return true;
};
process.on('disconnect', () => { if (!started) process.exit(1); });
process.once('exit', code => {
  if (!started || code !== 0 || overflow) return;
  try {
    const value = JSON.parse(stdout);
    if (value.status !== 'AVAILABLE' || typeof value.fileId !== 'string' || !value.fileId.trim() || value.fileId.length > 512
      || value.sha256 !== expected.sha256 || value.sizeBytes !== expected.sizeBytes) return;
    // Persist before the parent consumes the result; omit signed URLs and unknown fields.
    const receipt = { fileId: value.fileId, status: 'AVAILABLE', sha256: value.sha256, sizeBytes: value.sizeBytes };
    writeFileSync(receiptFile + '.tmp', JSON.stringify(receipt) + '\n', { flag: 'wx', mode: 0o600 });
    renameSync(receiptFile + '.tmp', receiptFile);
  } catch { /* No durable receipt means unconfirmed; a later pure upload may retry. */ }
});
process.once('message', async message => {
  if (message?.type !== 'go' || !Array.isArray(message.args) || message.args.length !== 3
    || message.args[0] !== 'upload' || message.args[2] !== '--json') process.exit(1);
  started = true; receiptFile = message.receiptFile; expected = message.expected;
  // Survives loss of the parent; a hung pure upload cannot retain ownership forever.
  setTimeout(() => process.exit(1), 300_000).unref();
  // Verify the exact bytes immediately before the CLI reads them.
  const bytes = readFileSync(message.args[1]);
  if (bytes.length !== expected.sizeBytes || createHash('sha256').update(bytes).digest('hex') !== expected.sha256) process.exit(1);
  process.argv = [process.execPath, message.entry, ...message.args];
  process.disconnect();
  await import(pathToFileURL(message.entry).href);
});
process.send({ type: 'ready', pid: process.pid, identity: (await ownProcessIdentity()).identity });
