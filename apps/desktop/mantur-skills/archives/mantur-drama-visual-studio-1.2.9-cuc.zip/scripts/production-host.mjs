import {fork} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {runPlatform} from './platform.mjs';
import {child} from './access.mjs';
import {createArtifactDownloader} from './artifact-download.mjs';
import {directory,json,save} from './production-state.mjs';

function durableRun(root,operation,entry,args,env,onDispatch){
  return new Promise((resolve,reject)=>{
    const worker=fork(fileURLToPath(new URL('./public-run-worker.mjs',import.meta.url)),[],{env,execArgv:[],silent:true,windowsHide:true});
    let result,stdout='',stderr='';
    worker.on('message',message=>{
      if(message.type==='ready'){
        try{
        const binding={operation_id:operation.operation_id,input_sha256:operation.input_sha256,pid:message.pid,identity:message.identity};
        const path=directory(operation.operation_id)+'/dispatch.json';
        save(root,path,{...binding,state:'prepared',dispatch_version:2});
        onDispatch();
        worker.send({type:'go',entry,args,context:{root,path,binding}});
        }catch(error){if(worker.connected)try{worker.disconnect();}catch{}reject(error);}
      }else if(message.type==='result')result=message.result;
    });
    worker.on('error',reject);
    worker.on('close',code=>{
      const response=result??{code:code??1,stdout,stderr};
      // An intact original receipt can survive a lost IPC message or output pipe.
      // Never reconstruct a confirmation token or adopt another dispatch's result.
      try{
        const receipt=json(root,directory(operation.operation_id)+'/dispatch.json');
        if(receipt.state==='finished'&&receipt.operation_id===operation.operation_id
          &&receipt.input_sha256===operation.input_sha256&&receipt.pid===worker.pid){
          if(!response.stdout.trim()&&receipt.json)response.stdout=JSON.stringify(receipt.json);
          if(!response.stderr.trim()&&receipt.recovery_id)response.stderr='调用恢复 ID: '+receipt.recovery_id+'\n';
        }
      }catch{ /* Missing or invalid evidence remains unknown; never submit again here. */ }
      resolve(response);
    });
    // Workers own bounded execution and durable receipts even if this host exits.
    worker.stdout.on('data',data=>{if(stdout.length<4_000_000)stdout+=data;});worker.stderr.on('data',data=>{if(stderr.length<4_000_000)stderr+=data;});
  });
}
export function productionHost(root){
  const profile=JSON.parse(readFileSync(new URL('./access-profile.json',import.meta.url),'utf8'));
  const download=createArtifactDownloader({trustedOrigins:profile.artifactOrigins??[]});
  const cli=async(args,operation,{onDispatch=()=>{}}={})=>{
    let result,dispatched=false;
    try{
      await runPlatform(['--project',root,...args],{output:value=>{result=value;},
        run:(entry,command,env,options)=>operation&&command[0]==='run'?durableRun(root,operation,entry,command,env,()=>{onDispatch();dispatched=true;}):child(entry,command,env,options)});
      return operation&&args[0]==='run'&&!dispatched?{...result,not_dispatched:true}:result;
    }catch(error){if(operation&&args[0]==='run'&&!dispatched)error.not_dispatched=true;throw error;}
  };
  return {cli,queryBalance:()=>cli(['balance']),upload:async(path,scope)=>cli(['upload',path,'--scope',scope]),
    download:(url,path)=>download(url,path,{projectDir:root}),
    refresh:async(id)=>{const {refreshUiSnapshot}=await import('../runtime/studio.mjs');return refreshUiSnapshot(id?['--update-id',id]:[]);},
    validateReferences:async(path,id)=>{const {validateReferences}=await import('../runtime/actions.mjs');const result=validateReferences([path,'--local-only'],id);if(!result.ok)throw Object.assign(new Error('Invalid local reference routing'),{code:'REFERENCE_ROUTING_INVALID'});return result;}
  };
}
