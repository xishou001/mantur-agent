import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {lstatSync,readFileSync,mkdirSync,renameSync,writeFileSync,readdirSync,realpathSync,linkSync,unlinkSync} from 'node:fs';
import {resolve,relative,isAbsolute,join,dirname} from 'node:path';

const sorted=value=>Array.isArray(value)?value.map(sorted):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort((a,b)=>a.localeCompare(b)).map(key=>[key,sorted(value[key])])):value;
export const hash=value=>createHash('sha256').update(typeof value==='string'||Buffer.isBuffer(value)?value:JSON.stringify(sorted(value))).digest('hex');
export const fail=(code,message=code)=>Object.assign(new Error(message),{code});
export function checked(root,path){
  const full=resolve(root,path),rel=relative(root,full);
  assert(rel&&!rel.startsWith('..')&&!isAbsolute(rel),'Project-local path required');
  let part=realpathSync(root);
  for(const segment of rel.split(/[\\/]/)){part=join(part,segment);assert(!lstatSync(part,{throwIfNoEntry:false})?.isSymbolicLink(),'Symlink is not a production input');}
  return full;
}
export function json(root,path){const file=checked(root,path),stat=lstatSync(file);assert(stat.isFile()&&stat.size<=8*1024*1024,'Invalid production record');return JSON.parse(readFileSync(file,'utf8'));}
export function save(root,path,value){
  const file=checked(root,path);mkdirSync(dirname(file),{recursive:true});
  const tmp=file+'.'+randomUUID()+'.tmp';writeFileSync(tmp,JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o600});renameSync(tmp,file);
}
export function fact(root,path){const file=checked(root,path),stat=lstatSync(file);assert(stat.isFile()&&stat.size>0&&stat.size<=512*1024*1024,'Invalid production file');return {path:relative(root,file).replaceAll('\\','/'),sha256:hash(readFileSync(file)),bytes:stat.size};}
export function immutable(root,path,value){
  const full=checked(root,path);if(lstatSync(full,{throwIfNoEntry:false})){assert(hash(json(root,path))===hash(value),'Immutable production evidence changed');return;}
  mkdirSync(dirname(full),{recursive:true});
  const tmp=full+'.'+randomUUID()+'.tmp';
  try{
    writeFileSync(tmp,JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o600});
    try{linkSync(tmp,full);}catch(error){if(error.code!=='EEXIST')throw error;assert(hash(json(root,path))===hash(value),'Immutable production evidence changed');}
  }finally{try{unlinkSync(tmp);}catch(error){if(error.code!=='ENOENT')throw error;}}
}
export const directory=id=>{assert(/^[a-f0-9]{64}$/.test(id),'Invalid production operation');return `.pipeline-state/runtime/public-production/${id}`;};
export function operations(root){const dir=checked(root,'.pipeline-state/runtime/public-production');return lstatSync(dir,{throwIfNoEntry:false})?readdirSync(dir).filter(id=>/^[a-f0-9]{64}$/.test(id)).flatMap(id=>{const base=directory(id);if(lstatSync(checked(root,base+'/operation.json'),{throwIfNoEntry:false}))return [json(root,base+'/operation.json')];const files=readdirSync(checked(root,base));assert(files.every(name=>name==='plan.json'||name.endsWith('.tmp')),'Unrecognized incomplete production record; preserve and inspect original evidence');if(files.includes('plan.json'))json(root,base+'/plan.json');return [];}):[];}
export function stripped(value){
  if(Array.isArray(value))return value.map(stripped);
  if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).filter(([key,item])=>!/(?:token|authorization|secret)/i.test(key)&&!(typeof item==='string'&&/^https?:\/\//.test(item)&&key!=='pollUrl')).map(([key,item])=>[key,stripped(item)]));
  return value;
}
const legacyDirs={extraction:'online-asset-extraction',material:'asset-operations',clips:'clip-operations',video:'video-operations'};
// A read-only exception for known pre-submit records. Legacy executors persist
// submission intent before invoking; any contradictory evidence retains handoff.
function legacyUnsubmitted(root,stage,id,record){
  try{
    if(!['preparing','awaiting_approval'].includes(record.stage)||record.operation_id!==id)return false;
    if(record.schema_version!==(stage==='extraction'?2:1))return false;
    if(stage==='extraction'&&record.adapter_version!=='asset-online-operation-v1'||stage==='clips'&&record.adapter_version!=='clip-operation-v1')return false;
    if(stage==='video'&&!['seedance-file-video-v1','wan-file-video-v1'].includes(record.profile))return false;
    if(stage==='material'){
      const operators={image:'op.image.generate',understanding:'op.video.understand-v2','voice-design':'op.voice.design',audio:'op.audio.generate'};
      if(!operators[record.kind]||record.operator!==operators[record.kind]||typeof record.asset_id!=='string'||!record.asset_id)return false;
      if(record.submission_status!==undefined&&record.submission_status!=='not_submitted')return false;
    }else if(record.submission_status!=='not_submitted')return false;
    const submitted=['idempotency_key','job_id','jobId','job_status','poll_url','approval_sha256','submission_contract_receipt_sha256',
      'recovery_contract_receipt_sha256','first_job_sha256','first_success_sha256','output','output_sha256','candidates','media','tail_media','publication','review_result','billing_status'];
    if(submitted.some(key=>Object.hasOwn(record,key)))return false;
    const project=json(root,'.pipeline-state/project.json');
    const binding=hash({root:resolve(root),project_id:project.project_id??null,...(stage==='video'?{}:{project_name:project.project_name}),site:project.manturhub_base});
    if(record.site!==project.manturhub_base||(record.project_binding??record.binding)!==binding)return false;
    const base=`.pipeline-state/runtime/${legacyDirs[stage]}/${id}`;
    if(lstatSync(checked(root,base+'.lock'),{throwIfNoEntry:false}))return false;
    const inspect=(path,inResponses=false)=>{
      for(const name of readdirSync(checked(root,path))){
        const file=path+'/'+name,info=lstatSync(checked(root,file));
        if(/(?:\.lock|\.tmp)(?:\.|$)|^(?:approval(?:-|\.)|accepted\.|first-(?:success|job)\.|result(?:-|\.))/i.test(name))return false;
        if(info.isDirectory()){if(!inspect(file,inResponses||name==='responses'))return false;}
        else if(!info.isFile())return false;
        else if(inResponses){
          if(!/^(?:upload|confirm|detail|quote|precharge)-[a-f0-9-]+\.json$/i.test(name))return false;
          const raw=json(root,file),payload=raw.data??raw;
          if([raw,payload].some(value=>!value||typeof value!=='object'||Array.isArray(value)||['jobId','job_id','output'].some(key=>Object.hasOwn(value,key))))return false;
        }
      }
      return true;
    };
    return inspect(base);
  }catch{return false;}
}
export function legacyHandoff(root,stage,target){
  const dir=checked(root,`.pipeline-state/runtime/${legacyDirs[stage]}`);
  if(!lstatSync(dir,{throwIfNoEntry:false}))return;
  for(const id of readdirSync(dir)){
    if(!/^[a-f0-9]{64}$/.test(id))continue;
    let record;try{record=json(root,relative(root,join(dir,id,'operation.json')));}catch{return {code:'LEGACY_RECORD_UNREADABLE',operation_id:id,next_action:'open_matching_stable_version'};}
    const oldTarget=stage==='clips'?record.episodes?.join(','):record.asset_id??record.clip_id;
    if(target&&stage!=='extraction'&&oldTarget&&oldTarget!==target)continue;
    if(['completed','terminal','reviewed','analysis_ready'].includes(record.stage))continue;
    if(legacyUnsubmitted(root,stage,id,record))continue;
    return {code:'LEGACY_RECOVERY_REQUIRED',operation_id:id,original_stage:record.stage,original_adapter:record.adapter_version??record.profile??'unknown',
      next_action:'open_matching_stable_version',message:'保留原记录，使用匹配的稳定版本恢复此操作；不转换批准、身份或幂等键。'};
  }
}
