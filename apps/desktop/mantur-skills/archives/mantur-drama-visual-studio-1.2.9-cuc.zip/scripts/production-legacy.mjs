// Query known legacy Jobs without translating private approvals or unknown submissions.
import assert from 'node:assert/strict';
import {relative,resolve} from 'node:path';
import {lstatSync} from 'node:fs';
import {withProductionOperation} from './production-writer.mjs';
import {business} from './production-plans.mjs';
import {download} from './production-results.mjs';
import {hash,json,immutable,save,checked,fact,stripped} from './production-state.mjs';

export function inspectLegacyReceipt(root,operationPath,receiptPath){
  const path=relative(root,checked(root,operationPath)).replaceAll('\\','/');
  const match=/^\.pipeline-state\/runtime\/(online-asset-extraction|asset-operations|clip-operations|video-operations)\/([a-f0-9]{64})\/operation\.json$/.exec(path);
  assert(match,'Original legacy operation path required');
  const base=path.slice(0,-'/operation.json'.length),receipt=relative(root,checked(root,receiptPath)).replaceAll('\\','/');
  assert(receipt.startsWith(base+'/')&&receipt!==path,'Receipt must belong to the original operation');
  const r=json(root,path),project=json(root,'.pipeline-state/project.json'),raw=json(root,receipt);
  const job=raw.code===0&&raw.success!==false?raw.data:raw;
  const binding=match[1]==='video-operations'?business.videoBinding(root,project):hash({root:resolve(root),project_id:project.project_id??null,project_name:project.project_name,site:project.manturhub_base});
  assert(r.schema_version===1&&r.operation_id===match[2]&&r.site===project.manturhub_base&&(r.project_binding??r.binding)===binding,'Legacy project binding changed');
  const operator=r.operator??r.source_operator??(match[1]==='video-operations'?'op.video.generate':match[1]==='online-asset-extraction'?'op.drama.asset-extract':r.video_model==='wan-3.0'?'op.drama.clip-wan-compile':'op.drama.clip-seedance-compile');
  assert(job&&job.jobId===r.job_id&&typeof r.job_id==='string'&&/^[A-Za-z0-9_-]+$/.test(r.job_id)&&job.apiCode===operator,'Known original Job receipt required');
  const pollUrl=job.pollUrl??r.poll_url;assert(typeof pollUrl==='string','Original poll URL required; do not manufacture a recovery record');
  const url=new URL(pollUrl,r.site);assert(url.origin===new URL(r.site).origin&&url.pathname==='/api/openapi/v1/jobs/'+r.job_id&&!url.search&&!url.hash&&!url.username&&!url.password,'Legacy poll URL changed');
  return {record:r,job,operator,jobId:r.job_id,pollUrl:url.href,operation:fact(root,path),receipt:fact(root,receipt),kind:match[1]};
}
export async function recoverLegacyProduction(root,tokens,host){
  const values={};for(let i=0;i<tokens.length;i++){
    const key=tokens[i];assert(['--operation','--receipt'].includes(key)&&!Object.hasOwn(values,key),'Use --operation <old operation.json> --receipt <original response.json>');
    const value=tokens[++i];assert(value&&!value.startsWith('--'),'Missing evidence path');values[key]=value;
  }
  const evidence=inspectLegacyReceipt(root,values['--operation'],values['--receipt']);
  const id=hash({operation:evidence.operation,receipt:evidence.receipt}),base=`.pipeline-state/runtime/public-legacy-results/${id}`;
  return withProductionOperation(root,'legacy-'+id,async()=>{
    const response=await host.cli(['status','--legacy-operation',evidence.operation.path,'--legacy-receipt',evidence.receipt.path]);
    if(response.code!==0)return {ok:false,error:{code:'LEGACY_QUERY_FAILED'},next_action:'recover-legacy-production'};
    const job=response.json;assert(job.jobId===evidence.jobId&&(!job.apiCode||job.apiCode===evidence.operator),'Original Job changed');
    assert(fact(root,evidence.operation.path).sha256===evidence.operation.sha256&&fact(root,evidence.receipt.path).sha256===evidence.receipt.sha256,'Original evidence changed during query');
    const result={ok:true,operation_id:evidence.record.operation_id,remote_status:job.status,original_preserved:true,submission_performed:false};
    save(root,base+'/observation.json',{...result,job:stripped(job),operation:evidence.operation,receipt:evidence.receipt});
    if(job.status!=='SUCCEEDED')return {...result,next_action:['FAILED','CANCELED','CANCELLED','TIMED_OUT','ERROR','EXPIRED'].includes(job.status)?'inspect_original_terminal_result':'recover-legacy-production'};
    const successPath=base+'/success.json';
    if(!lstatSync(checked(root,successPath),{throwIfNoEntry:false}))immutable(root,successPath,stripped({...job,apiCode:evidence.operator}));
    const candidates=evidence.kind==='video-operations'?(()=>{const out=business.inspectVideoOutput(job.output);return [...out.videos,...(out.tail?[out.tail]:[])];})():
      evidence.kind==='asset-operations'?business.assetOutputs(evidence.record.kind,job.output).media??[]:job.output.artifacts;
    assert(Array.isArray(candidates),'Original artifacts missing');
    const savedJob=json(root,successPath);
    const savedCandidates=evidence.kind==='video-operations'?(()=>{const out=business.inspectVideoOutput(savedJob.output);return [...out.videos,...(out.tail?[out.tail]:[])];})():
      evidence.kind==='asset-operations'?business.assetOutputs(evidence.record.kind,savedJob.output).media??[]:savedJob.output.artifacts;
    for(const [index,previous]of savedCandidates.entries())assert((previous.fileId??previous.file_id)===(candidates[index]?.fileId??candidates[index]?.file_id)&&previous.sha256===candidates[index]?.sha256,'Original artifact identity changed');
    const files=[],pending=[];
    for(const [index,remote]of candidates.entries()){
      try{
        assert(remote.fileId||remote.file_id,'Original artifact identity required');
        const role=remote.role,extension=role==='PRIMARY_JSON'?'json':role==='TABULAR_XLSX'?'xlsx':'bin';
        const file=await download(root,host,remote,`${base}/artifacts/${index}.${extension}`,remote.kind);
        files.push({file_id:remote.fileId??remote.file_id,role:role??remote.kind,...file});
      }catch(error){pending.push({index,code:error.code??'LEGACY_DOWNLOAD_FAILED'});}
    }
    save(root,base+'/delivery.json',{operation:evidence.operation,receipt:evidence.receipt,job:base+'/success.json',files,pending});
    return {...result,ok:!pending.length,job:base+'/success.json',files,pending,next_action:pending.length?'recover-legacy-production':'import_verified_local_results',
      message:'已取回原任务产物；使用对应严格本地导入入口继续。旧视频外部导入仅为候选，不自动补造付费或采用证据。'};
  });
}
