#!/usr/bin/env node
// Hand-written package source. This helper never opens a project or contacts a service.
import {lstat, mkdir, open, readFile, realpath} from 'node:fs/promises';
import {homedir} from 'node:os';
import {dirname, join, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {assertNodeVersion} from '../runtime/node-version.mjs';

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const skip = (reason, ok = true) => ({ok, show_welcome: false, reason});

// Read only the two top-level single-line scalars needed by this helper.
// Both fields accept plain/single-quoted/double-quoted syntax; ambiguous keys
// fail closed before claiming a welcome. This is not a general YAML parser.
function packageScalar(frontmatter, key) {
  const fields = [...frontmatter.matchAll(new RegExp(`^${key}:(.*)$`, 'gm'))];
  if (fields.length !== 1) return undefined;
  const scalar = /^(?:"([^"\r\n]*)"|'([^'\r\n]*)'|([^'"\s]+))(?:[ \t]+#.*)?$/.exec(fields[0][1].trim());
  return scalar?.[1] ?? scalar?.[2] ?? scalar?.[3];
}

// home/skillRoot are injection points for isolated tests, not CLI overrides.
export async function claimWelcome({client, suppress = false, home = homedir(), skillRoot = packageRoot} = {}) {
  if (typeof client !== 'string' || !/^[a-z][a-z0-9-]{0,39}$/.test(client) || ['all', 'unknown'].includes(client))
    return skip('invalid_client', false);
  try {
    assertNodeVersion();
    const entry = await readFile(join(skillRoot, 'SKILL.md'), 'utf8');
    const frontmatter = /^\uFEFF?---[ \t]*\r?\n([\s\S]*?)\r?\n---[ \t]*(?:\r?\n|$)/.exec(entry)?.[1] ?? '';
    const name = packageScalar(frontmatter, 'name'), version = packageScalar(frontmatter, 'version');
    if (name !== 'mantur-drama-visual-studio' || typeof version !== 'string' || !/^\d+\.\d+\.\d+$/.test(version))
      return skip('package_unavailable', false);
    const template = await readFile(join(skillRoot, 'assets/welcome.txt'), 'utf8');
    if (!template.includes('{{version}}') || template.trim().length > 240) return skip('package_unavailable', false);
    const message = template.trim().replaceAll('{{version}}', version);
    // Resolve the OS home once; never follow links inside this helper's state directories.
    let directory = await realpath(home);
    for (const segment of ['.mantur-drama-visual-studio', 'welcome-v1']) {
      directory = join(directory, segment);
      try { await mkdir(directory, {mode: 0o700}); }
      catch (error) { if (error.code !== 'EEXIST') throw error; }
      const info = await lstat(directory);
      if (info.isSymbolicLink() || !info.isDirectory()) return skip('state_unavailable', false);
    }
    // Claim before returning copy: concurrent calls, restarts, upgrades and reinstalls
    // cannot replay the welcome. An interrupted delivery is deliberately not retried.
    let handle;
    try { handle = await open(join(directory, `client-${client}.json`), 'wx', 0o600); }
    catch (error) {
      if (error.code === 'EEXIST') return skip('already_claimed');
      throw error;
    }
    try {
      await handle.writeFile(JSON.stringify({schema_version: 1, claimed: true,
        kind: suppress ? 'upgrade' : 'welcome', first_version: version, claimed_at: new Date().toISOString()}) + '\n');
      await handle.sync();
    } finally { await handle.close(); }
    return suppress ? skip('suppressed_for_upgrade') : {ok: true, show_welcome: true, version, message};
  } catch {
    // No paths, raw errors, repair loops or fallback state locations in agent output.
    return skip('state_or_package_unavailable', false);
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const valid = args[0] === '--client' && args[1] &&
    (args.length === 2 || (args.length === 3 && args[2] === '--suppress'));
  const result = valid ? await claimWelcome({client: args[1], suppress: args[2] === '--suppress'}) : skip('invalid_arguments', false);
  process.stdout.write(JSON.stringify(result) + '\n');
  if (!result.ok) process.exitCode = 1;
}
