// Business routing only. Shared ACCESS/CLI own discovery, authentication and billing.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { existsSync, linkSync, lstatSync, mkdirSync, readFileSync, realpathSync, renameSync, rmdirSync, unlinkSync, writeFileSync } from 'node:fs';
import { isAbsolute, join, relative, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { context, hostSource, parseAccessArgs, runAccess, validateProfile, validateJobStatusUrl } from './access.mjs';
import { createPublicCli } from './cli-client.mjs';
import { readWorkflowContext, workflowContextArgs } from './workflow-context.mjs';
import { uploadProjectFile } from './public-upload.mjs';
import { inspectLegacyReceipt } from './production-legacy.mjs';
import { checked } from './production-state.mjs';

export const steps = Object.freeze({
  'op.drama.asset-extract': 'asset-extract',
  'op.drama.clip-seedance-compile': 'seedance-compile',
  'op.drama.clip-wan-compile': 'wan-compile',
  'op.image.generate': 'image-generate',
  'op.video.understand-v2': 'video-understand',
  'op.voice.design': 'voice-design',
  'op.audio.generate': 'audio-generate',
  'op.video.generate': 'video-generate',
});
const bindingPath = '.pipeline-state/public-cli-binding.json';

function checkedBinding(project, profile) {
  if (!project) return null;
  const file = checked(project, bindingPath), stat = lstatSync(file, { throwIfNoEntry: false });
  if (!stat) return null;
  assert(stat.isFile() && stat.size <= 32768, 'Invalid CLI binding file');
  const bytes = readFileSync(file, 'utf8'), value = JSON.parse(bytes);
  assert(value.schemaVersion === 1 && value.product === profile.product && Array.isArray(value.bindingArgs)
    && Object.keys(value).every(key => ['schemaVersion', 'product', 'bindingArgs'].includes(key)), 'Invalid CLI binding file');
  const selected = parseAccessArgs(value.bindingArgs);
  assert(selected.args.length === 0 && selected.binding, 'Invalid checked CLI binding');
  return { ...selected, file, bytes };
}

function saveCheckedBinding(project, profile, result, previous) {
  if (!project || result.code !== 0 || !result.authenticated || !result.operatorReady) return;
  const selected = parseAccessArgs(result.bindingArgs ?? []);
  assert(selected.args.length === 0 && selected.source && selected.binding, 'Incomplete checked execution context');
  const file = checked(project, bindingPath), lock = file + '.check-lock';
  const bytes = JSON.stringify({ schemaVersion: 1, product: profile.product, bindingArgs: result.bindingArgs }) + '\n';
  if (checkedBinding(project, profile)?.bytes === bytes) return;
  mkdirSync(join(project, '.pipeline-state'), { recursive: true });
  mkdirSync(lock); // Only this short local publication is locked; never reclaim another checker.
  const temporary = file + '.' + randomUUID() + '.tmp';
  let created = false;
  try {
    const current = checkedBinding(project, profile);
    if (current?.bytes === bytes) return;
    assert(current?.bytes === previous?.bytes, 'Checked execution context changed concurrently; check again');
    writeFileSync(temporary, bytes, { flag: 'wx', mode: 0o600 }); created = true;
    if (current) renameSync(temporary, file);
    else linkSync(temporary, file); // A concurrent first binding must never be overwritten.
  } finally {
    if (created && existsSync(temporary)) unlinkSync(temporary);
    rmdirSync(lock);
  }
}

export async function runPlatform(argv, { env = process.env, run, signal, output = value => console.log(JSON.stringify(value)) } = {}) {
  const profile = validateProfile(JSON.parse(readFileSync(new URL('./access-profile.json', import.meta.url), 'utf8')));
  let project;
  if (argv[0] === '--project') {
    assert(isAbsolute(argv[1] ?? ''), 'Project must be an absolute path');
    project = realpathSync(argv[1]);
    assert(lstatSync(project).isDirectory(), 'Project directory is required');
    argv = argv.slice(2);
  }
  const options = parseAccessArgs(argv), args = options.args;
  assert(!options.project || project && resolve(options.project) === project, 'Conflicting project binding');
  if (!options.binding && env.MANTURHUB_CLI_ENTRY) {
    assert(env.MANTURHUB_CONFIG_DIR, 'Explicit CLI entry requires its explicit configuration directory');
    options.binding = { cliPath: env.MANTURHUB_CLI_ENTRY, configDir: env.MANTURHUB_CONFIG_DIR };
  }
  const action = args[0];
  assert(['check', 'registration', 'context', 'describe', 'quote', 'run', 'status', 'resume', 'upload', 'balance'].includes(action),
    'Unsupported public business command; see references/public-cli-adaptation.md');
  const saved = project ? readWorkflowContext(project) : null;
  const requestedBusiness = options.businessCode ?? env.MANTURHUB_BUSINESS_CODE;
  if (saved && requestedBusiness !== undefined) assert(saved.businessCode === requestedBusiness, 'Project business conflict');
  if (action === 'context') {
    assert(project && args.length === 1, 'Use --project <directory> context');
    output(saved); return 0; // Pure context inspection remains read-only.
  }
  const previousBinding = checkedBinding(project, profile);
  const businessCode = saved?.businessCode ?? requestedBusiness ?? previousBinding?.businessCode ?? profile.businessCode;
  const known = value => value && value !== 'unknown';
  const environmentSource = env.MANTURHUB_SOURCE === undefined ? undefined : hostSource(env.MANTURHUB_SOURCE);
  const suppliedSource = known(options.source) ? options.source : environmentSource ?? options.source;
  if (!['check', 'status', 'resume', 'registration'].includes(action) && known(previousBinding?.source) && known(suppliedSource))
    assert(suppliedSource === previousBinding.source, 'Host source changed; run project check before new calls');
  const source = (known(suppliedSource) ? suppliedSource : previousBinding?.source ?? suppliedSource)
    ?? 'unknown';
  const originalConfirmation = action === 'run' && args.some(arg => /^--confirm(?:=|$)/.test(arg));
  const newCall = ['describe', 'quote', 'upload'].includes(action) || action === 'run' && !originalConfirmation;
  const needsCheckedBinding = project && newCall && known(source) && !known(previousBinding?.source);
  const bindingArgs = [...(source ? ['--source', source] : []), '--business-code', businessCode,
    ...(options.binding ? ['--existing-cli', options.binding.cliPath, '--config-dir', options.binding.configDir] : []),
    ...(options.environmentBinding ? ['--environment-binding', options.environmentBinding] : [])];
  if (action === 'registration') {
    assert(args.length === 1, 'registration accepts no arguments');
    return runAccess(profile, [...bindingArgs, 'registration'], { env, run, output });
  }
  const cli = createPublicCli({ profile, bindingArgs, projectDir: project, bindingPath: project ? bindingPath : undefined, env, run, signal });
  if (action === 'balance') {
    assert(args.length === 1, 'balance accepts no arguments');
    const result = await cli.queryBalance({ signal });
    output({ ...result, checked_at: new Date().toISOString() }); return 0;
  }
  if (action === 'check') {
    assert(args.length === 1, 'check accepts no arguments');
    const result = await cli.check();
    saveCheckedBinding(project, profile, result, previousBinding);
    output(result); return result.code;
  }
  assert(project, 'Public production commands require the original project');
  const pipeline = lstatSync(join(project, '.pipeline-state'));
  assert(pipeline.isDirectory() && !pipeline.isSymbolicLink(), 'Unsafe project state directory');
  const projectFile = join(project, '.pipeline-state/project.json');
  const info = lstatSync(projectFile);
  assert(info.isFile() && !info.isSymbolicLink() && info.size <= 1024 * 1024, 'Invalid project configuration');
  const config = JSON.parse(readFileSync(projectFile, 'utf8'));
  const selectedSite = context(profile, env, undefined, options.binding, source, businessCode).baseUrl ?? profile.baseUrl;
  const siteProfile = { ...profile, baseUrl: selectedSite };
  assert(config.manturhub_base === selectedSite, 'Project site differs from the selected CLI environment; do not rebind an existing project');
  if (action === 'upload') {
    assert((args.length === 4 || args.length === 5 && args[4] === '--renew') && args[2] === '--scope',
      'Use upload <project-file> --scope <business-operation-id> [--renew]');
    if (needsCheckedBinding) {
      const readiness = await cli.check();
      if (readiness.code !== 0) { output({ ...readiness, ok: false, next_action: 'repair_access_then_retry_upload' }); return readiness.code; }
      saveCheckedBinding(project, profile, readiness, previousBinding);
    }
    const result = await uploadProjectFile({ project, file: args[1], scope: args[3], renew: args[4] === '--renew', profile, bindingArgs, env, run });
    output(result); return result.code;
  }
  let command = [...args];
  let originalJob;
  const operator = args[1];
  if (action === 'resume' || action === 'status') {
    const legacy=action==='status'&&args[1]==='--legacy-operation';
    assert(legacy||saved && lstatSync(join(project, bindingPath), { throwIfNoEntry: false }),
      'LEGACY_RECOVERY_REQUIRED: use the original recovery entry; do not create a new binding or resubmit');
    if (action === 'resume') assert(args.length === 2 && /^[a-zA-Z0-9-]+$/.test(args[1]), 'Use the original CLI recovery ID');
    else if(legacy){
      assert(args.length===5&&args[3]==='--legacy-receipt','Use original legacy operation and receipt');
      const evidence=inspectLegacyReceipt(project,args[2],args[4]);
      assert(Object.hasOwn(steps,evidence.operator),'Legacy operator outside product scope');
      command=['status',validateJobStatusUrl(evidence.pollUrl,siteProfile)];
      originalJob={jobId:evidence.jobId,operator:evidence.operator};
    } else {
      assert(args.length === 3 && args[1] === '--receipt', 'Use status --receipt <saved-CLI-job.json>');
      const requested = resolve(project, args[2]), file = realpathSync(requested), rel = relative(project, requested);
      assert(rel && !rel.startsWith('..') && !isAbsolute(rel), 'Receipt must be inside the original project');
      let cursor = project;
      for (const part of rel.split(/[\\/]/)) {
        cursor = join(cursor, part);
        assert(!lstatSync(cursor).isSymbolicLink(), 'Unsafe receipt path');
      }
      const stat = lstatSync(file);
      assert(stat.isFile() && stat.size <= 4 * 1024 * 1024, 'Invalid saved CLI receipt');
      const raw = JSON.parse(readFileSync(file, 'utf8')), job = raw.json ?? raw;
      const receiptOperator = job.apiCode ?? job.operatorCode ?? raw.operator;
      const jobId = job.jobId ?? job.job_id;
      assert(!(job.jobId && job.job_id && job.jobId !== job.job_id), 'Conflicting receipt Job IDs');
      assert(typeof jobId === 'string' && /^[A-Za-z0-9_-]+$/.test(jobId)
        && Object.hasOwn(steps, receiptOperator), 'Original accepted Job is required');
      const url = validateJobStatusUrl(job.pollUrl, siteProfile);
      assert(url.endsWith('/' + jobId), 'Receipt job identity differs from pollUrl');
      command = ['status', job.pollUrl];
      originalJob = { jobId, operator: receiptOperator };
    }
    // No current step/flow/version arguments: the CLI restores its original snapshot.
  } else {
    assert(Object.hasOwn(steps, operator), 'Operator is outside the business allowlist');
    assert(!args.some(arg => /^--(?:skill-run-id|step-code|business-code|skill-code|skill-version|source|distribution-target|access-mode)(?:=|$)/.test(arg)),
      'Attribution is owned by the project and installed package');
    if (action === 'run') {
      assert(!args.some(arg => /^--file(?:=|$)/.test(arg)), 'Upload separately before run; retrying upload must never submit an operator');
      assert(args.includes('--no-wait'), 'Use --no-wait; the Agent controls waiting');
      if (originalConfirmation) assert(saved,
        'An existing confirmation requires its original project attribution; do not backfill old confirmations');
    }
    if (action !== 'describe' || needsCheckedBinding) {
      const readiness = await cli.check();
      if (readiness.code !== 0) { output(readiness); return readiness.code; }
      if (needsCheckedBinding) saveCheckedBinding(project, profile, readiness, previousBinding);
    }
    if (action !== 'describe') {
      const flowArgs = workflowContextArgs({ project, skillRunId: saved?.skillRunId ?? randomUUID().replaceAll('-', ''),
        stepCode: steps[operator], operator, businessCode, env });
      command.push(...flowArgs);
    }
  }
  const result = await cli.exec(command);
  if (['describe', 'quote', 'run'].includes(action)) result.operator = operator;
  if (action === 'status' && result.code === 0) {
    const job = result.json;
    const responseOperator = job?.apiCode ?? job?.operatorCode;
    assert(job && (job.jobId ?? job.job_id) === originalJob.jobId
      && !(job.jobId && job.job_id && job.jobId !== job.job_id)
      && (responseOperator === undefined || responseOperator === originalJob.operator)
      && ['CREATED', 'QUEUED', 'PENDING', 'RUNNING', 'PROCESSING', 'IN_PROGRESS', 'SUCCEEDED', 'FAILED',
        'ERROR', 'CANCELED', 'CANCELLED', 'EXPIRED', 'TIMEOUT', 'TIMED_OUT'].includes(String(job.status).toUpperCase()),
    'Invalid original Job response; preserve the receipt and query again, never resubmit');
  }
  // Preserve exit 3, confirmation and recovery receipts; never retry or interpret success.
  output(result); return result.code;
}

/** Compatibility business entry; all new file preparations use only public upload. */
export async function preparePublicProjectFile(project, tokens, options = {}) {
  const values = {}, flags = new Set();
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (token === '--renew') { assert(!flags.has(token), 'Duplicate --renew'); flags.add(token); continue; }
    assert(['--input', '--scope'].includes(token) && !Object.hasOwn(values, token), 'Use --input <project-file> [--scope <operation-id>] [--renew]');
    const value = tokens[++i]; assert(value && !value.startsWith('--'), 'Missing upload argument'); values[token] = value;
  }
  assert(values['--input'], 'Provide --input with the project file');
  let result;
  await runPlatform(['--project', project, 'upload', resolve(project, values['--input']), '--scope', values['--scope'] ?? 'project-file',
    ...(flags.has('--renew') ? ['--renew'] : [])], { ...options, output: value => { result = value; } });
  return { ...result, action: 'prepare-project-file' };
}

if (process.argv[1] && existsSync(process.argv[1]) && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  try { process.exitCode = await runPlatform(process.argv.slice(2)); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
