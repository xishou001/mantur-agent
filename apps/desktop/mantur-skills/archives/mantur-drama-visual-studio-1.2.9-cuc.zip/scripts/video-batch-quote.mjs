import assert from 'node:assert/strict';
import {hash,json,immutable,checked} from './production-state.mjs';
import {lstatSync} from 'node:fs';

const maxAge=24*60*60*1000;
const optional=(root,path)=>lstatSync(checked(root,path),{throwIfNoEntry:false})?json(root,path):null;

// This is preparation evidence only, never an account identity, price lock or
// confirmation. Completed preparations refresh; only incomplete rounds resume.
export function videoBatchQuotes(root,batchId,detail,{resume=false,round=null,now=()=>Date.now()}={}){
  const folder=`.pipeline-state/runtime/public-batches/${batchId}`;
  const binding=()=>hash({batch_id:batchId,round,project:json(root,'.pipeline-state/project.json'),
    execution:optional(root,'.pipeline-state/public-cli-binding.json'),contract:detail});
  const context=binding();
  const unchanged=()=>assert(binding()===context,'Video quote execution context changed; prepare again');
  return {
    get(state,request){
      unchanged();
      if(!resume||!state.video_quote_receipt||state.error?.code==='BATCH_PRICE_CHANGED')return null;
      const id=state.video_quote_receipt;assert(/^[a-f0-9]{64}$/.test(id),'Invalid video quote receipt');
      const receipt=json(root,`${folder}/video-quote-${id}.json`);
      assert(hash(receipt)===id&&receipt.schema_version===1,'Video quote receipt changed');
      if(receipt.context_sha256!==context||receipt.request_sha256!==hash(request))return null;
      const at=Date.parse(receipt.quoted_at),until=Date.parse(receipt.expires_at),time=now();
      assert(Number.isFinite(at)&&Number.isFinite(until)&&until>at&&until<=at+maxAge,'Invalid video quote validity');
      return at<=time&&time<until?receipt:null;
    },
    save(request,quote){
      unchanged();
      const at=now();let until=at+maxAge;
      for(const key of ['expireAt','expiresAt','validUntil'])if(quote[key]!=null){
        assert(typeof quote[key]==='string'&&Number.isFinite(Date.parse(quote[key])),'Invalid video quote expiry');
        until=Math.min(until,Date.parse(quote[key]));
      }
      assert(until>at,'Video quote expired');
      const receipt={schema_version:1,context_sha256:context,request_sha256:hash(request),quote,
        quoted_at:new Date(at).toISOString(),expires_at:new Date(until).toISOString()};
      const id=hash(receipt);immutable(root,`${folder}/video-quote-${id}.json`,receipt);
      return {id,receipt};
    },
    unchanged,
  };
}
