import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {lstatSync,readdirSync} from 'node:fs';
import {inspectProcess} from '../runtime/process-identity.mjs';
import {resolve} from 'node:path';
import {withProductionWriter,withProductionOperation} from './production-writer.mjs';
import {confirmationFrom} from './cli-client.mjs';
import {planProduction,equivalentProductionPlans,buildProductionInput,validateProductionInput,verifyPlanSources} from './production-plans.mjs';
import {finishProduction,recoverProductionAttachment} from './production-results.mjs';
import {clipAssetFiles} from './clip-asset-files.mjs';
import {recharge,rechargeForFailure} from './recharge.mjs';
import {hash,json,save,immutable,directory,operations,legacyHandoff,fail,stripped,checked,fact} from './production-state.mjs';

const terminal=new Set(['FAILED','ERROR','CANCELED','CANCELLED','EXPIRED','TIMEOUT','TIMED_OUT']);
const baseOf=r=>directory(r.operation_id);
const saveOperation=(root,r)=>{r.updated_at=new Date().toISOString();save(root,baseOf(r)+'/operation.json',r);};
function savePreparationQuote(r,result){
  r.quote=preparationQuote(result);
  if(result.quote_evidence)r.quote_evidence=stripped(result.quote_evidence);else delete r.quote_evidence;
}
export function preparationQuote(result){
  const quote=stripped(result.json);
  if(!quote||typeof quote!=='object'||Array.isArray(quote)||feeSummary(quote).cost_points===null)
    throw fail('PUBLIC_QUOTE_INVALID','工具未返回有效的结构化报价；保留原操作，修复报价输出后重新准备，不改用制作调用询价。');
  return quote;
}
// Append-only evidence for local budget release, never a refund or CLI invocation record.
function recordUnsubmitted(root,r,reason){
  assert(!r.job_id&&!r.accepted_sha256&&r.input_sha256,'Cannot release an accepted operation');
  const proof={schema_version:1,operation_id:r.operation_id,input_sha256:r.input_sha256,previous:r.not_submitted_id??null,reason,nonce:randomUUID()};
  const id=hash(proof);immutable(root,baseOf(r)+`/not-submitted/${id}.json`,proof);r.not_submitted_id=id;
}
const queryOriginal=(root,r,host)=>host.cli(!json(root,baseOf(r)+'/accepted.json').json?.pollUrl&&r.recovery_id?['resume',r.recovery_id]:['status','--receipt',resolve(root,baseOf(r)+'/accepted.json')]);
const numericAmount=value=>typeof value==='number'&&Number.isFinite(value)&&Math.abs(value)<=Number.MAX_SAFE_INTEGER?value:
  typeof value==='string'&&/^-?\d+(?:\.\d+)?$/.test(value.trim())&&Number.isFinite(Number(value))&&Math.abs(Number(value))<=Number.MAX_SAFE_INTEGER?Number(value):null;
// Presentation only. The CLI remains the authority for pricing, authorization and settlement.
export function feeSummary(quote,balance={available:false,reason:'not_queried'}){
  const settlement=quote?.postExecutionSettlement;
  const amount=numericAmount(settlement?.maximumPoints??quote?.estimatedPoints);
  const known=amount!==null&&amount>=0&&(!settlement||amount>0)&&(amount!==0||quote?.billable===false);
  const difference=known&&balance.available?Number((balance.points-amount).toPrecision(15)):null;
  return {unit:'馒头',cost_kind:!known?'unavailable':settlement?'maximum':'estimate',cost_points:known?amount:null,
    formula:quote?.formula??settlement?.formula??null,settlement:settlement??null,balance,
    estimated_remaining_points:difference,shortfall_points:difference===null?null:Math.max(0,-difference),is_estimate:true,
    ...(quote?.enoughBalance===false||difference!==null&&difference<0?{recharge}:{}),
    notice:settlement?'按最高费用估算余量；成功后按实际用量结算，预扣 0 不代表免费。':'预计剩余仅为查询余额减去本次报价，不代表实际扣费或可支付证明。'};
}
export async function productionFinancialStatus(r,host,quote=r.quote,returnedBalance){
  let balance={available:false,reason:'query_unavailable'};
  try{
    const receipt=await host.queryBalance();
    const points=numericAmount(receipt.totalBalance);
    assert(points!==null&&Number.isFinite(Date.parse(receipt.checked_at)),'Invalid balance receipt');
    balance={available:true,points,checked_at:receipt.checked_at,source:'public_cli_query'};
  }catch{
    const points=numericAmount(returnedBalance);
    if(points!==null)balance={available:true,points,checked_at:new Date().toISOString(),source:'cli_confirmation'};
  }
  return {...productionStatus(r),quote:stripped(quote??null),fees:feeSummary(quote,balance)};
}
// Read-only observation for an old warning, never permission to skip write locks.
// Missing/unsafe/unreadable directories are unknown; expired leases still block.
function cleanupSiteIsClear(root){
  if(!root)return false;
  try{
    const names=readdirSync(checked(root,'.pipeline-state/runtime'));
    const locks=/^(?:image-phase|snapshot-batch|snapshot)\.lock(?:\.reap)?(?:\.[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.tmp)?$/i;
    return !names.some(raw=>{const name=process.platform==='win32'?raw.toLowerCase():raw;return name==='snapshot-batch.json'||locks.test(name);});
  }catch{return false;}
}
export function productionStatus(r){const confirmed=!['preparing','awaiting_manifest_review','ready'].includes(r.state)&&r.confirmation_quote;const quote=confirmed||r.quote;const cleanup=r.material_review?.snapshot_cleanup??r.result?.snapshot_cleanup;
  const cleanupBlocked=cleanup?.ok===false&&(r.state!=='completed'||!cleanupSiteIsClear(r.project));
  return {ok:!r.error,code:r.state==='confirmation_required'?3:r.error?1:0,operation_id:r.operation_id,stage:r.state,
  quote:stripped(quote??null),quote_source:confirmed?'cli_confirmation':r.quote_evidence?'batch_representative':'saved_preparation',
  ...(!confirmed&&r.quote_evidence?{quote_evidence:r.quote_evidence}:{}),fees:feeSummary(quote),
  attachment:r.attachment??null,attachment_error:r.attachment_error??null,
  material_warnings:r.material_warnings??[],creative_warnings:r.creative_warnings??[],attachment_warnings:r.attachment_warnings??[],
  operator:r.plan.operator,job_id:r.job_id??null,recovery_id:r.recovery_id??null,error:r.error??null,result:r.result??null,
  ...(r.state==='completed'&&r.plan.stage==='material'&&r.result?.media?.length?{review_baseline_action:'asset-review-baseline'}:{}),
  snapshot_cleanup:cleanup??null,
  next_action:r.error?.code==='PUBLIC_INPUT_CHANGED'?'prepare_new_unsubmitted_attempt':cleanupBlocked?'inspect_snapshot_cleanup':r.state==='completed'?(r.plan.stage==='material'&&r.result?.saved===false&&!r.material_review?'apply_asset_review':'continue_authorized_scope'):r.state==='terminal'?'prepare_authorized_successor':
    r.state==='submission_unknown'?(r.recovery_id?'recover_original_cli_call':'inspect_original_submission_without_resubmitting'):r.state==='confirmation_required'?'submit_with_original_cli_confirmation':
    r.state==='awaiting_manifest_review'?'confirm_production_manifest':r.state==='ready'?'submit_authorized_operation':'resume_same_operation'};}
export function loadProduction(root,id){const r=json(root,directory(id)+'/operation.json');assert(r.schema_version===1&&r.transport==='public-cli-v1'&&r.operation_id===id&&r.project===resolve(root),'Invalid public production binding');assert(hash(json(root,directory(id)+'/plan.json'))===r.plan_sha256&&hash(r.plan)===r.plan_sha256,'Production plan changed');return r;}

async function completeProduction(root,r,job,host){
  r.result=await finishProduction(root,r,job,host);r.state='completed';saveOperation(root,r);
  if(r.plan.stage==='material'&&r.result?.media?.length&&r.result.saved!==true){
    try{const value=await host.refresh();r.result.snapshot_refresh={ok:true,revision:value.revision};}
    catch{r.result.snapshot_refresh={ok:false,error:{code:'SNAPSHOT_REFRESH_FAILED'}};}
    saveOperation(root,r);
  }
}

export async function prepareProduction(root,stage,input,host,options={}){
  if(options.noWrite||options.localOnly)return prepareProductionOwned(root,stage,input,host,options);
  return withProductionWriter(root,()=>prepareProductionOwned(root,stage,input,host,options));
}
async function prepareProductionOwned(root,stage,input,host,{attempt='initial',retryOf,manifestReview,noWrite=false,localOnly=false}={}){
  assert(/^[A-Za-z0-9_-]{1,128}$/.test(attempt),'Use a stable attempt label');
  const descriptor=json(root,input),target=stage==='material'?descriptor.asset_id:stage==='video'?descriptor.clip_id:stage==='clips'?descriptor.episodes?.join(','):undefined;
  const handoff=legacyHandoff(root,stage,target);
  if(handoff)return {ok:false,code:1,error:handoff,next_action:handoff.next_action};
  const observations={};
  const plan=await planProduction(root,stage,input,host,observations);
  const id=hash({transport:'public-cli-v1',project:resolve(root),plan,attempt});
  const checkIntent=(all,existing)=>{
    if(stage!=='clips'||plan.metadata.wan)return;
    const intent=plan.metadata.candidate.generation_intent;
    if(!existing&&observations.has_existing_report&&!intent)throw fail('CLIP_GENERATION_INTENT_REQUIRED');
    if(intent)for(const row of all.filter(row=>row.plan.operator===plan.operator&&row.plan.metadata.candidate?.generation_intent===intent))
      if(!equivalentProductionPlans(row.plan,plan))throw fail('CLIP_GENERATION_INTENT_CONFLICT');
  };
  if(noWrite||localOnly){const all=operations(root);checkIntent(all,all.find(row=>row.operation_id===id));return {ok:true,code:0,stage:'preview',read_only:true,operation_id:id,plan,material_warnings:observations.material_warnings??[],next_action:'prepare_authorized_operation'};}
  const initialized=await withProductionOperation(root,'initialize',async()=>{
    const all=operations(root);let existing=all.find(row=>row.operation_id===id);
    if(!existing){
      const matches=all.filter(row=>row.attempt===attempt&&equivalentProductionPlans(row.plan,plan));
      if(matches.length>1)throw fail('PUBLIC_PLAN_AMBIGUOUS','存在多个仅审核编号不同的原操作；按原操作 ID 核对并恢复，不自动选择或创建新任务。');
      existing=matches[0];
    }
    checkIntent(all,existing);
    if(existing)return {record:loadProduction(root,existing.operation_id)};
    const same=all.filter(row=>row.plan.stage===stage&&row.plan.target===plan.target&&(stage!=='material'||row.plan.operator===plan.operator));
    const inFlight=same.find(row=>['submission_unknown','accepted','result_pending'].includes(row.state));
    if(inFlight)return {blocked:{...productionStatus(inFlight),ok:false,code:1,next_action:'resume_original_operation'}};
    if(retryOf){
      const previous=loadProduction(root,retryOf);
      assert(previous.plan.stage===stage&&previous.plan.target===plan.target&&previous.plan.operator===plan.operator&&previous.state==='terminal','Only an original terminal failure of the same operator may have a successor');
      assert(previous.job_id||previous.rejection?.submission?.outcome==='REJECTED','Terminal receipt is required');
      if(previous.job_id){
        assert(hash(json(root,baseOf(previous)+'/accepted.json'))===previous.accepted_sha256,'Original receipt changed');
        const original=await queryOriginal(root,previous,host);
        assert(original.code===0&&accepted(previous,original)&&previous.state==='terminal','Query the original terminal Job before creating a successor');
      }
    }else assert(!same.some(row=>row.state==='terminal'),'Use --retry-of with the original terminal operation and a new attempt');
    const r={schema_version:1,transport:'public-cli-v1',operation_id:id,project:resolve(root),plan,plan_sha256:hash(plan),attempt,
      ...(retryOf?{retry_of:retryOf}:{}),state:stage==='clips'&&!plan.metadata.wan?'awaiting_manifest_review':'preparing',uploads:[],created_at:new Date().toISOString()};
    immutable(root,directory(id)+'/plan.json',plan);saveOperation(root,r);return {record:r};
  });
  if(initialized.blocked)return initialized.blocked;
  return continueProduction(root,initialized.record.operation_id,'prepare',host,{manifestReview,observations});
}

async function prepare(root,r,host,manifestReview){
  const base=baseOf(r),plan=r.plan;
  await verifyPlanSources(root,plan);
  if(r.state==='awaiting_manifest_review'){
    if(!manifestReview)return;
    const review=json(root,manifestReview);
    assert(review.approved===true&&review.operation_id===r.operation_id&&review.candidate_sha256===plan.metadata.candidate_sha256,'Manifest review must match this candidate');
    immutable(root,base+'/manifest-review.json',review);r.state='preparing';saveOperation(root,r);
  }
  const checked=await host.cli(['check']);if(checked.code!==0)throw Object.assign(fail('PUBLIC_ACCESS_NOT_READY'),{detail:checked});
  await verifyPublicReferences(root,r,host);
  const existingAsset=clipAssetFiles(root,r,host);
  for(const file of plan.uploads){
    const result=await existingAsset(file.path)??await host.upload(file.path,r.operation_id);
    if(!result.ok)throw Object.assign(fail(result.error?.code??'UPLOAD_RESULT_UNCONFIRMED'),{detail:result});
    const row={path:file.path,receipt:result.receipt,receipt_path:result.receipt_path,...(result.reuse_source?{reuse_source:result.reuse_source}:{})};
    r.uploads=r.uploads.filter(item=>item.path!==file.path);r.uploads.push(row);saveOperation(root,r);
  }
  const input=await buildProductionInput(root,plan,base,r.uploads,host);
  const detail=await host.cli(['describe',plan.operator,'--json']);if(detail.code!==0)throw Object.assign(fail('PUBLIC_DESCRIBE_FAILED'),{detail});
  r.output_schema=validateProductionInput(detail.json,plan,input);
  await verifyPlanSources(root,plan);
  immutable(root,base+'/input.json',input);r.input_sha256=hash(input);
  const quote=await host.cli(['quote',plan.operator,'--json','--json-file',resolve(root,base+'/input.json')]);
  if(quote.code!==0)throw Object.assign(fail('PUBLIC_QUOTE_FAILED'),{detail:quote});
  savePreparationQuote(r,quote);r.state='ready';delete r.error;saveOperation(root,r);
}
async function verifyPublicReferences(root,r,host){
  for(const reference of r.plan.metadata.refs??[]){
    if(!reference.url)continue;
    const expected=r.plan.files.find(file=>file.path===reference.path);
    const path=baseOf(r)+'/reference-check/'+hash(reference.url)+'.bin';
    await host.download(reference.url,resolve(root,path));
    assert(expected&&fact(root,path).sha256===expected.sha256,'Public reference differs from the selected local original');
  }
}

function accepted(r,result){
  const job=result.json;
  if(!job||typeof job!=='object')return false;
  const id=job.jobId??job.job_id;
  assert(!(job.jobId&&job.job_id&&job.jobId!==job.job_id),'Conflicting accepted Job IDs');
  if(id){
    assert(typeof id==='string'&&/^[A-Za-z0-9_-]+$/.test(id)&&(!r.job_id||r.job_id===id),'Original Job changed');
    assert(!job.apiCode||job.apiCode===r.plan.operator,'Accepted operator changed');
    r.job_id=id;r.job_status=String(job.status??'QUEUED').toUpperCase();
    // This is a projection for local importers; raw CLI evidence is separately retained.
    r.job={jobId:id,apiCode:r.plan.operator,status:r.job_status,...(job.output?{output:stripped(job.output)}:{})};
    r.state=terminal.has(r.job_status)?'terminal':r.job_status==='SUCCEEDED'?'result_pending':'accepted';return true;
  }
  if(result.code===0&&job.output&&(!job.status||job.status==='SUCCEEDED')){
    r.job={apiCode:r.plan.operator,status:'SUCCEEDED',output:stripped(job.output)};r.job_status='SUCCEEDED';r.state='result_pending';return true;
  }
  return false;
}

// Every recovery path applies the same CLI-owned, input-bound rejection receipt.
function rejected(root,r,result){
  const rejection=result.json;
  const canonical=value=>Array.isArray(value)?value.map(canonical):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonical(value[k])])):value;
  if(rejection?.schemaVersion!=='mantur.cli.submission.v1'||rejection.inputDigest!==hash(JSON.stringify(canonical(json(root,baseOf(r)+'/input.json'))))||rejection.operatorCode!==r.plan.operator||!['NOT_SUBMITTED','REJECTED'].includes(rejection.status)
    ||rejection.submission?.outcome!==rejection.status||rejection.jobId||rejection.job_id||rejection.output)return false;
  r.rejection=stripped(rejection);r.state=rejection.status==='NOT_SUBMITTED'?'ready':'terminal';return true;
}

export async function continueProduction(root,id,action,host,{confirm,manifestReview,localOnly=false,observations,submissionGuard}={}){
  return withProductionOperation(root,id,async()=>{
    const r=loadProduction(root,id),base=baseOf(r);
    // Mutable diagnostics can refresh without rewriting plan.json, confirmations or historical IDs.
    if(observations?.material_warnings){r.material_warnings=observations.material_warnings;saveOperation(root,r);}
    delete r.error;
    try{
      // A host interruption may occur before the parent receives the CLI result.
      if((r.state==='submission_unknown'||!r.accepted_sha256&&['accepted','result_pending'].includes(r.state))&&lstatSync(checked(root,base+'/dispatch.json'),{throwIfNoEntry:false})){
        const dispatch=json(root,base+'/dispatch.json');
        assert(dispatch.operation_id===id&&dispatch.input_sha256===r.input_sha256,'Dispatch binding changed');
        if(dispatch.recovery_id)r.recovery_id=dispatch.recovery_id;
        if(dispatch.state!=='finished'){
          const owner=await inspectProcess(dispatch.pid);
          if(owner.state!=='dead'&&!(owner.identity&&dispatch.identity&&owner.identity!==dispatch.identity))return {...productionStatus(r),next_action:'wait_for_original_cli_process'};
        }
        if(dispatch.state==='finished'&&accepted(r,{code:dispatch.code,json:dispatch.json})){
          immutable(root,base+'/accepted.json',{operator:r.plan.operator,json:dispatch.json});r.accepted_sha256=hash(json(root,base+'/accepted.json'));
        }else if(dispatch.code===3&&dispatch.confirmation_sha256){r.confirmation_sha256=dispatch.confirmation_sha256;r.state='confirmation_required';recordUnsubmitted(root,r,'cli_confirmation');}
        else if(dispatch.state==='finished'&&rejected(root,r,{json:dispatch.json})){ /* Original CLI disposition restored. */ }
        else if(dispatch.pre_submit_failure||dispatch.dispatch_version===2&&dispatch.state==='prepared')r.state='ready';
        if(r.state==='ready'){recordUnsubmitted(root,r,'original_dispatch_not_submitted');delete r.confirmation_quote;delete r.confirmation_sha256;}
        saveOperation(root,r);
      }
      if(r.state==='completed'||r.state==='terminal')return productionStatus(r);
      if(['preparing','awaiting_manifest_review'].includes(r.state)){
        if(localOnly)return productionStatus(r);
        await prepare(root,r,host,manifestReview);
        // Preparation never invokes, even when the quote is free.
        return r.state==='ready'?productionFinancialStatus(r,host):productionStatus(r);
      }
      if(r.state==='result_pending'&&(localOnly||!r.job_id)){await completeProduction(root,r,r.job,host);return productionStatus(r);}
      if(localOnly)return {...productionStatus(r),ok:false,code:1,next_action:'query_original_job'};
      if(action==='prepare'&&['ready','confirmation_required'].includes(r.state)){
        // A pre-upgrade confirmation also proves no invocation; preserve its hash
        // and append evidence before refreshing the mutable quotation.
        if(r.state==='confirmation_required'&&r.confirmation_sha256&&!r.not_submitted_id)recordUnsubmitted(root,r,'cli_confirmation');
        // Expire current pricing before any await; failure or interruption must
        // leave a preparation-only operation, with historical CLI evidence intact.
        r.state='preparing';delete r.quote;delete r.quote_evidence;delete r.confirmation_quote;delete r.confirmation_sha256;
        saveOperation(root,r);
        await verifyPlanSources(root,r.plan);
        assert(hash(json(root,base+'/input.json'))===r.input_sha256,'Prepared input changed');
        const quote=await host.cli(['quote',r.plan.operator,'--json','--json-file',resolve(root,base+'/input.json')]);
        if(quote.code!==0)throw Object.assign(fail('PUBLIC_QUOTE_FAILED'),{detail:quote});
        savePreparationQuote(r,quote);r.state='ready';delete r.confirmation_quote;delete r.confirmation_sha256;
        saveOperation(root,r);return productionFinancialStatus(r,host);
      }
      if(action==='submit'&&['ready','confirmation_required'].includes(r.state)){
        const observations={};
        const current=await planProduction(root,r.plan.stage,r.plan.files[0].path,host,observations,r.plan);
        if(observations.material_warnings)r.material_warnings=observations.material_warnings;
        assert(equivalentProductionPlans(current,r.plan),'Business inputs changed; prepare again before a new submission');
        await verifyPlanSources(root,r.plan);
        await verifyPublicReferences(root,r,host);
        assert(hash(json(root,base+'/input.json'))===r.input_sha256,'Prepared input changed');
        if(confirm)assert(r.confirmation_sha256===hash(confirm),'Confirmation belongs to another operation or attempt');
        const checked=await host.cli(['check']);if(checked.code!==0)throw Object.assign(fail('PUBLIC_ACCESS_NOT_READY'),{detail:checked});
        // Batch authorization is an additional constraint checked under the same operation lock.
        if(submissionGuard)await submissionGuard(r);
        // An old executor may have advanced since preparation. Never bypass a
        // newly observed legacy submission, including before CLI confirmation.
        const handoff=legacyHandoff(root,r.plan.stage,r.plan.target);
        if(handoff){
          // The batch may have reserved budget, but this attempt never reached
          // the CLI. Reuse the existing append-only non-dispatch proof.
          if(submissionGuard){recordUnsubmitted(root,r,'not_dispatched');saveOperation(root,r);}
          return {ok:false,code:1,operation_id:id,error:handoff,next_action:handoff.next_action};
        }
        const beforeSubmit=r.state;
        let result;
        try{
          result=await host.cli(['run',r.plan.operator,'--json-file',resolve(root,base+'/input.json'),'--no-wait',...(confirm?['--confirm',confirm]:[])],r,
            {onDispatch:()=>{delete r.recovery_id;delete r.rejection;r.state='submission_unknown';saveOperation(root,r);}});
        }catch(error){r.state=error.not_dispatched?beforeSubmit:'submission_unknown';if(error.not_dispatched)recordUnsubmitted(root,r,'not_dispatched');throw error;}
        if(result.not_dispatched){r.state=beforeSubmit;recordUnsubmitted(root,r,'not_dispatched');throw Object.assign(fail('PUBLIC_ACCESS_NOT_READY'),{detail:result});}
        r.state='submission_unknown';saveOperation(root,r);
        const recovery=/调用恢复 ID:\s*([a-f0-9-]{36})/i.exec(result.stderr??'')?.[1];if(recovery)r.recovery_id=recovery;
        const confirmation=confirmationFrom(result.stderr??'');
        if(result.code===3&&confirmation){
          r.confirmation_sha256=hash(confirmation.confirmation_token);r.state='confirmation_required';recordUnsubmitted(root,r,'cli_confirmation');
          const quote={estimatedPoints:confirmation.estimated_dumplings,postExecutionSettlement:confirmation.post_execution_settlement??null,
            formula:confirmation.formula,priceVersionTag:confirmation.price_version_tag};
          r.confirmation_quote=stripped(quote);saveOperation(root,r);
          return {...await productionFinancialStatus(r,host,quote,confirmation.balance),quote_source:'cli_confirmation',cli:result};
        }
        if(accepted(r,result)){
          immutable(root,base+'/accepted.json',{operator:r.plan.operator,json:stripped(result.json)});
          r.accepted_sha256=hash(json(root,base+'/accepted.json'));saveOperation(root,r);
          if(r.state==='result_pending'){immutable(root,base+'/success.json',r.job);await completeProduction(root,r,result.json,host);}
          return productionStatus(r);
        }
        if(!rejected(root,r,result)&&!recovery&&result.code===1&&/报价已变化或确认标识无效|报价响应缺少 priceVersionTag|参数校验失败:|余额不足：/.test(result.stderr??''))r.state='ready';
        if(r.state==='ready'){recordUnsubmitted(root,r,'cli_not_submitted');delete r.confirmation_quote;delete r.confirmation_sha256;}
        r.error={code:r.state==='submission_unknown'?'PUBLIC_SUBMISSION_UNKNOWN':'PUBLIC_NOT_SUBMITTED',
          ...(r.state==='ready'&&rechargeForFailure(result)?{recharge}:{})};saveOperation(root,r);return {...productionStatus(r),cli:result};
      }
      if(r.job_id){
        assert(hash(json(root,base+'/accepted.json'))===r.accepted_sha256,'Original receipt changed');
        const result=await queryOriginal(root,r,host);
        if(result.code!==0)throw Object.assign(fail('PUBLIC_QUERY_FAILED'),{detail:result});
        assert(accepted(r,result),'Missing original Job response');saveOperation(root,r);
        if(r.state==='result_pending'){
          immutable(root,base+'/success.json',r.job);
          await completeProduction(root,r,result.json,host);
        }
      }else if(r.state==='submission_unknown'&&r.recovery_id){
        const result=await host.cli(['resume',r.recovery_id]);
        if(accepted(r,result)){
          immutable(root,base+'/accepted.json',{operator:r.plan.operator,json:stripped(result.json)});r.accepted_sha256=hash(json(root,base+'/accepted.json'));saveOperation(root,r);
          if(r.state==='result_pending'){await completeProduction(root,r,result.json,host);}
        }else if(rejected(root,r,result)){if(r.state==='ready'){recordUnsubmitted(root,r,'cli_not_submitted');delete r.confirmation_quote;delete r.confirmation_sha256;}saveOperation(root,r);}
        else throw Object.assign(fail('PUBLIC_ORIGINAL_RECOVERY_REQUIRED'),{detail:result});
      }
      if(r.state==='submission_unknown'&&!r.recovery_id){r.error={code:'PUBLIC_ORIGINAL_RECOVERY_REQUIRED',message:'未取得原调用恢复 ID；保留输入与提交证据，核对原调用。不可通过重新 run 解除此状态。'};saveOperation(root,r);}
      return r.state==='ready'?productionFinancialStatus(r,host):productionStatus(r);
    }catch(error){if(['preparing','ready','confirmation_required'].includes(r.state)&&/SOURCE_CHANGED|Business inputs changed|Immutable production evidence changed/.test(error.message??''))error=fail('PUBLIC_INPUT_CHANGED','输入或已上传引用已改变；保留原准备记录，使用新 --attempt 重新准备、询价和确认。');r.error={code:error.code??'PUBLIC_LOCAL_VALIDATION_FAILED',message:error.code?error.message:'本地输入或证据检查失败；修复后继续原操作。',...(rechargeForFailure(error.detail)?{recharge}:{})};saveOperation(root,r);return {...productionStatus(r),...(r.state==='result_pending'?{artifact_directory:base+'/artifacts'}:{}),...(error.detail?{detail:error.detail}:{})};}
  });
}

export async function recoverAttachments(root,id,host,{localOnly=false}={}){
  return withProductionOperation(root,id,async()=>{
    const r=loadProduction(root,id),base=baseOf(r);
    assert(r.state==='completed'&&r.plan.stage==='clips','Primary Clip result must already be completed');
    try{
      let live=json(root,base+'/success.json');
      if(!localOnly){
        assert(hash(json(root,base+'/accepted.json'))===r.accepted_sha256,'Original receipt changed');
        const result=await queryOriginal(root,r,host);assert(result.code===0,'Original Job query failed');live=result.json;
      }
      const recovered=await recoverProductionAttachment(root,r,live,host);
      r.attachment=recovered.attachment;r.attachment_warnings=[];delete r.attachment_error;saveOperation(root,r);
      return {...productionStatus(r),...recovered};
    }catch(error){
      r.attachment_error={code:error.code??'CLIP_ATTACHMENT_RECOVERY_FAILED',message:'附件暂未补齐，可修正后重试；已完成分镜和视频流程不受影响。'};saveOperation(root,r);
      return {...productionStatus(r),ok:false,code:1,error:r.attachment_error,next_action:'recover-clip-attachments',artifact_directory:base+'/artifacts'};
    }
  });
}
