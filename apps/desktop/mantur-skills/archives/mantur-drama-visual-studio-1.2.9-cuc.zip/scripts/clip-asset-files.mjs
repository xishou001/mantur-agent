// Optional file identity lookup for the current Seedance selections only.
// No shared cache, credential reads, legacy-state migration or operator submission.
import assert from 'node:assert/strict';
import {relative,resolve} from 'node:path';
import {business} from './production-plans.mjs';
import {checked,directory,fact,hash,json,operations,stripped} from './production-state.mjs';

const available=file=>typeof file?.fileId==='string'&&file.fileId.trim().length>0&&file.fileId.length<=512
  &&!/[\x00-\x20\x7f]/.test(file.fileId)
  &&(file.retentionExpiresAt===undefined||Number.isFinite(Date.parse(file.retentionExpiresAt))&&Date.parse(file.retentionExpiresAt)>Date.now());
const same=(file,selection)=>file.sha256===selection.sha256&&(file.bytes??file.sizeBytes)===selection.bytes;
const receipt=(file,selection)=>({status:'AVAILABLE',fileId:file.fileId,sha256:selection.sha256,sizeBytes:selection.bytes});

function original(root,source){
  const base=directory(source.operation_id),plan=json(root,base+'/plan.json');
  assert(hash(json(root,base+'/operation.json'))===hash(source),'Source operation changed');
  assert(source.schema_version===1&&source.transport==='public-cli-v1'&&source.project===resolve(root)
    &&source.state==='completed'&&source.job_id&&source.job_status==='SUCCEEDED','Incomplete source');
  assert(hash(plan)===source.plan_sha256&&hash(source.plan)===source.plan_sha256,'Source plan changed');
  const accepted=json(root,base+'/accepted.json'),success=json(root,base+'/success.json');
  assert(hash(accepted)===source.accepted_sha256&&(accepted.json?.jobId??accepted.json?.job_id)===source.job_id
    &&(accepted.operator??accepted.json.apiCode)===plan.operator,'Source receipt changed');
  assert(success.jobId===source.job_id&&success.apiCode===plan.operator&&success.status==='SUCCEEDED'
    &&hash(success.output)===hash(source.job?.output),'Source result changed');
  assert(hash(json(root,base+'/input.json'))===source.input_sha256,'Source input changed');
  return {base,plan,success};
}

async function candidates(root,selection,sources){
  const result=[];
  for(const source of sources){
    try{
      const {base,plan,success}=original(root,source);
      if(plan.stage==='material'&&plan.metadata.voice===(selection.role==='VOICE')
        &&plan.metadata.asset_id===(selection.role==='VOICE'?selection.base_asset_id:selection.asset_id)){
        const media=business.assetOutputs(plan.metadata.kind,success.output).media;
        const publication=json(root,base+'/publication.json');
        for(const [index,local]of publication.media.entries()){
          const remote=media[index];
          if(!same(local,selection)||!available(remote)||remote.sha256!==undefined&&remote.sha256!==selection.sha256)continue;
          assert(local.path.startsWith(base+`/artifacts/${index}.`),'Candidate order changed');
          const bytes=await business.inspectAssetMedia(root,local.path,selection.role==='VOICE'?'audio':'image');
          assert(same(bytes,selection)&&bytes.mime_type===selection.mime,'Candidate bytes changed');
          result.push({source,file:remote,index,receipt_path:base+'/success.json',kind:'generated',
            evidence:[fact(root,base+'/publication.json'),fact(root,local.path)],
            preferred:selection.review_id===source.operation_id||selection.review_id===source.material_review?.review_id});
        }
      }
      for(const row of source.uploads??[]){
        if(!same(row.receipt??{},selection)||row.receipt.status!=='AVAILABLE'||!available(row.receipt))continue;
        // Only genuine upload-worker receipts owned by this original operation.
        const receiptPath=typeof row.receipt_path==='string'?row.receipt_path.replaceAll('\\','/'):'';
        const match=/^\.pipeline-state\/runtime\/public-uploads\/([a-f0-9]{64})\/([a-f0-9-]{36})\.json\.receipt$/.exec(receiptPath);
        if(!match)continue;
        const uploaded=json(root,receiptPath),attempt=json(root,receiptPath.slice(0,-'.receipt'.length));
        const key=hash(JSON.stringify({scope:source.operation_id,source:relative(root,checked(root,row.path)),sha256:selection.sha256,sizeBytes:selection.bytes}));
        assert(match[1]===key&&attempt.schemaVersion===1&&attempt.key===key&&!attempt.superseded
          &&hash(uploaded)===hash(row.receipt)&&same(fact(root,row.path),selection),'Upload provenance changed');
        result.push({source,file:uploaded,receipt_path:receiptPath,kind:'uploaded',preferred:false,
          evidence:[fact(root,receiptPath),fact(root,receiptPath.slice(0,-'.receipt'.length)),fact(root,row.path)]});
      }
    }catch{ /* An incomplete/unverifiable historical record is a cache miss. */ }
  }
  return result.sort((a,b)=>Number(b.preferred)-Number(a.preferred)||a.source.operation_id.localeCompare(b.source.operation_id)
    ||a.file.fileId.localeCompare(b.file.fileId));
}

/** The planner already chose one adopted file per asset/role. Match those exact
 * bytes, never another candidate of the same character or the newest picture.
 * Query the original Job through the current public CLI before sharing its file.
 */
export function clipAssetFiles(root,operation,host){
  let sources;
  const observations=new Map();
  return async path=>{
    if(operation.plan.stage!=='clips'||operation.plan.metadata.wan)return;
    const selection=operation.plan.metadata.candidate.selections.find(item=>item.path===path);
    if(!selection)return; // Scripts and the newly assembled manifest keep their upload path.
    const current=fact(root,path);assert(same(current,selection),'Selected asset changed');
    const saved=operation.uploads.find(row=>row.path===path);
    if(saved){
      assert(saved.receipt?.status==='AVAILABLE'&&available(saved.receipt)&&same(saved.receipt,selection),'Prepared asset reference changed');
      return {ok:true,...saved,reused:true}; // Preserve this preparation's original file identity.
    }
    sources??=operations(root).filter(row=>row.operation_id!==operation.operation_id);
    for(const candidate of await candidates(root,selection,sources)){
      try{
        const source=candidate.source,base=directory(source.operation_id);
        if(!observations.has(source.operation_id)){
          observations.set(source.operation_id,await host.cli(['status','--receipt',resolve(root,base+'/accepted.json')]).catch(()=>undefined));
        }
        const response=observations.get(source.operation_id),live=response?.json;
        assert(response?.code===0&&(live?.jobId??live?.job_id)===source.job_id&&live.status==='SUCCEEDED'
          &&(!live.apiCode||live.apiCode===source.plan.operator)&&live.output,'Original Job unavailable');
        if(candidate.kind==='generated'){
          const media=business.assetOutputs(source.plan.metadata.kind,live.output).media;
          const remote=media[candidate.index];
          assert(available(remote)&&remote.fileId===candidate.file.fileId
            &&(remote.sha256===undefined||remote.sha256===selection.sha256),'Original file identity changed');
        }else assert(hash(stripped(live.output))===hash(json(root,base+'/success.json').output),'Original result changed');
        original(root,source); // Recheck local evidence after the asynchronous query.
        for(const expected of candidate.evidence)assert(fact(root,expected.path).sha256===expected.sha256,'File evidence changed');
        assert(available(candidate.file),'Original file expired');
        assert(same(fact(root,path),selection),'Selected asset changed');
        return {ok:true,reused:true,receipt:receipt(candidate.file,selection),receipt_path:candidate.receipt_path,
          reuse_source:{operation_id:source.operation_id,kind:candidate.kind,...(candidate.index===undefined?{}:{candidate_index:candidate.index})}};
      }catch{ /* No successful proof under the current access: use normal upload. */ }
    }
  };
}
