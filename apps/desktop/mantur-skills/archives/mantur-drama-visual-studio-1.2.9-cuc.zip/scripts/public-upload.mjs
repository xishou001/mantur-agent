import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { fork } from 'node:child_process';
import { lstatSync, mkdirSync, readFileSync, readdirSync, realpathSync, renameSync, writeFileSync } from 'node:fs';
import { dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { child } from './access.mjs';
import { createPublicCli } from './cli-client.mjs';
import { withProjectLock } from '../runtime/project-lock.mjs';
import { inspectProcess } from '../runtime/process-identity.mjs';

const digest = value => createHash('sha256').update(value).digest('hex');
function safe(root, path) {
  const absolute = resolve(root, path), rel = relative(root, absolute);
  assert(rel && !rel.startsWith('..') && !isAbsolute(rel), 'Upload path must be inside the project');
  let cursor = root;
  for (const part of rel.split(/[\\/]/)) {
    cursor = join(cursor, part);
    assert(!lstatSync(cursor, { throwIfNoEntry: false })?.isSymbolicLink(), 'Unsafe upload path');
  }
  return absolute;
}
function write(path, value) {
  const temporary = path + '.' + randomUUID() + '.tmp';
  writeFileSync(temporary, JSON.stringify(value) + '\n', { flag: 'wx', mode: 0o600 });
  renameSync(temporary, path);
}
const read = path => JSON.parse(readFileSync(path, 'utf8'));
function validReceipt(receipt, expected) {
  assert(receipt.status === 'AVAILABLE' && typeof receipt.fileId === 'string' && receipt.fileId.trim().length > 0 && receipt.fileId.length <= 512
    && receipt.sha256 === expected.sha256 && receipt.sizeBytes === expected.sizeBytes, 'UPLOAD_RECEIPT_MISMATCH');
  return { fileId: receipt.fileId, status: receipt.status, sha256: receipt.sha256, sizeBytes: receipt.sizeBytes };
}

function ownedUpload(attempt, receiptFile, expected) {
  return (entry, args, env, options) => {
    if (args[0] !== 'upload') return child(entry, args, env, options);
    return new Promise((resolveResult, reject) => {
      const proc = fork(new URL('./public-upload-worker.mjs', import.meta.url), [], {
        env, execArgv: [], windowsHide: true, stdio: ['ignore', 'ignore', 'ignore', 'ipc'],
      });
      let timedOut = false, launchError;
      const timer = setTimeout(() => { timedOut = true; proc.kill(); }, options.timeout || 300_000);
      proc.once('message', message => {
        try {
          assert(message?.type === 'ready' && message.pid === proc.pid, 'Invalid upload owner');
          write(attempt, { ...read(attempt), state: 'running', pid: message.pid, identity: message.identity, ownerRecordedAt: new Date().toISOString() });
          proc.send({ type: 'go', entry, args, receiptFile, expected }, error => {
            if (error) { launchError = error; proc.kill(); }
          });
        } catch (error) { launchError = error; proc.kill(); }
      });
      proc.once('error', error => {
        launchError = error;
        if (proc.pid) proc.kill(); // Wait for close before permitting another upload.
        else { clearTimeout(timer); reject(error); }
      });
      proc.once('close', (code, signal) => {
        clearTimeout(timer);
        if (launchError) reject(launchError);
        else resolveResult({ code: timedOut || signal ? 1 : code ?? 1,
          stdout: lstatSync(receiptFile, { throwIfNoEntry: false }) ? readFileSync(receiptFile, 'utf8') : '', stderr: '' });
      });
    });
  };
}

/** One continuation = at most one independent upload, never an operator run. */
export async function uploadProjectFile({ project, file, scope, renew = false, profile, bindingArgs, env, run }) {
  assert(typeof scope === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(scope), 'Use --scope <business-operation-id>');
  const root = realpathSync(project), source = safe(root, file);
  const sourceStat = lstatSync(source);
  assert(sourceStat.isFile(), 'Upload requires a regular project file');
  assert(sourceStat.size > 0 && sourceStat.size <= 512 * 1024 * 1024, 'Upload file size is invalid');
  const bytes = readFileSync(source), expected = { sha256: digest(bytes), sizeBytes: bytes.length };
  assert(bytes.length > 0 && bytes.length <= 512 * 1024 * 1024, 'Upload file size is invalid');
  const key = digest(JSON.stringify({ scope, source: relative(root, source), ...expected }));
  const directory = safe(root, `.pipeline-state/runtime/public-uploads/${key}`);
  mkdirSync(directory, { recursive: true });
  const cliOptions = { profile, bindingArgs, projectDir: root, bindingPath: '.pipeline-state/public-cli-binding.json', env };
  return withProjectLock(directory + '.lock', async () => {
    const unchanged = () => assert(digest(readFileSync(source)) === expected.sha256, 'UPLOAD_SOURCE_CHANGED: retry with the current file');
    unchanged();
    const readiness = await createPublicCli({ ...cliOptions, run }).check();
    if (readiness.code !== 0) return { ...readiness, ok: false, next_action: 'repair_access_then_retry_upload' };
    // Inspect every owner before choosing a receipt or starting a replacement.
    const completed = [];
    for (const name of readdirSync(directory).filter(name => /^[a-f0-9-]{36}\.json$/.test(name))) {
      const attemptFile = safe(root, join(directory, name)), attempt = read(attemptFile);
      assert(attempt.schemaVersion === 1 && attempt.key === key, 'Invalid upload attempt');
      const receiptFile = attemptFile + '.receipt';
      if (lstatSync(receiptFile, { throwIfNoEntry: false })) {
        const receipt = validReceipt(read(safe(root, receiptFile)), expected);
        if (!attempt.superseded) completed.push({ attemptFile, attempt, receiptFile, receipt });
        continue;
      }
      if (attempt.state === 'running') {
        const owner = await inspectProcess(attempt.pid);
        const dead = owner.state === 'dead' || owner.state === 'alive' && (
          attempt.identity && owner.identity && attempt.identity !== owner.identity
          || !attempt.identity && owner.startedAt && Number.isFinite(Date.parse(attempt.ownerRecordedAt))
            && owner.startedAt > Date.parse(attempt.ownerRecordedAt) + 2000);
        if (!dead) return { ok: false, code: 1, error: { code: 'UPLOAD_PROCESS_ACTIVE_OR_UNKNOWN' }, next_action: 'observe_original_upload', retryable: true };
        write(attemptFile, { ...attempt, state: 'unconfirmed' });
      }
      // A starting attempt has not received go. If its parent died, no upload can have begun.
    }
    if (!renew && completed.length) {
      unchanged();
      const { receiptFile, receipt } = completed.at(-1);
      return { ok: true, code: 0, reused: true, receipt, receipt_path: relative(root, receiptFile), next_action: 'prepare_operator_input' };
    }
    if (renew) for (const { attemptFile, attempt } of completed) {
      // Keep original successful receipts; never modify a production input or CLI invocation.
      write(attemptFile, { ...attempt, superseded: true, supersededReason: 'explicit_upload_renewal' });
    }
    const attemptFile = join(directory, randomUUID() + '.json'), receiptFile = attemptFile + '.receipt';
    write(attemptFile, { schemaVersion: 1, key, state: 'starting', createdAt: new Date().toISOString() });
    try {
      const runner = run ?? ownedUpload(attemptFile, receiptFile, expected);
      const receipt = validReceipt(await createPublicCli({ ...cliOptions, run: runner }).upload(source), expected);
      if (!lstatSync(receiptFile, { throwIfNoEntry: false })) write(receiptFile, receipt);
      write(attemptFile, { ...read(attemptFile), state: 'available' });
      unchanged();
      return { ok: true, code: 0, reused: false, receipt, receipt_path: relative(root, receiptFile), next_action: 'prepare_operator_input' };
    } catch {
      // The owned process has closed. A success receipt wins even if later bookkeeping failed.
      if (lstatSync(receiptFile, { throwIfNoEntry: false })) {
        unchanged();
        return { ok: true, code: 0, reused: true,
          receipt: validReceipt(read(receiptFile), expected), receipt_path: relative(root, receiptFile), next_action: 'prepare_operator_input' };
      }
      write(attemptFile, { ...read(attemptFile), state: 'unconfirmed' });
      return { ok: false, code: 1, error: { code: 'UPLOAD_RESULT_UNCONFIRMED' }, retryable: true,
        next_action: 'retry_same_upload', message: '可重试独立上传；上次可能已创建远端文件。此次没有执行算子。' };
    }
  }, 1000);
}
