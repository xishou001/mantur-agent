import assert from 'node:assert/strict';
import {withProductionOperation} from './production-writer.mjs';
import {loadProduction} from './production.mjs';
import {business} from './production-plans.mjs';
import {json,hash,immutable,directory,save} from './production-state.mjs';

/** No writes, downloads or CLI calls; valid for already paid, completed operations too. */
export async function productionReviewBaseline(root,id){
  const r=loadProduction(root,id),m=r.plan.metadata;
  assert(r.plan.stage==='material'&&r.state==='completed'&&r.job_status==='SUCCEEDED','Original material is not complete');
  const baseline=await business.assetSelectionBaseline(root,m.asset_id,m.voice);
  assert(baseline.target_hash===m.target_hash,'Asset requirement changed');
  const result=json(root,directory(id)+'/publication.json');
  assert(Array.isArray(result.media)&&result.media.length,'Original material has no media candidates');
  return {ok:true,read_only:true,operation_id:id,asset_id:m.asset_id,media_kind:m.voice?'audio':'image',...baseline,
    candidates:result.media.map((media,candidate_index)=>({candidate_index,path:media.path,media_sha256:media.sha256})),
    next_action:baseline.replacement_blocker?'inspect_downstream_dependencies':'apply-asset-review'};
}

/** Local adoption only: never calls CLI run, synthesizes an approval, or replaces a newer selection. */
export async function reviewProductionAsset(root,input,host){
  const review=json(root,input),id=review.operation_id;
  return withProductionOperation(root,id,async()=>{
    const r=loadProduction(root,id),m=r.plan.metadata;
    const technical=m.voice&&review.review_origin==='technical_audio_completion';
    assert(r.plan.stage==='material'&&r.state==='completed'&&r.job_status==='SUCCEEDED','Original material is not complete');
    assert(review.schema_version===1&&review.asset_id===m.asset_id&&(technical?!Object.hasOwn(review,'user_confirmed'):review.user_confirmed===true)
      &&['passed','rejected'].includes(review.review_status),'Explicit material selection is required');
    assert(review.media_kind===(m.voice?'audio':'image')&&Number.isSafeInteger(review.candidate_index),'Invalid selected media');
    const result=json(root,directory(id)+'/publication.json');let candidate=result.media[review.candidate_index];
    assert(candidate,'Candidate changed');
    if(technical){
      assert(review.review_status==='passed'&&r.material_review?.status!=='rejected'&&review.candidate_count===1&&result.media.length===1&&review.unique_match===true,'Technical audio selection must be unique and not rejected');
      assert(Array.isArray(review.selection_evidence)&&review.selection_evidence.length>0&&review.selection_evidence.every(e=>typeof e==='string'&&e.trim()),'Technical audio evidence required');
    }
    assert((await business.inspectAssetMedia(root,candidate.path,review.media_kind)).sha256===candidate.sha256,'Candidate bytes changed');
    if(review.audio_derivation){
      const d=review.audio_derivation;assert(m.voice&&d.method==='transcode'&&d.source_sha256===candidate.sha256&&Array.isArray(d.evidence)&&d.evidence.length,'Invalid audio derivation');
      const converted=await business.inspectAssetMedia(root,d.output_path,'audio',{audioIntake:true});
      assert(converted.sha256===d.output_sha256&&converted.path!==candidate.path&&Math.abs(converted.duration_seconds-candidate.duration_seconds)<=0.25,'Audio derivation changed');candidate=converted;
    }
    assert(candidate.sha256===review.media_sha256,'Selected media changed');
    const p=await business.assetProject(root,m.asset_id,m.voice);assert(p.targetHash===m.target_hash,'Asset requirement changed');
    assert(Object.hasOwn(review,'expected_previous_sha256')&&Array.isArray(review.evidence)&&review.evidence.length>0,'Selection baseline and evidence required');
    const reviewId=hash({binding:p.binding,review});immutable(root,`.pipeline-state/runtime/asset-reviews/${reviewId}/review.json`,review);
    const finish=async result=>{save(root,directory(id)+'/operation.json',{...r,material_review:{review_id:reviewId,status:review.review_status,...(result.snapshot_refresh?{snapshot_refresh:result.snapshot_refresh}:{}),...(result.snapshot_cleanup?{snapshot_cleanup:result.snapshot_cleanup}:{})},updated_at:new Date().toISOString()});if(!result.snapshot_refresh&&result.snapshot_cleanup?.ok!==false)try{await host.refresh();}catch{}return result;};
    if(review.review_status==='rejected')return finish({ok:true,saved:false,review_id:reviewId,disposition:'rejected',next_action:'choose_another_candidate_or_authorize_new_generation'});
    assert(review.unique_match===true,'Select one uniquely matched candidate');
    return finish({ok:true,...await business.publishAssetSelection(root,{asset_id:m.asset_id,voice:m.voice,media:[candidate],source:m.voice?'custom_generated':'generated',
      review_status:'passed',review_id:reviewId,expected_previous_sha256:review.expected_previous_sha256,target_hash:m.target_hash,
      ...(technical?{technical_audio_completion:true,technical_source_sha256:review.audio_derivation?.source_sha256??candidate.sha256}:{}),
      ...(m.reference_base_sha256?{reference_base_sha256:m.reference_base_sha256}:{}),...(result.voice_id?{voice_id:result.voice_id}:{})},host.refresh)});
  });
}
