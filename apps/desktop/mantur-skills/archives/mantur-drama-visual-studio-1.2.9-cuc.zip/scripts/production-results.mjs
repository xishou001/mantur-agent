import assert from 'node:assert/strict';
import {lstatSync,copyFileSync,readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {business} from './production-plans.mjs';
import {directory,fact,hash,json,save,immutable,stripped,fail,checked} from './production-state.mjs';

export async function download(root,host,remote,path,kind){
  if(!lstatSync(checked(root,path),{throwIfNoEntry:false})){
    const url=remote.url??remote.downloadUrl??remote.download_url;
    if(!url)throw fail('PUBLIC_ARTIFACT_URL_REQUIRED','原结果没有可下载的公开 URL；重新查询原 Job，或将原产物放入指定路径后以 local-only 继续。不得重新生成。');
    await host.download(url,resolve(root,path));
  }
  const file=kind?await (kind==='video'?business.inspectVideoMedia(root,path,'video'):business.inspectAssetMedia(root,path,kind)):fact(root,path);
  if(remote.sha256)assert(file.sha256===remote.sha256,'Downloaded artifact SHA256 differs from original result');
  return file;
}
// A companion is an append-only delivery, never a replacement of the imported report.
export async function recoverProductionAttachment(root,r,live,host){
  assert(r.plan.stage==='clips'&&r.state==='completed','Complete the primary result before recovering its attachment');
  const base=directory(r.operation_id),first=json(root,base+'/success.json');
  const current=jobForIntake(r,live);
  assert(first.jobId===current.jobId&&first.apiCode===current.apiCode,'Original successful Job changed');
  const rows=live.output.artifacts;assert(Array.isArray(rows),'Missing original artifacts');
  for(const previous of first.output.artifacts??[]){
    const matches=rows.filter(row=>row.role===previous.role);
    assert(matches.length===1&&matches[0].fileId===previous.fileId&&matches[0].sha256===previous.sha256,'Original artifact identity changed');
  }
  const found=rows.filter(row=>row.role==='TABULAR_XLSX');
  if(!found.length)throw fail('CLIP_ATTACHMENT_PENDING','原任务尚未提供附件，可稍后继续；已导入分镜仍可制作视频。');
  assert(found.length===1&&found[0].fileId&&/^[a-f0-9]{64}$/.test(found[0].sha256),'Invalid companion identity');
  const attachment=await download(root,host,found[0],base+'/artifacts/TABULAR_XLSX.xlsx');
  const entries=business.inspectArchive(readFileSync(checked(root,attachment.path)),{maxEntries:256,maxEntryBytes:16*1024*1024,maxTotalBytes:64*1024*1024});
  assert(['[Content_Types].xml','xl/workbook.xml','xl/_rels/workbook.xml.rels'].every(name=>entries.some(entry=>entry.name===name))&&entries.some(entry=>/^xl\/worksheets\/sheet\d+\.xml$/.test(entry.name)),'CLIP_XLSX_INVALID');
  immutable(root,base+'/attachment-recovery.json',{schema_version:1,operation_id:r.operation_id,job_id:r.job_id,original_success_sha256:hash(first),file_id:found[0].fileId,...attachment});
  return {attachment,production_result_preserved:true};
}
function jobForIntake(r,live){
  assert(!live.apiCode||live.apiCode===r.plan.operator,'Result operator changed');
  const id=live.jobId??live.job_id;
  assert(!r.job_id||id===r.job_id,'Result Job changed');
  assert(String(live.status??'SUCCEEDED').toUpperCase()==='SUCCEEDED'&&live.output&&!live.errorCode&&!live.errorMessage,'Original result is not successful');
  return {apiCode:r.plan.operator,...(id?{jobId:id}:{}),status:'SUCCEEDED',output:stripped(live.output)};
}
export async function finishProduction(root,r,live,host){
  const base=directory(r.operation_id),plan=r.plan,m=plan.metadata,job=jobForIntake(r,live);
  immutable(root,base+'/success.json',job);
  if(plan.stage==='extraction'||plan.stage==='clips'){
    const artifacts=live.output.artifacts;
    assert(Array.isArray(artifacts),'Missing original artifacts');
    const paths={};
    const frozenIntake=lstatSync(checked(root,base+'/intake.json'),{throwIfNoEntry:false})?json(root,base+'/intake.json'):null;
    r.attachment_warnings=[];
    for(const [role,extension]of [['PRIMARY_JSON','json'],['TABULAR_XLSX','xlsx']]){
      const rows=artifacts.filter(a=>a.role===role);
      const optional=role==='TABULAR_XLSX'&&plan.stage==='clips';
      if(optional&&(!rows.length||frozenIntake&&!frozenIntake.tabular_xlsx)){
        r.attachment_warnings.push({code:'CLIP_XLSX_PENDING',production_usable:true,attachment_complete:false});continue;
      }
      assert(rows.length===1&&rows[0].fileId&&/^[a-f0-9]{64}$/.test(rows[0].sha256),'Invalid original artifact identity');
      const path=base+'/artifacts/'+role+'.'+extension;
      try{await download(root,host,rows[0],path);paths[role]=path;}
      catch(error){
        // Only an unavailable optional attachment can degrade. Existing corrupt bytes,
        // ambiguous identities and an already frozen attachment remain hard failures.
        if(!optional||frozenIntake?.tabular_xlsx||lstatSync(checked(root,path),{throwIfNoEntry:false}))throw error;
        r.attachment_warnings.push({code:'CLIP_XLSX_PENDING',production_usable:true,attachment_complete:false});
      }
    }
    const descriptor={schema_version:1,script:m.script,primary_json:paths.PRIMARY_JSON,...(paths.TABULAR_XLSX?{tabular_xlsx:paths.TABULAR_XLSX}:{}),job:base+'/success.json',episodes:m.episodes};
    if(plan.stage==='clips'){
      if(m.wan)Object.assign(descriptor,{schema_version:2,production_asset_table:m.production_asset_table,compilation_request:base+'/input.json',...(m.media_mapping?{media_mapping:m.media_mapping}:{})});
      else {immutable(root,base+'/compilation-request.json',{mode:'ASYNC',input:json(root,base+'/input.json')});Object.assign(descriptor,{requirements:m.requirements,production_manifest:base+'/manifest.json',media_mapping:base+'/mapping.json',compilation_request:base+'/compilation-request.json'});}
    }
    immutable(root,base+'/intake.json',descriptor);
    return plan.stage==='extraction'?business.importAssetExtraction(root,base+'/intake.json',{refresh:host.refresh}):business.importClipCompilation(root,base+'/intake.json',{refresh:host.refresh});
  }
  if(plan.stage==='material'){
    if(r.output_schema&&r.validated_output_sha256!==hash(job.output)){business.validateAssetOutputSchema(m.kind,r.output_schema,live.output);r.validated_output_sha256=hash(job.output);}
    const result=business.assetOutputs(m.kind,live.output);
    if(result.analysis){immutable(root,base+'/analysis.json',{schema_version:1,asset_id:m.asset_id,analysis:stripped(result.analysis)});return {analysis:base+'/analysis.json',review_status:'pending'};}
    const media=[];
    for(const [index,remote]of result.media.entries()){
      const kind=remote.kind,raw=base+`/artifacts/${index}.bin`;
      await download(root,host,remote,raw);
      const ext=await business.assetMediaExtension(root,raw,kind),path=base+`/artifacts/${index}${ext}`;
      if(!lstatSync(checked(root,path),{throwIfNoEntry:false}))copyFileSync(checked(root,raw),checked(root,path));
      media.push(await download(root,host,remote,path,kind));
    }
    assert(media.length,'Missing generated media');
    // Keep result publication idempotent; a dashboard refresh can fail without regenerating media.
    const publication=base+'/publication.json';
    if(lstatSync(checked(root,publication),{throwIfNoEntry:false}))return json(root,publication);
    const current=await business.assetProject(root,m.asset_id,m.voice);assert(current.targetHash===m.target_hash,'Asset requirement changed');
    const automatic=m.kind==='image'&&!await business.hasStoryboards(root)&&m.generation_intent!=='regenerate'&&m.baseline?.expected_previous_sha256==null;
    if(!automatic||media.length!==1){
      const candidate={saved:false,media,voice_id:result.voiceId??null,review_status:'pending',next_action:'apply_asset_review',operation_id:r.operation_id,candidate_created_at:new Date().toISOString()};
      save(root,publication,candidate);return candidate;
    }
    const published=await business.publishAssetSelection(root,{asset_id:m.asset_id,voice:m.voice,media,
      source:m.kind==='image'?'generated':'custom_generated',review_status:automatic?'passed':'pending',review_id:r.operation_id,
      ...(m.baseline?{expected_previous_sha256:m.baseline.expected_previous_sha256}:{}),...(result.voiceId?{voice_id:result.voiceId}:{}),
      target_hash:m.target_hash,operation_id:r.operation_id,...(automatic?{generated_image_completion:true,automatic:true}:{}),
      ...(m.reference_base_sha256?{reference_base_sha256:m.reference_base_sha256}:{}),
      evidence:[base+'/accepted.json',base+'/success.json']},host.refresh);
    save(root,publication,{...published,media,review_status:automatic?'passed':'pending'});return json(root,publication);
  }
  const output=business.inspectVideoOutput(live.output);
  assert(output.videos.length===1&&output.continuity_supported&&output.tail&&output.tail_source==='final_video','Video result lacks a verified real final frame');
  const video=await download(root,host,output.videos[0],base+'/artifacts/video.mp4','video');
  const tail=await download(root,host,output.tail,base+'/artifacts/tail.'+(output.tail.mime_type==='image/jpeg'?'jpg':'png'),'image');
  assert(video.width===tail.width&&video.height===tail.height,'Video/tail dimensions differ');
  const id=`VIDEO-${r.operation_id}-0`;
  const c=await business.videoSelectionForRun(root,{run_id:id,clip_id:m.descriptor.clip_id,transport:'public-cli-v1',clip_binding_sha256:hash(m.binding)});
  r.material_warnings=c.materialWarnings??[];
  r.creative_warnings=business.videoCreativeWarnings(json(root,base+'/input.json'),[video]);
  if([[output.videos[0],video],[output.tail,tail]].some(([remote,local])=>remote.sha256===local.sha256&&
    (['width','height'].some(key=>remote[key]!==undefined&&remote[key]!==local[key])||remote.duration_seconds!==undefined&&Math.abs(remote.duration_seconds-(local.duration_seconds??0))>=0.1)))
    r.creative_warnings.push({code:'VIDEO_REMOTE_FACTS_ADVISORY'});
  assert(await business.matchingVideoBinding(root,c,hash(m.binding)),'Video inputs changed');
  await business.preserveVideoInputBindings(root,c);
  const privateResult=base+'/video-result.json';
  immutable(root,privateResult,{schema_version:1,transport:'public-cli-v1',run_id:id,operation_id:r.operation_id,job_id:r.job_id,
    request_sha256:r.input_sha256,accepted_sha256:r.accepted_sha256,success_sha256:hash(job),binding_sha256:hash(m.binding),
    video_sha256:video.sha256,tail_sha256:tail.sha256,tail_file_id:output.tail.file_id,tail_media_ref:output.tail.media_ref??null});
  const runPath=`.pipeline-state/runs/${id}.json`;
  if(!lstatSync(checked(root,runPath),{throwIfNoEntry:false}))await business.publishVideoRun(root,{
    schema_version:1,source_profile:m.profile,transport:'public-cli-v1',run_id:id,clip_id:m.descriptor.clip_id,attempt:m.descriptor.attempt,
    ...(m.storyboard_revision?{storyboard_revision:m.storyboard_revision}:{}),stage:'video_generation',status:'waiting_for_approval',remote_status:'SUCCEEDED',
    local_video:video.path,video_sha256:video.sha256,local_last_frame:tail.path,last_frame_sha256:tail.sha256,tail_frame_is_real:true,tail_frame_source_sha256:video.sha256,
    production_lineage_verified:true,validation_status:'pending',request_sha256:r.input_sha256,clip_binding_sha256:hash(m.binding),private_result:privateResult,
    ...(m.previous?{previous_clip_id:m.previous,previous_run_id:m.tail.run_id,previous_tail_sha256:m.tail.sha256}:{}),updated_at:new Date().toISOString()
  },async()=>({revision:0}));
  const result=await business.completeVideoTechnically(root,id);
  try{await host.refresh();}catch{/* Optional dashboard is not the delivery gate. */}
  return result;
}
