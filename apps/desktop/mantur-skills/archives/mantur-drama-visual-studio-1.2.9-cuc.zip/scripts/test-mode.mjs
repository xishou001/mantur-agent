// Explicit process configuration and non-secret project binding. No credentials or HTTP.
import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { existsSync, linkSync, lstatSync, readFileSync, realpathSync, unlinkSync, writeFileSync } from 'node:fs';
import { dirname, isAbsolute, join, parse, relative, resolve, sep } from 'node:path';

export const productionBase = 'https://hub.mantur.ai';
export function selectEnvironment(profile, env, home, binding) {
  const mode = env.MANTURHUB_SKILL_ENV ?? 'production';
  assert(['production', 'test'].includes(mode), 'MANTURHUB_SKILL_ENV must be production or test');
  if (mode === 'production') {
    assert(!env.MANTURHUB_BASE || env.MANTURHUB_BASE.replace(/\/$/, '') === productionBase,
      'TEST_MODE_REQUIRED: a different gateway requires explicit MANTURHUB_SKILL_ENV=test');
    return { mode, baseUrl: productionBase };
  }
  assert(profile.environmentPolicy === 'explicit-test-v1', 'This package does not enable explicit test mode');
  const supplied = env.MANTURHUB_BASE;
  assert(typeof supplied === 'string' && supplied.length <= 2048 && !/[\s\x00-\x1f\x7f-\x9f]/.test(supplied),
    'TEST_BASE_REQUIRED: supply an HTTPS gateway origin through MANTURHUB_BASE');
  const url = new URL(supplied);
  assert(url.protocol === 'https:' && !url.username && !url.password && !url.search && !url.hash
    && url.pathname === '/' && url.origin !== productionBase,
  'TEST_BASE_INVALID: use a non-production HTTPS origin without credentials, path, query or fragment');
  const configDir = env.MANTURHUB_CONFIG_DIR;
  assert(typeof configDir === 'string' && isAbsolute(configDir) && !/[\x00-\x1f\x7f-\x9f]/.test(configDir)
    && resolve(configDir) !== resolve(home, '.manturhub')
    && (!profile.configDir || resolve(configDir) !== resolve(home, profile.configDir)),
  'TEST_CONFIG_REQUIRED: explicitly select a separate absolute CLI config directory; existing test authorization can be reused');
  assert(!binding || resolve(binding.configDir) === resolve(configDir), 'TEST_CONFIG_CONFLICT: binding and environment select different directories');
  return { mode, baseUrl: url.origin, configDir: resolve(configDir) };
}

export function environmentIdentity(profile, ctx) {
  return { schemaVersion: 1, product: profile.product, mode: ctx.mode, baseUrl: ctx.baseUrl, configDir: ctx.configDir };
}
export const environmentDigest = identity => createHash('sha256').update(JSON.stringify(identity)).digest('hex');

function safePath(value) {
  assert(typeof value === 'string' && isAbsolute(value), 'Project path must be absolute');
  let path = resolve(value);
  if (process.platform === 'darwin') for (const prefix of ['/var', '/tmp']) {
    if ((path === prefix || path.startsWith(prefix + '/')) && realpathSync(prefix) === '/private' + prefix) path = '/private' + path;
  }
  let cursor = parse(path).root;
  for (const part of path.slice(cursor.length).split(/[\\/]/).filter(Boolean)) {
    cursor = join(cursor, part);
    assert(!lstatSync(cursor, { throwIfNoEntry: false })?.isSymbolicLink(), 'Unsafe project environment path');
  }
  return path;
}

// Additive sidecar: never rewrite business state, frozen inputs, CLI receipts or an existing binding.
export function projectEnvironment(project, identity, { commit = false, packageRoot } = {}) {
  if (!project) return;
  const root = safePath(project);
  assert(lstatSync(root).isDirectory(), 'Project directory is required');
  if (packageRoot) {
    const distance = relative(realpathSync(packageRoot), realpathSync(root));
    assert(distance && (distance === '..' || distance.startsWith('..' + sep) || isAbsolute(distance)), 'Project must be outside the Skill installation');
  }
  const path = safePath(join(root, 'skill-access-context.json'));
  const read = () => {
    if (!existsSync(path)) return null;
    const info = lstatSync(path);
    assert(info.isFile() && info.size <= 8192, 'Invalid project environment binding');
    const value = JSON.parse(readFileSync(path, 'utf8'));
    assert.deepEqual(value, identity, 'PROJECT_ENVIRONMENT_CONFLICT: use the original gateway and config directory; do not move pending tasks between environments');
    return value;
  };
  if (read() || !commit) return;
  const temporary = join(dirname(path), '.access-context-' + randomUUID());
  try {
    writeFileSync(temporary, JSON.stringify(identity) + '\n', { flag: 'wx', mode: 0o600 });
    try { linkSync(temporary, path); } catch (error) { if (error.code !== 'EEXIST') throw error; }
    read();
  } finally { if (existsSync(temporary)) unlinkSync(temporary); }
}
