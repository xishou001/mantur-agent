import {
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  renameSync,
  rmSync,
  writeFileSync,
  writeSync,
} from "node:fs";
import { dirname, isAbsolute, relative, resolve } from "node:path";

import { spawnInternalNodeSync } from "./child-process.mjs";
import { realpathSync } from 'node:fs';

export function plainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

export function parseOptions(tokens, specification) {
  const values = new Set(specification.values || []);
  const booleans = new Set(specification.booleans || []);
  const repeated = new Set(specification.repeated || []);
  const options = Object.fromEntries([...repeated].map((name) => [name, []]));
  const positionals = [];
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (token === "--") {
      positionals.push(...tokens.slice(i + 1));
      break;
    }
    if (!token.startsWith("--")) {
      positionals.push(token);
      continue;
    }
    const equals = token.indexOf("=");
    const name = token.slice(2, equals > 2 ? equals : undefined);
    if (booleans.has(name)) {
      if (equals > 2) throw new Error(`option --${name} does not accept a value`);
      options[name] = true;
      continue;
    }
    if (!values.has(name) && !repeated.has(name)) throw new Error(`unknown option: --${name}`);
    let value;
    if (equals > 2) value = token.slice(equals + 1);
    else value = tokens[++i];
    if (!value || value.startsWith("--")) throw new Error(`option --${name} requires a value`);
    if (repeated.has(name)) options[name].push(value);
    else options[name] = value;
  }
  const expected = specification.positionals ?? 0;
  if (positionals.length !== expected) {
    throw new Error(`expected ${expected} positional argument(s), received ${positionals.length}`);
  }
  return { options, positionals };
}

export function readJson(path, { object = false } = {}) {
  const value = JSON.parse(readFileSync(path, "utf8"));
  if (object && !plainObject(value)) throw new Error(`JSON must be an object: ${path}`);
  return value;
}

export function writeJson(path, payload) {
  const target = assertProjectWritePath(path);
  mkdirSync(dirname(target), { recursive: true });
  const temporary = resolve(dirname(target), `.${target.split(/[\\/]/).pop()}.${process.pid}.tmp`);
  try {
    writeFileSync(temporary, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
    for(let attempt=0;;attempt++) {
      try {renameSync(temporary,target);break;}
      catch(error) {if(process.platform!=='win32'||!['EPERM','EACCES','EBUSY'].includes(error.code)||attempt>=80)throw error;Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,25);}
    }
  } catch (error) {
    try {rmSync(temporary, { force: true });}
    catch {
      try {writeSync(2,JSON.stringify({level:'warning',code:'ATOMIC_WRITE_TEMP_CLEANUP_FAILED',retryable:false})+'\n');} catch { /* Preserve the original write failure. */ }
    }
    throw error;
  }
  return target;
}

export function projectRoot() {
  const configured = process.env.MANTURHUB_PROJECT;
  if (!configured) throw new Error('Project is missing; use scripts/studio.mjs --project <directory> <action>');
  const root = resolve(configured);
  if (!existsSync(root) || !lstatSync(root).isDirectory()) throw new Error(`project directory is invalid: ${configured}`);
  return root;
}

export function assertProjectWritePath(path) {
  const root = projectRoot();
  const target = resolve(root, path);
  const relation = relative(root, target);
  if (relation.startsWith("..") || isAbsolute(relation)) {
    throw new Error(`output path must stay inside the project directory: ${path}`);
  }
  if (existsSync(target) && lstatSync(target).isSymbolicLink()) {
    throw new Error(`output path is a symbolic link: ${target}`);
  }
  let cursor = dirname(target);
  while (cursor !== root && cursor !== dirname(cursor)) {
    if (existsSync(cursor) && lstatSync(cursor).isSymbolicLink()) {
      throw new Error(`output path contains a symbolic link: ${cursor}`);
    }
    cursor = dirname(cursor);
  }
  return target;
}

export function httpUrl(value, field = "URL", { httpsOnly = false, noQuery = false } = {}) {
  let url;
  try {
    url = new URL(String(value || ""));
  } catch {
    throw new Error(`${field} must be a valid HTTP/HTTPS URL`);
  }
  if ((!httpsOnly && !["http:", "https:"].includes(url.protocol)) || (httpsOnly && url.protocol !== "https:")) {
    throw new Error(`${field} must be a valid ${httpsOnly ? "HTTPS" : "HTTP/HTTPS"} URL`);
  }
  if (!url.hostname || url.username || url.password || (noQuery && (url.search || url.hash))) {
    throw new Error(`${field} is not an allowed URL`);
  }
  return url.href;
}

export function runInternalNode(entry, args = []) {
  const result = spawnInternalNodeSync(entry, args, {
    encoding: "utf8",
    stdio: ['ignore','pipe','pipe'],
    parentEnvironment: process.env,
    environmentProfile: 'isolated',
    maxBuffer: 16 * 1024 * 1024,
  });
  return {
    found: result.error?.code !== "ENOENT",
    status: result.status,
    stdout: result.stdout || "",
    stderr: result.stderr || "",
  };
}

export function outputPath(value, label) {
  if (!value) throw new Error(`${label} is required`);
  return assertProjectWritePath(value);
}
