import{a,b}from"./shared-O7WHAKFU.mjs";import"./shared-CMSGDO4E.mjs";import"./shared-FFASSQKO.mjs";export{a as inspectProcess,b as ownProcessIdentity};
