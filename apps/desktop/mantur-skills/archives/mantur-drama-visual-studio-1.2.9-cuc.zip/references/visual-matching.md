# Visual asset matching rules

## Evidence order

Use all evidence together:

1. User-declared asset ID, character name, type, and variant.
2. Canonical names, aliases, and evidence lines extracted from the script.
3. Visible pixels or video content.
4. Filename and folder naming.

A filename alone never proves identity when two script assets remain plausible.

## Existing-media batch workflow

For an already confirmed source scope, reuse its saved directories. Inventory candidate files and compare duplicate checksums in one pass. Use user labels, script names, aliases, variant descriptions, and episode evidence to shortlist plausible targets; do not compare every file against every extracted asset by default. This shortlist is for efficient review, never identity proof.

Inspect the actual pixels of every image proposed for adoption. A contact sheet may help scan many files together if each image remains legible; open the original at sufficient detail when identity, clothing, injury, scene layout, image quality, or headcount cannot be resolved from the sheet. Do not infer unseen details from the filename, thumbnail, or a prior Agent's summary.

For each visually checked image in the authorized source scope, prepare a matching proposal before adoption. Multiple candidates require actual visual comparison: propose the one that best fits identity, current requirements, reference constraints and legibility, recording why. Preserve alternatives. Show the proposed association in the dashboard and obtain explicit chat confirmation; support whole-batch or partial confirmation. Never fabricate user confirmation or visual evidence. Unmatched requirements remain distinct from unused files.

## Dashboard matching confirmation

Use `prepare-asset-matching --input input/matching-proposal.json` with `schema_version:1` and `matches:[{asset_id,local_file,unique_match:true,evidence:["actual visual observations"],note:"optional conflict to show next to the image"}]`. Files must already be in the project. This local action validates media and saves display-only candidates, then refreshes the snapshot. It does not upload, generate, adopt or change readiness. Check `snapshot_refresh.ok=true`; on failure repeat the same local prepare or refresh, never regenerate.

Follow the [dashboard opening contract](readonly-http-api.md) and provide the actual dashboard link before asking the user to confirm. The asset row shows its proposed image, original asset name, source “已有素材” and “待确认”; click to enlarge. Summarize only scope and conflicts in chat, rather than making a text table the sole review surface. Use unique_match:false for unresolved identity proposals; they may be previewed or discarded but cannot be adopted until a revised uniquely resolved proposal is confirmed. Identity conflicts stay proposals until resolved; confirmation cannot waive invalid media or an ambiguous identity.

After the user decides, run `apply-asset-matching --input input/matching-decision.json` with `schema_version:1`, the returned `proposal_id`, real `user_confirmed:true`, and `decisions:[{asset_id,decision:"adopt"}]` or `decision:"discard"`. Include only decided items; omitted items remain pending. Adopt only uniquely resolved associations. Discard preserves the previous selection; if none existed the asset remains missing. Repeated identical decisions are idempotent. Changed media, requirements or previous selection invalidate the old adoption; prepare and confirm the affected items again. Never fill confirmation before the user replies or edit the matching report directly.

Batch confirmation saves each decision with the existing selection transaction and recovery checks, then explicitly refreshes the dashboard once after the batch. Check the top-level `snapshot_refresh`: saved selections survive a failed refresh; repeat the same local confirmation or refresh without regenerating, and already saved decisions are skipped. A publication error attempts one refresh of partial progress and keeps the original error. If `next_action=inspect_snapshot_cleanup`, inspect the saved lease/cleanup failure before further publication; do not treat it as a request to repeat generation.

Style references are not identity evidence unless the user explicitly identifies the depicted asset. A visual match can guide rendering style without asserting that the pictured subject is a script character.

A style reference is also not an output element. Do not treat the source image, its depicted character, its background, its props, its text or its logo as something that should appear inside the newly generated asset. Only an explicit `identity / wardrobe / structure` role permits transfer of that named feature class, and literal embedding of the source image remains forbidden.

## Match decision

Accept a match only when it is unique and has no conflicting evidence.

- `matched`: explicit metadata or a unique script candidate agrees with visible facts.
- `variant_match`: identity is known and visible state agrees with one declared variant.
- `unresolved`: multiple candidates remain, visual facts contradict metadata, or the file lacks sufficient evidence.

Do not emit artificial probability scores. Record the evidence and contradiction instead.

## Duplicate and variant handling

- Compare checksums first; identical bytes are one source file.
- Keep the clearest user-provided image when multiple files depict the same base variant.
- Do not merge materially different clothing, age, injury, disguise, or story phase.
- Do not create a variant solely because framing, pose, crop, lighting, or expression differs.
- Do not use a group image as a single-character identity asset unless the target person is explicitly and unambiguously isolated.
- Classify single-person files as character assets, not crowd assets.
- Use crowd assets only for multi-person compositions and record the visible headcount class.
- When an extracted crowd row appears to correspond only to a single-person file, leave that proposal unresolved for identity review; a filename or role label cannot waive the crowd composition rule.

## Output entry

Every resolved image entry must include:

```json
{
  "filename": "local-or-uploaded-name.png",
  "url": "https://public-object-url",
  "kind": "character",
  "asset_id": "CHAR-001",
  "canonical_name": "Name",
  "display_name": "Name-晚礼服裙",
  "variant_id": "CHAR-001-V02",
  "variant_name": "Wardrobe or state",
  "is_base": false,
  "visual_facts": ["visible fact"],
  "applicable_episode_range": "EP11-20",
  "applicable_scenes": ["scene evidence"],
  "forbidden_tags": ["conflicting state"],
  "output_width": 1672,
  "output_height": 941,
  "provenance": "user_uploaded"
}
```

Use `variant_id: null` only for a canonical base asset or a type without variants. Public URLs must be raw text, never Markdown links.

Save `display_name` on the local matching entry keyed by `asset_id`: use the user's explicit name, otherwise the uniquely matched user image's original filename without its directory and final extension. Keep `canonical_name` and IDs unchanged. Generated images use semantic names, not ID filenames. A display name is a label, never identity evidence. See [local-project-schema.md](local-project-schema.md#资产展示名称) for snapshot fallbacks.

For generated assets, record actual `output_width/output_height` for audit and visual review. The canvas is selected per asset use; neither a reference image nor the project's video ratio is an automatic acceptance criterion.

Generated outputs are adopted after technical validation under [generated image completion](asset-operations.md). Report copied reference panels, unintended text, identity differences or quality concerns only as non-blocking chat advice; never turn aesthetic judgement into pending/rejected status or a confirmation requirement. Existing user-image matching still requires a unique identity association.
