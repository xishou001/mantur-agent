# 版本兼容性

| 组件 | 要求 | 合同 |
|---|---:|---|
| Skill | `mantur-drama-visual-studio@1.2.5` | 独立安装、包内 Compiler 与只读服务、本地权威状态 |
| Node.js | `>=18.20.8` | 运行已打包 `.mjs`，安装后无需 npm；保留 Node 20/22 兼容 |
| ManturHub CLI | 公共合同声明的正式版下限与已验证安装版本 | 仅远端动作需要；来源、配置和身份统一由公共接入校验 |
| `op.drama.asset-extract` | `>=v2.3.0` 且兼容 | 完整剧本单个 `input_file`、严格 JSON Schema |
| `op.drama.clip-seedance-compile` | `>=v2.3.3` 且兼容 | 完整剧本与资产清单两个 `input_file.file_data`、固定状态与时长审计 |
| `op.image.generate` | live 兼容 schema | Agent 无原生生图能力时使用，执行前实时报价 |
| `op.video.understand-v2` | live 兼容 schema | 分析参考图中的角色、服装、环境与画风；以实时字段为准 |
| `op.voice.design` | live 兼容 schema | 定制角色音色并保留后续复用所需的音色引用 |
| `op.audio.generate` | live 兼容 schema | 确需额外参考音频时独立预检、报价和批准；合规 previewAudio 可直接审核复用 |
| `op.video.generate` | live 兼容 schema | Seedance 参数、参考媒体、音色和官方尾帧 |
| Snapshot | `mantur.drama.ui-snapshot/v1` | 完整 Envelope、revision、ETag、脱敏字段 |
| Local protocol | `mantur.drama.local/v1` | Manifest、权威文件、媒体完整性和兼容适配器 |
| JianYing profile | `jianying-windows-portable-v2` / `jianying-macos-portable-v2` | 5.9.0 生成格式与应用版本分开；本机自动安装，跨平台只打包；应用验收另记 |

更高算子版本只在 live schema 仍满足当前必需字段时兼容。缺字段、未知状态或供应商变化必须预检失败，不得猜测、静默降级或更换 provider。

新算子动作以 CLI describe 的 inputSchema 和实际输出为准，不用历史算子业务版本或打包指纹代替兼容检查。固定 voice_id、无取链合同的 fileId-only 结果及未知响应不放行。旧 Runtime 的远端恢复由匹配稳定版本承接，已有本地事实按原协议读取。详见 [公共预检](cli-onboarding.md#公共接入预检)与[视频合同](video-generation.md)。

Node 18 已停止官方维护，仅作为旧环境兼容下限，不建议新装环境使用。优先使用仍受维护的 Node.js LTS。低于最低版本或预发布版本，统一入口在执行动作前返回 `NODE_VERSION_UNSUPPORTED`；升级运行时后重试同一命令，不修改生产事实或重新提交远端任务。

此要求针对安装包运行，不代表仓库开发依赖均支持 Node 18。开发构建和 Playwright 使用 Node 22；运行产物以 `node18` 为构建目标。新版公共流程回归覆盖 Node 20/24，Node 18 仅保留原本地运行下限声明，本轮未重新验收；不因构建目标代替实际测试。ManturHub CLI 还须满足自身 Node 要求，升级 CLI 后需要重新核对。

不同 Agent 宿主可能通过 `NODE_OPTIONS` 注入安全或语言 shim。Skill 的包内 Compiler 与只读服务不需要该注入，启动前会隔离 `NODE_OPTIONS`／`NODE_PATH`；ManturHub CLI 属于外部平台边界，继续继承宿主安全 Hook。Skill 不通过清空外部 CLI 环境规避宿主安全策略；宿主 Hook 自行派生的窗口、进程或兼容问题仍须在对应宿主实测和修复。
