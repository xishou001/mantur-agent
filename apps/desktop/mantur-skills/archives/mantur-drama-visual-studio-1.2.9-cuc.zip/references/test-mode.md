# 显式测试模式

默认生产。同一份包可在用户明确要求测试时选择外部HTTPS测试网关，包内没有测试地址、预设测试账号或测试凭据。上传到哪个平台不会自动改变运行环境，也不根据下载来源猜测环境。

在实际执行Skill/CLI的宿主进程中注入以下三项；值由测试人员提供，不把示意值直接执行：

```text
MANTURHUB_SKILL_ENV=test
MANTURHUB_BASE=<测试人员提供的HTTPS网关origin>
MANTURHUB_CONFIG_DIR=<已有测试CLI授权目录的绝对路径>
```

三项同时提供，不能只设置BASE；目录必须与生产默认目录分开。已有测试目录直接复用，不能复制凭据到新目录。网关只允许HTTPS origin，不带用户名、密码、路径、query或fragment。生产模式不自动接受遗留测试baseUrl。

先按[access.md](access.md)执行check，核对返回的environment=test、baseUrl、configDir。READY即复用已有授权；需要登录时完整保留动态loginInstructions的环境、来源与注册业务码，授权网页必须和所选网关同源，不使用静态生产注册链接。不要为通过检查而删除已有登录或换账号。

check返回的bindingEnv用于后续planner和ACCESS命令；bindingArgs固定同一环境。环境变量在另一个终端设置不会自动传入WorkBuddy、IDE或连接器。新的项目在prepare/首次调用时记录环境sidecar；环境改变、遗漏测试开关或配置目录冲突都会在业务请求前报错。恢复使用原bindingArgs、bindingEnv和原恢复ID，不重新run。

旧项目仍可只读与导出，已有工作稿、身份键、输入及回执不迁移。旧pending没有环境绑定时，在原授权目录和原站点先执行CLI恢复；成功后补充sidecar，原任务数据保持不变。生产和测试项目分目录保存，不能通过删除sidecar把已有远端项目切站。

连接器需在宿主执行CLI命令的环境中显式注入测试三项；配置目录是另一个宿主管理的`.manturhub-workbuddy`或带后缀目录，不能借用独立技能的CLI路径/账号目录。宿主若不能覆盖其固定注入环境，本连接器入口不能完成测试，使用同包业务的独立技能入口；不能把终端模拟说成连接器现场验证。

回到生产时清除测试变量，重新check并使用生产项目。切换运行环境不改写包文件；RC 与正式稳定版仍分别构建，不能改名转为正式包。动态项目sidecar/运行日志留在用户工作区，不能加入发行包。
