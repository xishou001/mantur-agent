# 视频生成与真实尾帧

沿用用户 Clip 范围，先校验模板与素材，再按[批次合同](video-batch-approval.md)整批报价、一次费用批准及有限并发推进。同场依赖顺序提交：本批前序视频必须通过技术验收且被采用，不能借用同 Clip 的旧版尾帧。已有采用版本时，新候选完成不静默替换；按返回的 expected_run_id 经 adopt-video-run 明确采用后继续，独立场次不受影响。

    {"schema_version":1,"clip_id":"CLIP-EP01-001","generation_intent":"approved-scope","attempt":1}

prepare-video-generation --input <文件> 按当前模板、真实媒体和前序尾帧构造请求。ready 后 submit-video-generation --operation-id <ID>，费用批准传 --confirm。随后 resume-video-generation --operation-id <ID>，已下载原件可 --local-only。

镜头连续性硬性限制保留：必须注入前序真实尾帧，保存原 Run 与摘要。缺少尾帧 mediaRef 时交接稳定版本，不由 fileId 造引用。结果必须含真实视频与 final_video 尾帧，校验结构、哈希、尺寸和分镜关系。

公共 CLI 受理回执替代旧报价/批准字段，不伪造 quote_verified 或 approval_verified。下载/导入失败保留 result_pending，继续本地步骤不重新生成。完成后写技术证据；替换候选通过 adopt-video-run 采用。

创作预期偏差不阻断技术完成；creative_warnings 不反复提醒、不等待确认、不自动重生成。旧 local_pending 交原版本恢复，保留媒体。范围结束沿用明确交付目标，未授权动作才询问。见 [结果选择](video-result-selection.md) 和 [公共入口](public-cli-adaptation.md)。

视频按实际引用核验，新绑定为 reference_policy=request-input-v2；旧 request-media-v1 只读兼容：以实际引用为准，material_warnings 只提醒。用户明确拒绝的媒体和未采用候选不得进入请求。费用批准仍独立核对；不伪造审核。当前绑定不包含 review_id；旧绑定保留原样，不能用换标签绕过真实媒体及连续性检查。
