# 统一 Agent 异步循环策略

本策略覆盖新公共 CLI 制作流程。Agent 负责“等待 → 单次恢复 → 判断 → 再等待”，业务层保存原操作和结果，CLI 管理远端受理与恢复。持续推进不依赖对话结束后的后台监控，也不通过重复提交猜测任务是否完成。

中断续跑先执行一次[看板交接](readonly-http-api.md#中断后继续制作的看板交接)，等待期间不反复打开页面。遇到本地锁问题读[锁恢复](lock-and-queue-recovery.md)，不要删除状态或并发启动同一操作。

## 阶段与动作

| 阶段 | 继续动作 |
| --- | --- |
| 资产提取 | resume-asset-extraction |
| 图片、理解、音色、音频 | resume-asset-operation |
| Seedance/WAN 分镜 | resume-clip-compilation |
| 视频 | resume-video-generation |

全部传原 --operation-id。阶段 status 只读本地；resume 对已知 Job 使用公共 status 查询原受理回执。未知受理有原 CLI 恢复 ID 时使用原 resume，可能长轮询；没有 ID 时必须核对原提交，不伪造恢复记录。旧 poll-checkpoint 与旧队列已移除，旧任务交匹配稳定版本。

## 按返回状态继续

以 stage、error 和 next_action 判断，不等待不存在的旧 polling 字段。ok=true 不能单独证明产物成功。

| stage / next_action | Agent 行为 |
| --- | --- |
| preparing | 修复文件、登录或上传问题后继续同一操作；每次继续最多一次新上传，成功回执复用 |
| awaiting_manifest_review | 核对原候选并取得业务清单确认 |
| ready / confirmation_required | 只在有效制作范围与 CLI 费用批准内提交；确认令牌不写项目 |
| accepted | 分段等待后查询原 Job，不重新 run |
| wait_for_original_cli_process | 观察原进程，存活或身份未知时不重复提交或上传 |
| submission_unknown | 恢复原 CLI 调用；没有恢复 ID 时核对原调用，保留证据并继续不依赖它的工作 |
| result_pending | 继续原结果下载、校验或本地导入；可选看板失败不撤销产物 |
| completed | 按 next_action 继续已授权范围；素材试听/采用仍遵循对应业务审核 |
| terminal | 明确失败、取消或超时后，获准的新尝试用 --retry-of 与新 --attempt；先复核原终态 |

用户要求制作或继续时，在授权内持续推进，不因一次查询返回便结束。使用宿主可中断等待，每段最多 60 秒；服务端有间隔时遵守总间隔，否则以 15 秒为起点，连续查询失败逐步退避。连续三次空响应或相同查询错误时停止盲目轮询，检查原受理回执、访问和服务状态；修复后继续原 Job，不将该次数变为永久门禁。

用户停止或宿主中断时保存当前事实；下一次继续从原操作恢复。上传的原进程已经结束且没有有效回执时允许一次新的纯上传尝试，可能产生重复远端文件；这一规则绝不适用于未知的生产提交。
