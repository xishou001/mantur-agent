# CLI 调用合同

本页是业务唯一的工具接入入口，要求公共 CLI 1.2.10 及以上正式版，默认安装已验证的精确版本 1.2.10，不自动追随 latest。仅梳理需求或读取已有本地产物时无需安装、登录或联网；实际调用前按 [channel.md](channel.md) 准备运行条件和授权，按 [access.md](access.md) 使用固定环境与命令转发。具体版本、站点、凭据位置和宿主按钮只在接入/发行层维护，不写进业务流程。

## 调用入口

尚未有平台账号时，可按 [注册入口](registration.md) 选择当前宿主的引流链接；注册与 CLI 授权分别完成。当前宿主由每次ACCESS --source明确提供；调用businessCode来自当前调用方上下文，Skill身份/版本由包内接入层提供，业务 input 保持算子 Schema。支持归因的 profile v2 会把业务脚本的流程/步骤参数交给 CLI；确认与恢复沿用首次归因快照。新归因包的注册businessCode表示引流Skill及接入形态：独立技能为产品id加-skill，连接器加-connector。缺registrationBusinessCode的旧profile沿用原产品id，不能判成独立技能，不回填旧数据；不与调用业务自动合并。

ACCESS替换为本包`scripts/access.mjs`的绝对路径；参数逐项传递，不拼接shell字符串。业务脚本返回的`cli.args`原样传给ACCESS，不直接执行其`cli.command`。下面省略接入选项；独立入口按channel.md先check默认发现本地CLI，再在每次exec前带上返回的同一组bindingArgs（`--source`、`--business-code`、`--existing-cli`和`--config-dir`），包括报价、确认调用及resume。连接器复用check返回的业务码bindingArgs，其他身份/包元数据仍使用宿主环境，不能中途换入口。

```bash
node "ACCESS" exec -- describe <算子代码> --json
node "ACCESS" exec -- quote <算子代码> --json-file "参数文件" --json
node "ACCESS" exec -- run <算子代码> --json-file "参数文件"
node "ACCESS" exec -- resume <原恢复ID>
node "ACCESS" exec -- status <本项目原受理回执中的pollUrl>
```

describe以当前身份的线上合同为准，不可发现即停止；本地算子说明不是上架证明。quote仅取报价，run仍会重新报价；通常直接按业务脚本返回的run参数执行，无需重复quote。run的stdout默认JSON，不加无值的`--json`；也支持`--json '<JSON>'`，本地项目统一使用`--json-file`。

## 费用与文件

- run不是纯报价：正额固定报价退出3，确认信息在stderr。展示实际价格、范围及返回的有效期，用户明确批准后以原参数追加CLI返回的`--confirm <confirmation_token>`。令牌只用于临时命令，不写项目或交付物；过期后重新取得报价和确认。
- 升级包或自动环境中的宿主、Skill版本、发行目标、接入方式变化，不改原确认快照；业务/Skill身份、流程/步骤冲突仍停止。显式改写快照字段继续拒绝，账号/站点/算子/输入/价格校验保持。
- 只有`billable=false`、金额0且`postExecutionSettlement`缺失/null才可直接免费受理，也需用户批准该业务操作。当前 CLI 支持具有有效单价、用量上限、最高费用、公式及 priceVersionTag 的后结算合同；按原确认信息展示最高费用和结算规则并取得批准。后结算金额0不表示免费。合同不完整、无有效上限或 CLI 拒绝时停止，不换旧 CLI 或 HTTP 绕过。
- `--file "<Schema文件字段>=<本地路径>"`由CLI完成上传/确认并替换fileId。上传在报价前就可能发生，先确认用户选定文件及使用权；退出3不表示文件尚未上传。确认后复用相同文件和参数，不单独重复上传。
- 文件类型/大小按describe，不使用任意URL绕过。扫描PDF或复杂排版要人工核对分析效果。
- 报价不是最终扣费，失败也不等于已退款；以公开`billing/_billing`及平台记录为准。

## 回执、结果与恢复

stdout保存为单独JSON，stderr中的进度、确认信息和恢复ID分别处理，记录真实退出码。recoveryId、jobId、本地callId/stepId互不等同。

CLI stdout 是解包后的任务对象，不再包 HTTP `Result.data`。以下是字段位置示意，不是可导入的完整业务结果：

```json
{"jobId":"示意任务ID","operatorCode":"op.script.review","status":"SUCCEEDED","output":{"schemaVersion":"script.review.v1","action":"SCAN","status":"REVIEW_REQUIRED"}}
```

这里顶层 status 表示任务执行成功，output.status 表示仍有审校问题；数据算子的 output.outcome/status 也只表示业务结果。项目的 qualityAccepted 是另外的本地验收事实，不能从任一成功状态自动推导。输入只包含算子业务参数，不包含 jobId、任务 status、output 包装或本地项目 ID；下游只按业务引用取完整 output 或指定子对象，不能把整个 stdout 直接作为下游参数。

CLI 校验输入合同；本地业务脚本仅提供关键结构与流程护栏，并非完整输出 Schema 验证器。收到输出仍需核对当前合同的关键字段、业务状态与质量门禁；缺少字段就停止，不用示例或模型补齐。

| 实际结果 | 后续动作 |
| --- | --- |
| 退出3，未受理 | 记录待费用确认；批准后确认同一调用，不把报价当业务产物 |
| QUEUED/RUNNING/PENDING且已知原任务 | 保存原恢复ID与jobId；业务已绑定受理索引时单次status，否则沿原resume；不新建调用 |
| 提交结果未知 | 核对CLI原恢复记录，不猜任务或用新的run补索引 |
| `--no-wait`回执为SUCCEEDED、output缺失/null且带CLI作业pollUrl | 只是结果待获取；按原恢复ID查询，不再次run，不直接访问返回URL |
| 退出0、SUCCEEDED且完整output | 按算子Schema校验，才可导入并继续下游 |
| 恢复查询仍无output，或output为非法对象/缺少jobId等关键合同 | 停止排查，保留ID和原始响应；不无限轮询、不造结果 |
| 明确FAILED/CANCELED等终态 | 保存错误与账务；用户明确要求新尝试后，走业务脚本允许的重试入口及新的报价/调用 |

未知任务只恢复原调用；终态后的新尝试不是resume，不承诺免费，也不能一概复用已失败调用的幂等键。参数变更不能套用旧确认令牌。幂等与记录由CLI管理，不手工生成或替换。缺少恢复ID时核对CLI/平台记录，不据此推断未提交。

## 长任务与宿主执行预算

实际提交前核对当前宿主是否支持长进程或后台任务。当前CLI的run默认等待结果，resume也会持续轮询，默认轮询预算20分钟；宿主的命令执行预算可能更短。不要套用认证命令的超时作为业务执行超时。

- 宿主支持长进程：使用它提供的后台执行/继续读取输出机制，保存stdout、stderr和原恢复ID；等待同一进程，不重复run。
- 需要先取提交回执：可在业务脚本给出的run参数后追加`--no-wait`，其他业务参数与确认令牌不变；按原callId记录回执。它不是有界查询，随后resume仍可能长时间等待，不能宣称仅加此标志就适配了短超时宿主。
- 宿主不支持长进程：已接入单次查询的业务使用 --no-wait 及原任务 status，交回 Agent 分段等待；尚未接入的业务在提交前说明限制并暂停，不反复杀进程重跑。已受理任务保留原ID，回到原绑定恢复，不新建收费任务。

本修订复用现有 CLI status：ACCESS 只允许 profile 同源的规范 Job 路径，业务必须验证原受理索引与响应身份。一次返回后由 Agent 等待，不能由 Skill 另写认证 HTTP、任意访问 URL 或猜造 resume 参数。查询成功不等于任务成功，也不代表产物已下载和接入。它不提供旧 Runtime 未知受理或原账号强绑定恢复，不替换原 CLI invocation 记录。

## 认证错误与凭据迁移

认证失效按channel的入口重新授权；403也可能是权限不足，先看错误信息，不反复登出/登录。不能通过换账号、目录或渠道重提未决任务。

当前 CLI 使用本机私有 SQLite 凭据库，进程崩溃由事务恢复，不再要求手工删除凭据锁。首次修改凭据时由 CLI 迁移旧文件；若检测到旧 `client-credentials.lock`，会隔离旧会话并提示重新登录，旧文件与锁保留。停止使用同目录的旧版 CLI；不要手工改库、删除新库或移走旧锁来恢复旧登录。凭据库只支持本机磁盘，含明文凭据，不可共享上传。迁移后不能降级到使用旧凭据文件的版本。

登出先提交本地退出，再限时处理远端撤销；失败会保留重试记录并提示到平台核对，本地退出不等于远端已撤销。公共安装锁和业务项目锁仍各有恢复规则，不与凭据迁移混用。


## 可执行 Skill 的公开服务

声明了 CLI 动作清单的完整包会生成 `skill-runtime.json` 和 `scripts/cli-client.mjs`。安装包中的动作清单来自产品元数据，入口仍是同一份业务脚本；本地源码目录不是完整安装包。平台版本与清单的 `content_version` 分别表示平台修订和源码发行，不互相替代。

官网纳管安装继续使用公开 `manturhub skill install <公开Skill编码> --client <实际客户端>`，更新用 `skill update`，运行用 `skill doctor/run/exec`。客户端值使用实际安装环境，不伪造安装记录。未纳管的其他渠道通过其原安装入口更新；安装、更新与登录各自遵守用户授权。

包内公共服务只调用 CLI 的公开命令，不导入其私有模块。实际执行前复用同一次检查返回的 CLI/config 绑定；业务提供用户项目目录及显式安全相对 `bindingPath`，首次远端操作把非敏感 `bindingArgs` 原子保存在该位置；通用服务不指定业务目录，也不在缺少路径时创建另一份绑定。check/版本观察只读不创建绑定。既有业务沿用原路径及文件格式，后续复用并拒绝入口、目录或业务冲突；业务选择顺序为显式参数、当前进程业务、默认业务；先按该顺序取得有效请求值，再与既有项目业务比较，不把已被显式选择覆盖的环境默认值当成另一份用户请求。没有显式参数时，进程业务与既有绑定冲突仍须停止。check观察本身不创建或伪造历史业务绑定。独立入口的宿主 source 可以按当前运行环境变化；连接器只使用 profile 约束的宿主 PATH/身份环境，不接受外部 CLI 入口、配置或来源覆盖；路径固定不代替 CLI 对原调用账号的校验。不得复制或修改 CLI 的凭据库和 invocation 文件。

- 上传通过公开 `upload <用户选定的绝对文件路径> --json` 完成，要求 AVAILABLE 回执。上传可能早于收费确认；上传完成不代表调用或制作完成。
- 报价、运行及恢复通过原 ACCESS 转发，保留退出码及 stdout/stderr。批量预算是额外业务约束，每项收费确认仍使用对应输入的原令牌；令牌不落项目或网页。明确未受理的公开拒绝回执与已受理任务失败分开记录。
- 已受理任务可以在宿主允许的后台进程中执行原 ID 的 `resume`；它是长轮询，不是有界查询。每项目同一轮不重入，并限制并行原调用数；关闭工作台取消本地等待，不取消远端任务，也不新建调用。等待返回后重新核对 operation/request/recovery 绑定再保存结果。
- `singleJobStatus=true` 表示可经 ACCESS 执行 `status <原pollUrl>` 单次查询，只允许 profile 同源的规范 Job 路径，不接收任意地址、额外参数或凭据。业务必须先核对本项目实际受理记录，再核对响应 Job 身份和状态；code=0 只表示查询成功。该能力不替代 CLI 原恢复记录、原账号绑定或未知受理恢复，`boundedRecoveryQuery` 仍为 false。查询错误不改写原任务、不自动重试提交；等待与结果接入由业务合同负责。
- 产物下载是公共接入层的无凭据 HTTPS 文件传输，URL 仅取实际原任务返回的已选产物，不把任意查询 URL 当下载入口。默认拒绝私网、重定向和路径逃逸；仅产品清单按环境登记的精确 HTTPS 媒体来源允许通过 RFC1918 私网路由，仍固定 DNS 解析结果、校验原域名 TLS 证书，拒绝回环、链路本地和其它特殊地址。不能由命令参数、产物内容或浏览器请求添加受信来源，生产与测试分别装配，禁止失败后切站或关闭证书校验。完整文件经 SHA256、大小及原子落盘后才交给业务做媒体检查。下载器默认限制4 GiB与30分钟，取消/失败保留旧文件；不携带 CLI 的认证信息。失败后沿用原任务的产物恢复下载，不重新生成。
- 版本观察使用公开 `skill outdated --json`，只展示当前实际安装记录。缺少源码版本或更新摘要时明确未知；发现新平台版本后由用户选择更新或继续，不自动覆盖。

产品清单显式声明 `cliRuntime.readOnlyQueries: ["balance"]` 时，生成 `balanceQuery` 能力及 `queryBalance({signal}?)` 单次查询。它在同一环境、CLI 和配置目录检查后调用公开 `balance --json`；无需算子 Key 就绪，不保存项目绑定或凭据，不访问 CLI 私有模块。响应必须通过余额类型和金额字段校验，工作台只展示“最近查询余额”、查询时间及金额，不把查询时账户描述成持续认证绑定。存在优先使用的 API Key 时，以 CLI 本次实际使用的有效账户为准。

工作台可首次查询并按需刷新，刷新时清除旧金额；超时、失败、取消、退出工作台和新的查询轮次丢弃旧结果，迟到响应不能覆盖当前状态。余额只保留在当前工作台内存，不写入项目或本地持久缓存，错误不影响制作、下载和恢复。未知余额不等于0；余额展示不替代制作报价、收费确认，也不是可支付证明。未声明的产品不获得这一能力。直接使用已授权 CLI 的 `manturhub balance` 或 `manturhub balance --json` 仍可查看本次结果。

严格持续账户监控的 `accountBoundBalance` 仍为 false；公开 CLI 尚未提供可核验的认证上下文绑定及会话修订。旧 `balanceIdentity({signal}?)` 和 `balance(expectedIdentity, {signal}?)` 保持 `BALANCE_CONTRACT_UNSUPPORTED`，不执行查询、不要求用户重新登录。它们与单次 `queryBalance` 是不同合同，不能用伪造身份、裸余额或能力标志启用持续账户缓存。

启用持续账户绑定余额与持久缓存前，须先验证正式发行的 provider 合同：只读当前上下文与单次余额响应具有一致的站点、模式、非敏感认证/计费上下文绑定标识和会话修订；该绑定可以是 credential-context，不冒充真实 accountId。余额请求期间身份变化必须明确失败，不能用两次身份观察、配置目录或 Key 哈希代替响应自身的绑定。当前接口签名不表示该 provider 合同已经存在，也不猜造新 CLI 命令或未来字段。验证公开能力并完成身份切换、退出和迟到响应回归后，才能启用缓存及对应能力标志。


显式测试模式见[test-mode.md](test-mode.md)。默认生产；测试时在实际启动入口注入全部测试变量。check返回的bindingEnv、bindingArgs贯穿上传、报价、提交、查询、余额和后台任务；测试授权仅使用动态返回的registrationUrl与完整loginInstructions。旧项目和回执保持原环境，不删除绑定或换站重提。


余额不足时遵守[余额与充值指引](balance-recharge.md)，单项和批次均适用；余额未知不误判，充值后不自动重提。


CLI 检查后必须在对话中展示结果及适用的升级命令，按[版本与升级提示](cli-upgrade.md)处理；不自动升级，不重复提示。
