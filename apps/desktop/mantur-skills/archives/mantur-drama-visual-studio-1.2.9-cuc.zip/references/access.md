# 公共接入检查与转发

ACCESS是本包`scripts/access.mjs`的绝对路径。相邻access-profile.json固定产品、渠道、正式站点、CLI最低版本和算子范围；只有连接器声明宿主凭据目录。源码skills目录未装配公共资源，不能直接安装。

实际调用前按 [channel.md](channel.md) 执行check。通用/独立技能默认发现当前PATH中的CLI，沿用MANTURHUB_CONFIG_DIR或CLI默认`.manturhub`；连接器只使用宿主注入环境。独立入口check返回的bindingArgs用于固定当前宿主内后续调用路径和来源；换宿主重新check，连接器不接受外部路径覆盖。业务调用、费用与恢复见 [cli.md](cli.md)。

## 来源与注册引流

独立入口支持前置--source workbuddy|codex|claude-code|unknown（普通终端cli）。profile v2必须明确传入来源，或使用当前进程明确提供的MANTURHUB_SOURCE；缺失先报HOST_SOURCE_REQUIRED。来源与包内distributionTarget独立，不能根据standalone/mantur、安装目录或--client推断。check返回的bindingArgs包含source，每次exec/authorize/resume均原样携带；不保存到账号或全局配置。

未登录的v2 check返回loginInstructions，其command/args/env只含执行入口、from/businessCode和非敏感环境绑定，不执行登录。没有CLI时registration操作只生成当前产品引流URL。READY不返回登录指引；已有用户登录不更新注册来源。

向用户展示登录步骤时核对命令同时有 --from 当前宿主、--business-code 本包注册入口编码。check 在 PATH 自动发现 CLI、配置目录为当前用户默认 .manturhub 时，会额外返回 quickLoginInstructions.command/args，scope 固定 same-command-environment；用户在同一已检查命令环境执行时优先展示这个简版，不展开默认环境变量和内部 Node 路径。它不替代完整 loginInstructions：换到外部终端、显式选定 CLI/配置目录或未返回简版时，保留原 command/args/env 与绑定。不要自行推断另一个终端的 PATH/账号配置相同，也不要手工裁剪完整命令来伪造简版。缺参数先停止并重新 check，不能用调用业务覆盖注册产品。

authorize/exec 发现登录失效也返回登录指引；连接器不返回独立登录命令，只提示连接当前宿主，由其执行 cli.json 的完整认证命令。READY/仅缺算子 Key 不返回简版或完整登录指引。展示指引和执行登录分别处理，检查不自动发起登录。

## 调用业务与 Skill 身份

`businessCode`表示本次调用方业务，`skillCode`表示实际执行的逻辑Skill，二者可以不同。v2入口支持前置`--business-code BUSINESS`（也支持等号形式），优先于当前进程`MANTURHUB_BUSINESS_CODE`，最后使用profile默认业务码；默认来自产品清单可选businessCode，未声明时沿用产品id。仅传给当前子进程，不改账号或全局配置。业务码必须是1–64位小写kebab-case。

例如业务marketing-video复用同一Skill：`node "ACCESS" --source codex --business-code marketing-video check`。check返回invocationAttribution和含业务码的bindingArgs，后续exec/authorize/resume逐项复用。连接器也可传业务码，仍不能覆盖宿主来源、Skill身份、版本、发行目标或身份目录。内层CLI显式归因必须匹配已选择上下文，业务JSON同名字段保持原值。

注册是另一份上下文：loginInstructions与registration使用当前宿主from；新归因包的注册businessCode固定为产品id加-skill（独立技能）或-connector（连接器），缺registrationBusinessCode的旧profile仍用原产品id且入口未细分，不用调用业务替换。新业务使用新项目/流程；已有费用确认与恢复沿用首次业务、Skill、流程/步骤和归因快照，不把未决调用转给另一个业务。

## 行为边界

- check只定位和验证已安装的CLI、读取本地auth status，报告实际版本/站点/配置目录及READY、LOGIN_REQUIRED或OPERATOR_AUTH_REQUIRED等状态；不安装、不登录、不准备Key，不证明远端健康。CLI缺失、无效版本或状态解析错误会非零退出并提示原因。
- CLI要求1.2.10及以上正式版，安装指引和回归基线固定1.2.10。保留合格较新版，不自动降级/升级、不追latest。PATH首个CLI损坏时停止，不找另一个安装。只支持可定位到官方npm包的入口；不执行任意shell包装器。
- 公共脚本运行需要Node>=20。CLI凭据库依赖libsql原生包，安装保留npm optional dependencies；模块加载失败时检查Node架构和CLI安装，不改凭据文件。
- 独立入口不改写CLI的实际站点以通过检查；非正式站点或desktop-managed身份模式会停止。外部MANTURHUB_KEY被拒绝，使用现有CLI登录态，不打印环境变量全集或搜索其他目录的密钥。
- authorize仅供独立入口在用户批准后准备现有账号的Key，CLI负责保存。未登录时只提示登录，不替用户登录或切换账号。连接器授权通过宿主“连接/重新连接”。适配器没有install/login/logout操作，不管理共享CLI的生命周期。
- exec前仍核对本地授权与站点；原样传递参数数组、stdout、stderr和退出码，不添加confirm、不重试、不把失败改成成功。doctor/版本查询可在未登录时用于诊断。
- --existing-cli与--config-dir必须成对且为绝对路径；固定后不能只在第一次加。配置与当前环境冲突时停止。连接器目录不可被独立入口借用，连接器也不回退全局独立身份。
- 当前只允许describe、quote、run、resume、status、doctor和版本查询；status 只接受正式站点的规范 Job 路径、没有额外参数，业务还须校验本项目原受理记录。算子白名单与地址检查防误用，不代替服务端授权。

## 运行与恢复

用户项目保存在工作区，安装目录只放程序。恢复前核对原入口、账号与恢复ID；固定路径不能阻止用户在其他终端切换账号，也不能证明远端未重复执行。未知任务只查询原任务，不能因环境问题切换渠道重新提交。

缺少安装/登录时按渠道指引由用户处理，再check；不要复制API Key、手工改库或删除凭据。旧版Skill目录不自动清理，旧任务用显式绑定恢复。业务项目锁由业务runtime处理，CLI凭据事务与迁移规则见cli.md。


## CLI 版本策略

声明 cliInstallTag=latest 的新包在命令行 ACCESS check 返回 cliUpdate 与 upgradeInstructions；minimum 继续作为硬门禁。新版查询只访问 npm 官方 registry，可缓存且失败不阻断兼容 CLI；auth status 仍只读本地身份。UPDATE_AVAILABLE 时提示版本与 Node 要求，用户确认后按 channel.md 核对安装归属并执行升级，再重新 check。exec、费用确认和 resume 不触发软件升级。连接器升级通过宿主完成。旧精确版本 profile 保留原声明。


授权状态解析失败时会附退出码及脱敏、限长的错误摘要，业务调用不会继续。先排查 CLI/Node 和原生依赖；这不等同于未登录，不要重复登录。


测试接入与项目隔离按[显式测试模式](test-mode.md)执行。
