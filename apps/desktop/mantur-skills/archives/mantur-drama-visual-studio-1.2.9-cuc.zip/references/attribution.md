# 本业务归因

注册引流产品：mantur-drama-visual-studio；注册入口 businessCode：mantur-drama-visual-studio-skill。调用默认业务：mantur-drama-visual-studio；外部业务可覆盖，注册产品不随调用业务改变。Skill 身份与版本由当前包提供。

当前接入支持归因。执行前按 [公共接入](access.md) 明确当前宿主，并复用 check 的 bindingArgs。

本业务按项目绑定 businessCode 和稳定流程 ID。新项目先按公共入口 check 解析本次业务，将 invocationAttribution.businessCode 显式传给第一次 prepare/plan 的 --business-code。继续项目先用 业务合同指定的只读 context 入口 读取业务，再以同一业务执行 ACCESS check；初始化流程辅助脚本的只读入口名为 context。planner 的 cli.accessArgs 用于外层 check，cli.args 原样转发；不要只覆盖内层命令。业务冲突停止，业务 A/B 使用不同项目。

| stepCode | 业务步骤 | 算子 | 动作 |
| --- | --- | --- | --- |
| asset-extract | 资产提取 | op.drama.asset-extract | 默认 |
| seedance-compile | Seedance 分镜 | op.drama.clip-seedance-compile | 默认 |
| wan-compile | WAN 分镜 | op.drama.clip-wan-compile | 默认 |
| image-generate | 图片生成 | op.image.generate | 默认 |
| video-understand | 视频理解 | op.video.understand-v2 | 默认 |
| voice-design | 音色设计 | op.voice.design | 默认 |
| audio-generate | 音频生成 | op.audio.generate | 默认 |
| video-generate | 视频生成 | op.video.generate | 默认 |

步骤描述实际调用，不将本地阅读、规划、确认、导出当成算子成功。报价与恢复按 [工具合同](cli.md)，原调用快照不改写。包类型不证明实际下载入口；注册新入口区分独立技能与连接器，不证明实际下载市场；旧未细分编码不回填。
