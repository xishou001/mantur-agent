# 图片候选预览与采用

Seedance/WAN 原清单可补图／换图，不新增 ID；不论是否已有分镜，重新生图均先在看板显示“待确认”，经聊天确认后采用。平台图片描述与原生 begin-image-work 描述在用户要求重生时显式写 generation_intent=regenerate，不能只凭有没有旧图判断；该字段仅为本地流程意图，不发给算子。已有选图、多个候选或已有分镜也保留候选。首次缺图、单张技术合格结果且不是重生请求才可自动采用。原生入口的 awaiting_review 与公共入口的 completed 只描述各自操作状态，均不等于候选已采用。费用不代替采用，未确认保留旧图。

apply-asset-review 输入：schema_version=1、asset_id、operation_id、candidate_index、media_kind=image、真实 media_sha256、review_status=passed、unique_match=true、review_origin=image_adoption、user_confirmed=true、当前 expected_previous_sha256（无则 null）、真实 evidence、requirement_revision（如有）。不填 visual_validation/image_quality_analysis，不伪造视觉通过；选择变化先核对，不擅改基线。

明确放弃本次全部平台候选：改为 review_status=rejected，仅限成功待采用，不能取消未知／在途任务或撤销已采用图。私存 image_rejection 和审核凭据；保留旧图、缺图、任务及费用，队列结束，resume 不生成／下载／采用。拒绝幂等，损坏阻断；未决定则保留候选。

原生图先 begin-image-work；采用需 image_work_id、local_file、source=generated、reference_manifest、generation_prompt、风格及确认字段。放弃用 finish-image-work outcome=cancelled，未知不报取消。用户图须唯一匹配。

## 候选图展示与聊天确认

平台候选落盘即刷新，单次多候选先展示首张技术合格图，用户确认其他张前须先展示对应原图，不把确认首张套用到其他候选；原生重生图不论分镜前后，生成后先用 finish-image-work 登记本次待确认图，输入 work_id、outcome=awaiting_review、local_file、真实 media_sha256。这只登记预览，work 保持 active，不代表采用或完成；采用仍走原检查。检查 snapshot_refresh，失败只刷新本地快照并回读，不重复生成。

原资产行原位置显示新图与“待确认”，不新增筛选或多图展示。采用后显示新图已就绪；放弃后恢复原图已就绪，原本缺图则仍未就绪。完成度、分镜参考条和视频请求继续使用已采用图，候选不能充当生产素材。

询问采用前，先实际展示新图：核对快照刷新成功，按看板打开合同定位页面并给出实际看板文字链接，说明资产名称与“待确认”，用户可在资产列表放大查看，再询问采用／保留原图／重新生成（无旧图改为暂不采用）。聊天图片可额外展示，工具读取图片不等于聊天内嵌；无法内嵌时仍以已检查的看板为确认入口，不只输出文件路径或说“已展示”。不得虚构工具或承诺未验证的宿主能力，不上传到额外图床。采用与拒绝在聊天完成，页面无生产按钮。批量可整批或部分确认，未决定项保留候选。

首次分镜前生成图也主动在聊天展示；仅首次缺图、非重生、无旧选图且满足单张技术接入条件时自动采用，不额外询问确认。已有选择的候选以实际采用结果为准，保留旧图直到新选择写入并回读成功；不要把自动采用条件扩大为所有重新生成。已授权流程继续，批量合并新增图片，恢复不重复刷屏。

新视频按 assetId/Token 换引用并实时报价批准，保留模板／历史请求。未引用资产须重编译或显式编辑，不猜插入；defer_to_video 改必需先修订策略。

references.json 封存素材，image_adoptions 保存选择链；需求复核另存 *-references.json，历史视频按复核素材验证。旧复核缺快照仅恢复采用历史中完整绑定摘要精确匹配的状态，不猜名称／时间；损坏快照不回退。模板、需求、媒体、尾帧门禁保持。

旧 ASSET_IMAGES_FROZEN 显式 resume 原输出为候选，不重复付费。分镜编译在途时可独立生成候选，采用写入返回 ASSET_IMAGES_COMPILATION_IN_FLIGHT 时等待编译完成，再核对基线并继续采用；不重新付费生成。平台待采用候选不阻止用当前图片编译。

音色已统一候选、试听与明确采用流程，包括分镜后替换；音频字段、基础角色共享及历史任务保护见[音色采用](voice-adoption.md)，不填写图片专用 review_origin。
