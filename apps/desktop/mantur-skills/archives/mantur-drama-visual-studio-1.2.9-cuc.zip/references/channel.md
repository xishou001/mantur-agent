# Mantur Skill 广场渠道约定

本包适配平台现有 Skill 上传、审核、下载规则，不要求服务端增加 CLI 包类型。平台注入的开放接口说明描述底层协议；本包选择 ManturHub CLI 作为该协议的客户端实现，不是另一套认证或计费通道。

- 平台说明中的 API Key、幂等请求、文件上传、任务轮询由 CLI 处理。Agent 通过包内 ACCESS 转发，不读取凭据文件、不要求用户粘贴 Key、不另写 HTTP 调用。准备和执行步骤见下文与 [CLI 工具合同](cli.md)。
- 平台注入的积分是上传时快照；执行时仍通过 CLI 获取当前报价并遵守费用确认，不依据快照跳过确认或自动重试。
- 本包 SKILL.md 的 version 使用源码发行 SemVer，metadata.source_version 记录同一源码发行版本；上传后分别核对平台版本和源码版本。历史自动编号记录保留原事实，不据版本编号迁移项目或判断业务 runtime/schema 兼容性。
- 平台重写 SKILL.md 并归一化 ZIP 路径，下载包的摘要不是上传源 ZIP 摘要。工作项目仍保存在用户选择的工作区，平台分发并不代表云端执行脚本。

# 公共 CLI 接入

需要 Node.js >=20，正式 CLI >=1.2.10；默认安装精确版本 1.2.10，仅在用户批准后安装或升级。

先执行 ACCESS --source <实际宿主> check。默认复用 PATH 与已有登录；显式覆盖必须同时提供 CLI 绝对路径和配置目录。后续保持返回的 bindingArgs。

未登录时，用户同意后才执行返回的 loginInstructions.command/args/env；同一已检查终端可使用 quickLoginInstructions。不能按包名猜宿主、不自行登出或更换凭据。详见 [公共接入](access.md) 与 [工具合同](cli.md)。


测试平台交测的服务绑定见[test-mode.md](test-mode.md)，不能由下载渠道推断。
