# Seedance 分镜编译

默认使用已封存全集；显式子集只处理连续范围。保留资产映射、需求原件、唯一选图和音色/AI 直出策略。

    {"schema_version":1,"script":"input/script.md","requirements":"input/requirements.json","episodes":[1,2],"manifest_revision":1}

已有分镜后重编译需 generation_intent；模型参数放 parameters，不手写 fileId、requirementsResultId 或集数派生字段。

prepare-clip-compilation --input <文件> 返回 awaiting_manifest_review 与 operation_id。读取该操作 plan.json 中 candidate 与 candidate_sha256，展示实际素材绑定；确认后记录 {approved:true,operation_id,candidate_sha256}，再 resume-clip-compilation --operation-id <ID> --manifest-review <文件>。上传重试不重复确认同一绑定。

图片、音频以 candidate 中当前采用的唯一文件为准，不按角色名、候选顺序或最新生成时间另选。准备时先核对同项目已完成公共调用的原件与回执，并通过当前接入查询原 Job：原生成候选或成功上传记录与当前 SHA、字节数对应且文件身份未变化、未明确过期时，直接复用 fileId。原结果没有 fileId、当前采用的是转码后的新音频、回执无法核验或当前接入无法查询原任务时，走原独立上传流程。旧私有槽位不迁移；未决任务不重提。

剧本和本次新组装的生产清单仍按原路径准备上传；本项仅优化 Seedance 图片、音频。已保存到当前分镜操作的引用继续保持原身份，不因后续发现其他记录而改写。视频、WAN、素材审核与费用确认流程不变。

ready 后按 [公共调用](public-cli-adaptation.md) 提交并确认费用。成功后校验源文件、清单、请求与原产物，按 [修订合同](clip-revisions.md) 发布。不再请求用户分镜确认才能继续已授权范围，但保留真实依赖检查。WAN 使用 [完整资产表路线](clip-compilation.md#wan-完整资产表编译)。

# WAN 完整资产表编译

沿用 [完整资产表](wan-asset-table-v3.md) 的显式绑定与审核规则。先 inspect-wan-asset-table，处理 explicit_voice_bindings_ready=false；不能从摘要猜媒体。使用已封存全集或明确连续子集。

    {"schema_version":1,"script":"input/script.md","production_asset_table":"input/table.json","episodes":[1,2],"parameters":{"resolution":"1080p","ratio":"9:16","generateAudio":false}}

prepare-clip-compilation，再 submit-clip-compilation / resume-clip-compilation。业务派生 scriptFileId 和 productionAssetManifestFileId，不发送 requirementsResultId，费用批准传 --confirm。

新请求沿用项目的比例、分辨率与创作风格，并显式填入模型时长范围；描述中的配置与项目冲突时先修正本地输入。继续旧操作时保留原请求和确认，旧请求未写时长范围的导入按已记录的 WAN 合同默认 4–30 秒验证，不回填历史文件。

成功后自动构造 schema_version=2 的 import-clip-compilation 描述，核对生产表、请求、Job 与产物。snapshot_refresh.ok=true 只说明刷新成功，candidate=true 仍按修订合同采用。查询/下载失败不重复 run。见 [公共入口](public-cli-adaptation.md)。
