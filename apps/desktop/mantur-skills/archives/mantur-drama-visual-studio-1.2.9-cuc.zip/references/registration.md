# 注册入口

- [workbuddy](https://hub.mantur.ai/login?from=workbuddy&businessCode=mantur-drama-visual-studio-skill)
- [codex](https://hub.mantur.ai/login?from=codex&businessCode=mantur-drama-visual-studio-skill)
- [claude-code](https://hub.mantur.ai/login?from=claude-code&businessCode=mantur-drama-visual-studio-skill)
- [cli](https://hub.mantur.ai/login?from=cli&businessCode=mantur-drama-visual-studio-skill)
- [unknown](https://hub.mantur.ai/login?from=unknown&businessCode=mantur-drama-visual-studio-skill)

仅提供入口，不自动注册、登录或提交任务。


测试模式不使用本页生产链接；使用 ACCESS 动态返回的同源授权入口，见[测试授权](test-mode.md)。
