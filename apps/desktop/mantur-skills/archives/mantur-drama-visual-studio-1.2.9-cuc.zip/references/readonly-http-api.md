# 本地只读 JSON API

2026-10-16 资产可选 pending_images 仅供原缩略图位置显示待确认新图，沿用 MediaRef 脱敏和 media_id 只读访问。已采用 local_media 不变，不新增采用／拒绝接口；详见[图片采用](image-adoption.md)。

2026-09-22 视频显示扩展：公开 v1 结构不变；项目快照的 `ratio` 发布兼容后的有效项目比例，本地 MP4 可探测时在既有 MediaRef 可选字段发布真实宽高和时长。页面优先使用 Clip 模板比例，模板缺失的成片再回退媒体宽高、项目比例和 `9:16`；生成中、失败卡使用模板／项目比例。结果区按容器宽度排成 1–3 列，不增加写接口或生产按钮。

服务只绑定 `127.0.0.1`，端口由操作系统分配，运行记录为 `.pipeline-state/runtime/readonly-service.json`。快照 HTTP 处理器只读取当前 Manifest 及其引用；同宿主的独立 JSON 同步模块负责调用 Compiler 发布新快照，二者不调用 ManturHub、不代理远端 URL、不执行生产动作。本版余额接口只返回不可用兼容状态，不执行余额命令，不设余额定时器。服务不启用 CORS。

包内 Snapshot Compiler、只读服务和同步 Compiler 统一以隐藏、非 shell 子进程启动，并在加载前移除 `NODE_OPTIONS`／`NODE_PATH`，避免把 Agent 宿主注入的 Node preload 传播到包内进程。外部 ManturHub CLI 仍继承原宿主环境及安全 Hook；只读服务启动时仅在进程环境中临时中继原值，调用 CLI 时恢复并立即移除中继键。原值和中继键不得写入项目、日志、诊断、快照或 API。该隔离只约束 Skill 自己的进程，不代表已修复宿主自行派生的可见辅助窗口，也不构成 WorkBuddy 兼容验收。

## 聊天动作

```powershell
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" start-readonly-service
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" serve-readonly-service
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" open-workbench --require-existing
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" readonly-service-status
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" stop-readonly-service --confirm-stop
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" begin-snapshot-batch --lease-seconds 90
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" snapshot-batch-heartbeat --update-id <id>
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" commit-snapshot-batch --update-id <id>
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" abort-snapshot-batch --update-id <id>
```

启动动作先刷新快照；同项目、同 project_id、PID 存活且 health 匹配的实例直接复用。陈旧记录会被清除后重启。`start-readonly-service` 生成 detached 服务；`serve-readonly-service` 输出单行启动 JSON 后保持前台运行，必须由宿主长期后台任务或用户终端持有。停止只能响应用户明确的聊天请求，并要求 `--confirm-stop`。

### 看板链接的输出格式

本规则适用于所有聊天中的看板入口，包括首次打开、提取后补漏、中断续跑、图片查看提醒、视频结果反馈和只给链接。显示文字固定为“打开生产进度看板”，完整实际地址仅放在链接目标中，不依赖宿主自动识别裸 URL。

1. 只使用本次 `open-workbench` 页面检查成功后返回的完整 `url`。不从旧聊天、截图或展示记录复制端口；没有检查成功的地址时如实报告，不生成链接。
2. 链接独占一个段落，前后留空行；链接所在行不放标签、标点、括号说明或其他文字。不加粗、不包反引号或代码块、不使用方括号裸地址，不另外附裸地址。
3. 发送前逐字核对链接目标与返回的 URL 完全一致；目标中不得拼入强调符号或说明文字。端口变化只替换本次地址，不沿用旧项目链接。写法如下，`实际URL` 只是文档占位符，发送时必须替换，代码围栏也不进入实际回复：

```markdown
[打开生产进度看板](实际URL)
```

浏览器工具的参数仍使用原始 `url`，不要传整段 Markdown。打开成功、queued 和尝试失败的状态说明放另一个段落；仅 queued 时说“已请求打开”，失败时保留已验证链接，不宣称“已打开”，不循环弹页或重启健康服务。

用户明确要求排障或复制原始地址时，可另用独立的单行代码块提供同一个已验证 URL，不能把裸地址与加粗或说明混排；普通看板反馈仍只使用文字链接。此格式约束不改变检查、打开权限、服务生命周期或生产恢复边界，也不代表已完成任一宿主的真实渲染验收。

### 跨宿主生命周期与交接

服务只保证当前智能体会话期间存活，不安装系统服务、计划任务或隧道。Agent 不按产品名假定进程一定存活，而按工具能力选择启动方式：宿主提供明确的长期后台命令能力时，用该能力托管 `serve-readonly-service`；WorkBuddy 可用时传 `run_in_background=true`。没有这种能力的本地宿主使用 `start-readonly-service`。Codex 当前实测可走 detached，但仍遵守下述复核；远程或容器宿主还要单独确认用户浏览器能否访问执行机回环地址。

启动返回 `instance_id`、`launch_mode=detached|host_managed`、实际端口和 URL。Agent 必须等启动工具调用结束，再用新的独立工具调用执行 `readonly-service-status`，核对 `running=true` 且 `instance_id` 不变；随后才执行带 `--require-existing` 的 `open-workbench`。该选项只复用健康实例，缺失时返回 `READONLY_SERVICE_NOT_RUNNING`，不隐式启动或返回未经跨调用验证的 URL。旧健康状态缺少 `launch_mode` 时返回 `legacy_unknown` 并继续复用，不因此静默重启。

detached 复核失败时，若宿主存在长期后台任务能力，最多改用 host-managed 重试一次；否则不返回链接，并给出让用户在自己的终端保持运行的 `serve-readonly-service` 命令。不得用 `nohup`、`Start-Process`、watchdog、系统服务或计划任务绕过宿主回收。宿主直接强杀后台任务时可能留下陈旧状态，下次 status 会清理；正常停止仍只调用 `stop-readonly-service --confirm-stop`，不直接调用宿主的 TaskStop。看板故障不改变生产结果，也不授权重新提交任务。

### 图片查看前的看板检查

生成图片技术接入并自动采用后，请用户看图前先执行 `readonly-service-status`。健康服务复用；服务未运行且用户未禁止时，依据上方跨宿主生命周期合同选择 detached 或宿主长期后台任务启动。必须在启动调用结束后的独立工具调用中核对 `running=true` 及相同 `instance_id`，随后通过普通 `open-workbench --require-existing` 检查页面并取得实际 URL。不是仅检测 Node 存在、检查旧端口记录，或把启动命令退出成功当成服务可访问。

本次已交接页面时使用 `--link-only` 取得检查后的链接，不逐图重复打开；同一批新增结果合并一次检查与提醒。尚未交接时按宿主能力复用同项目页面或尝试打开一次，遵守用户只给链接或禁止服务的选择。图片在看板查看，审核建议只在聊天提供，不要求图片确认，不新增页面确认或重生成按钮。

服务启动不支持、跨调用复核失败或页面不可用时保留图片、审核和旧快照，按实际故障报告；仅按生命周期合同有限回退或提供手动前台命令，不猜 URL、不静默重启旧服务、不重提生图。远程／容器宿主另行核实用户能否访问回环地址，不能宣称未经实测的宿主已兼容。没有可查看页面时不声称已交接或催促确认。

## 权威 JSON 自动同步

服务启动后默认启用；浏览器关闭不停止同步，明确停止服务后才停止。监听当前选中的项目、提取、库存、匹配（含音色）、分镜、Task/Run/交付索引，以及检查点、视频结果和 legacy 草稿 JSON。沿用项目指针、Manifest 指针、标准路径的顺序，未被选中的报告不会影响发布。

连续两次内容检查相隔约 2 秒且稳定后编译；每 10 秒检查监听遗漏。编译耗时及页面约 3 秒轮询另计。自动编译在子进程执行，与主动刷新共用项目锁；相同 JSON 已发布则跳过。输入不完整或错误时保留上一版快照，按 5/10/20/30 秒退避，修复输入后重新等待稳定。不会回退其他报告、重新提交任务或改变完成门禁。

纯媒体变化不触发同步；替换图片、视频、尾帧或 ZIP 后仍须主动执行 `refresh-ui-snapshot`。主动刷新始终校验媒体；`--no-write` 不创建同步状态或发布凭据。

手动快照批次只用于 Agent 直接执行、确实需要协调的多文件编辑，例如直接重建库存或同时更新多个权威 JSON。素材采用（含 `apply-asset-review`、内置生成图接入及平台结果恢复）、资产提取接入和分镜接入已由 Runtime 管理事务，禁止外包 `begin-snapshot-batch`；不能因“批量生图”就为整段生成／采用套手动批次。同项目主动素材采用、补漏和手动刷新顺序调用，前一个本地动作返回后再调用下一个；本地自动同步保持，新版远端操作按公共流程顺序推进。Runtime 已自动刷新成功时不重复发布，直接文件编辑和纯媒体变化仍须主动刷新并回读。

手动批次租约有效时自动同步等待，非持有者主动刷新返回 `PROJECT_UPDATE_IN_PROGRESS`；heartbeat 续租，commit 在完整输入稳定后刷新一次，abort 只结束等待、不回滚生产文件。媒体先写同目录临时文件，经 MIME、扩展名、大小和 SHA-256 校验后原子替换，权威 JSON 最后原子发布。手动批次租约默认 90 秒；素材采用、资产提取接入、分镜接入和素材选择恢复的新内部租约为 300 秒（5 分钟），视频事务仍为 90 秒。已有租约保留原到期时间；缩短新租约只减少残留占用时间，不解决清理失败，也不表示到期后自动恢复业务。commit 刷新失败保留租约，不自动 abort；commit／abort 清理失败返回 `ok:false`、`SNAPSHOT_BATCH_CLEANUP_FAILED`、`retryable:false`，commit 已完成的 `snapshot_refresh` 保留，不能宣称批次已结束。生产动作清理失败保留原业务结果及刷新状态并输出同名结构化 stderr 告警，不意味着素材未采用或需要重新生成。

`batch_update.active=true` 是同步器观察到项目批次的摘要，不是看板持锁证明。遇到冲突先按[批次恢复指引](lock-and-queue-recovery.md#快照批次冲突与清理)核对原操作、批次来源及已保存结果；不能从磁盘读到一个 ID 就认定拥有批次，不能默认等待十五分钟、循环清理或静默重启服务。

`readonly-service-status` 返回附加 `snapshot_sync`：`enabled`、`state`（waiting/compiling/idle/error/stopped）、最近检查及成功时间、revision、脱敏 `error_code`、`batch_update` 和 `last_successful_revision`；顶层同时给出最近错误和批次摘要。同步版本为 2，旧实例返回 `enabled=false/restart_required=true`，不能静默重启。同步记录、发布凭据和只读服务诊断均位于 `.pipeline-state/runtime/`，只记录本地关联和脱敏错误码，不含 JSON 正文、密钥、远端 URL 或任务 ID；都不是生产输入，也不通过 HTTP 暴露。API 和业务 Snapshot Schema 不变。

## 冻结端点

```text
GET /api/v1/health
GET /api/v1/project
GET /api/v1/assets
GET /api/v1/episodes
GET /api/v1/episodes/:episode_id
GET /api/v1/tasks
GET /api/v1/deliveries
GET /api/v1/media/:media_id
```

`HEAD` 与对应 `GET` 使用相同状态码和响应头但没有 body。其他方法返回 `405` 和 `Allow: GET, HEAD`。未知路由、episode 或 media 返回结构化 JSON 错误。

Snapshot 端点直接返回完整 Envelope，以快照 SHA-256 作为 ETag；health 返回当前 `project_id`、`revision`、PID 和服务版本。`If-None-Match` 命中时返回 `304`。

媒体只可通过快照中已发布的 `media_id` 获取。服务拒绝绝对路径、路径穿越、项目外文件、符号链接、缺失/空文件和 MIME/扩展名不匹配；支持单段 byte range。文件通过同一个已打开句柄完成 stat、流式 SHA-256、签名检查和响应发送；替换、删除、错误 MIME 或客户端中断最多终止本次请求，不得终止 HTTP 服务。响应设置 CSP、`nosniff`、同源资源策略、禁止 framing 和私有 no-cache，不暴露凭据、签名 URL、远端 task ID 或文件系统绝对路径。

## 包内只读看板

静态页面随包发布于 `ui`，只读消费同源 API。资产按“已就绪 → 待处理 → 可延后”排列，同组保持原顺序；不显示“已就绪资产”标题或逐项操作提示。待处理／可延后数量切换筛选并定位原列表，不新增弹框。可延后图片显示蓝色，不计必需缺失或待处理，AI 直出音色不混入此筛选；音色按基础角色去重。

旧客户端的 GET /api/v1/account-balance 接口继续返回不可用状态，保持 Envelope 兼容；新版不执行账户绑定余额查询，不启动 CLI、不要求登录、不读取凭据或写入余额缓存。前端隐藏不可用余额，页面与快照继续正常使用。

完整提示词不得改写。视频历史仅供预览，严格完成按采用 Run 的技术门禁判断。筛选、剧集／Clip／结果选择、展开和媒体播放不改变业务事实；生成、上传、批准、重试均留在聊天中，不能增加页面业务按钮或 HTTP 写接口。

`open-workbench` 保留兼容的一步启动或复用能力；Skill 的正常 Agent 流程必须先完成跨工具调用复核，再使用 `--require-existing` 只复用服务并检查根页面，返回 `url`、`browser_opened=false` 和 `open_via_agent=true`。Agent 随后使用宿主浏览器工具打开链接；宿主无浏览器工具时返回链接。旧服务没有页面时明确报告 `WORKBENCH_UNAVAILABLE`，须得到用户停止旧服务的明确要求，不自动杀进程。

### 用户主动打开看板

“打开看板”“重新打开”“把侧边看板显示出来”是独立查看请求。先定位用户指定或当前已明确的项目；存在多个候选且无法确定时只澄清项目，不猜最近目录。项目已明确时无需再问是否打开，也不要求登录、素材就绪或恢复生产。

按[续跑交接](#中断后继续制作的看板交接)第 2–4 步检查服务、页面并执行宿主打开。使用普通 `open-workbench --require-existing`，不带 `--on-project-ready` 或 `--after-extraction`，不删除展示记录。本轮已交接、用户关闭过页面、旧记录为 `attempt_reserved`／`link_only` 或首次入口返回过 `already_handled`，都不阻止新的明确打开请求；不能回复“已经打开过”后只发链接。

本次明确要求打开可覆盖此前“只给链接／不弹页面”的展示偏好，仅用于本次请求；单纯关闭页面不等于永久禁止打开。仍明确禁止启动服务时不启动，已有健康服务可用于打开；请求同时要求打开又禁止服务且服务未运行时，说明冲突并等待用户解除该限制，不擅自启动。宿主权限和能力限制始终保留。只打开看板不主动查询远端生产任务，不执行任务恢复、上传、报价或生成；新版账户绑定余额保持不可用。

### 打开工具与回执

本节适用于首次、续跑和主动打开。`open-workbench` 只负责本地准备和页面检查：`browser_opened=false` 不表示宿主打开失败，`open_via_agent=true` 也不表示已经打开。满足 `ok=true`、`open_via_agent=true`、用户允许且有可调用工具时，Agent 必须调用宿主打开或定位工具；提供链接不能替代工具调用。

优先当前宿主实际提供的内置浏览器／侧边预览工具，按其工具描述传入原始 `url`，不猜专有工具名或参数。能识别同项目页面时优先定位；端口变化仅导航已确认属于该项目的旧页。没有内置能力时可使用宿主允许的系统浏览器工具；用户明确仅要侧边预览而该能力不可用时，说明限制并给链接，不改开外部窗口。没有打开工具或本次只给链接时使用 `--link-only`。Node 入口不启动浏览器，不另写 shell 弹窗命令绕过宿主限制。

结束交接前核对本次工具回执：成功才称“已打开／已定位”；queued 只称“已请求打开”；失败、无工具或受限则说明实际情况并保留已检查通过的链接。仅工具调用、服务健康、旧展示记录或聊天链接都不是成功证据。同一请求失败后不循环弹页、不重启健康服务；用户后来再次要求打开，重新检查并尝试一次。工具证实复用同项目页面时才称已复用，无法列出页面时不宣称已去重；不能仅凭返回了 URL 就声称侧边看板可见。

### 项目准备完成后的自动交接

新项目准备完成的主入口是 `open-workbench --on-project-ready`；中断后继续已有项目改走下方续跑交接，不使用项目级一次性展示记录决定是否打开。Agent 在用户选定剧本、项目配置保存完成后调用；明确提供剧本并要求制作已构成选择，不必再次询问。单纯讨论、选稿或查询状态不调用。该步骤在远端生产预检、上传、报价和提交前执行，不授予生产权限；初始化的账号状态检查及获同意的登录可先完成，但看板打开不以登录成功为前提。

入口读取 project.json 的 `source_script.path/sha256`，要求非空剧名、项目内普通非空文件、有效相对路径及匹配的 SHA-256，拒绝越界和符号链接。正常 Agent 流程已先完成服务启动与跨调用复核；入口带 `--require-existing` 时只复用该服务，再刷新初始快照并检查页面，返回前复核项目与剧本。缺失、变更或无效输入返回 `WORKBENCH_PROJECT_NOT_READY` 原因，不猜文件、不自动补摘要、不创建假资产报告。服务准备成功前不写展示记录。

首次返回 `open_via_agent=true/presentation_reason=project_ready`，与下方 `--after-extraction` 共用同一记录和锁，后者保留资产报告门禁。两个自动选项互斥，同时传入返回 `WORKBENCH_OPTIONS_CONFLICT`，不启动服务。旧 schema_version=1 展示记录继续有效，无需迁移。普通显式打开仍不受自动防重限制。

所有自动交接失败均返回 `WORKBENCH_HANDOFF_FAILED`、`production_result_preserved=true/retry_production=false`，附带脱敏 `error.stage` 和 `error.cause_code`，区分输入校验、服务准备和页面检查；不返回未检查通过的 URL。既有快照保留，只恢复失败的本地步骤。浏览器尝试已预留后即使宿主失败或中断也不自动重复，仍可显式要求打开。

打开方式、只给链接、禁止服务和远程地址限制统一沿用下方规则。页面复用“待资产提取”与空列表，实际任务运行后才显示“提取中”；公共 Schema/API 与布局不变。

### 资产提取后的自动交接

作为旧项目和未完成前置展示的兼容补漏，提取报告落盘、项目指针更新、结构验收及快照发布成功后，Agent 先确认跨工具调用复核通过，再执行 `open-workbench --after-extraction --require-existing` 获取链接。提取前已预留展示或本次连续执行已完成续跑交接时，不再尝试弹页。此时允许资产尚未匹配、图片尚未生成、存在阻断问题；不能以资产完成度为打开门槛。提取任务仍在运行、报告未通过结构验收或只有远端结果未落盘时，不调用此提取后入口。

- `--after-extraction`：检查当前成功发布的 Manifest 包含资产报告引用，再启动/复用服务。使用项目私有 `.pipeline-state/runtime/workbench-presentation.json` 记录 `schema_version=1`、`project_id`、`revision`、`disposition` 和 `recorded_at`；项目锁保护原子写入，防止并发打开。记录不包含端口、URL 或敏感数据，不属于生产事实、JSON 同步输入或公开 API。
- 首次返回 `open_via_agent=true/presentation_reason=first_extraction`，写入 `attempt_reserved`。这是浏览器尝试的预留，不是成功打开的记录。重复返回 `false/already_handled`；即使第一次浏览器失败或 Agent 中断，也不自动重复弹页，仍提供当前链接。普通显式 `open-workbench` 不受此防重限制。
- `--link-only`：用户不打开页面、无宿主打开工具时使用；与任一自动入口组合会写入 `link_only`，返回 `open_via_agent=false`。明确“不启动服务”时不要调用入口。宿主能力或用户限制比返回的建议优先。
- 记录不可读/写时仍返回可用链接，但禁止自动打开，附带 `presentation_warning=WORKBENCH_PRESENTATION_STATE_UNAVAILABLE`，不覆盖损坏记录、不反复尝试打开。
- 提取后服务/刷新/页面检查失败返回 `ok=false/error.code=WORKBENCH_HANDOFF_FAILED`、`production_result_preserved=true/retry_production=false`（命令退出码非零）。它只表示展示交接失败，不能据此把提取改成失败或重新提交算子；保留最后成功快照，先检查快照/服务。旧实例缺页面时仍必须由用户明确要求停止旧服务，不能自动重启。
- `url` 始终来自本次健康服务及页面检查，不从展示记录复用旧端口。Agent 按[统一链接格式](#看板链接的输出格式)发送文字链接；只有宿主工具证实打开成功才说“已打开”，queued 只说“已请求打开”。本地链接只在能访问执行机回环地址的环境有效，不承诺跨机器或跨源 iframe 可用。

浏览器由 Agent 调用宿主工具打开，Node 入口绝不启动浏览器。不会增加 HTTP 写接口、登录检查、生产调用或 UI 控件。后续 JSON 自动同步与 Agent 主动刷新继续按原约定执行。

宿主能识别同项目已打开的页面时，优先复用或定位该标签页，不创建重复标签页。展示记录仅限制两个首次自动入口的尝试，不证明页面仍打开，也不记录宿主标签页 ID。

### 中断后继续制作的看板交接

用户在新对话、智能体重启或制作中断后要求继续已有项目时，无论已到图片、音色、分镜、视频还是交付阶段，Agent 都先读取本地项目与原操作、核对本次范围，再恢复看板。用户的继续制作请求已包含这次默认展示，无需再问是否打开。该步骤不要求重新上传剧本、重新初始化或再次提取资产，也不以登录成功或素材就绪为前提。

1. 先遵守仍有效的用户展示偏好。明确“不启动服务”时跳过服务与打开动作；“只给链接／不打开页面”时使用 `--link-only`，不调用浏览器。无打开工具时也只给链接。旧展示记录中的 `link_only` 可能来自旧宿主缺少工具，不能单凭它推断用户永久禁止打开；用户明确表达的限制仍优先。
2. 执行 `readonly-service-status`，健康服务直接复用，不停止或重启。仅在服务未运行且用户未禁止时，按上方生命周期合同启动；启动调用结束后，必须在新的独立工具调用复核 `running=true` 和相同 `instance_id`。旧健康服务要求升级时仍需用户明确停止授权。
3. 健康检查通过后使用普通 `open-workbench --require-existing`，需要时追加 `--link-only`；续跑不带 `--on-project-ready` 或 `--after-extraction`。该入口检查当前页面并返回实际 URL，不读取一次性展示防重记录。不要删除或改写旧展示记录，也不要把 `already_handled` 当作页面仍打开的证据。
4. 仅在 `ok=true`、`open_via_agent=true` 且宿主允许时，必须按[打开工具与回执](#打开工具与回执)实际调用浏览器打开或定位工具，不能在取得 URL 后直接结束。没有可复用页面时打开一个页面；宿主无法列出页面时最多尝试打开一次。始终返回已验证的实际 Markdown 链接，queued 只说已请求打开。
5. 同一次连续执行只交接一次，由当前负责用户对话的 Agent 统一处理。普通轮询、自动恢复临时网络错误、阶段切换、费用批准后的继续和上下文压缩都不是新的续跑，不重复打开；本次已交接后，提取完成的补漏也不再触发浏览器。只有再次中断后用户要求继续，或用户明确要求打开，才重新交接。不为每条 Clip 或每个子任务各开页面。

浏览器尝试失败或宿主返回 queued 后，本次不循环弹页，保留可用链接；以后用户中断后再继续，可重新尝试。服务、快照或页面检查失败时按实际阶段报告，不伪造链接，不自动停止旧服务、不重提生产；仅继续其他已授权且门禁满足的步骤。远程宿主沿用回环地址限制，不创建隧道、不宣称用户已能访问。仅查询进度、讨论剧本或分析故障不触发本续跑交接。

静态 GET/HEAD 仅允许 `/`、`/index.html`、`/app.js`、`/app.css`、`/video-loading-background.png`、`/video-loading-background.webp`、`/mantur-balance.png`。文件来自 Skill 自身 `ui`，不是项目目录；其他包内文件不可通过 URL 读取。旧背景 PNG URL 是 WebP 的兼容别名，二者返回相同字节及 `image/webp`，保留 GET/HEAD、ETag、精确白名单及路径校验。

Header Logo 与 favicon 直接使用 `https://mantur-pro.tos-accelerate.volces.com/mantur-static-assets-2026-10-10/images/brand/logo.png`，包内不携带品牌 PNG。旧 `/brand-mantu.svg`、`/brand-mantur.png` 的 GET/HEAD 固定返回 302 到该地址，不读取查询参数、不代理远端内容。页面及图标关闭 Referer，HTML CSP 的 img-src 仅额外允许该完整公共地址；脚本、样式、业务媒体和连接仍限同源，不允许内联脚本或 iframe 嵌入。断网或 CDN 故障只影响图标，文字品牌和本地看板继续可用。旧服务不会自动重启，更新包后需要用户授权重新启动看板服务以加载新路由。Agent 内独立浏览器标签页可打开，跨源 iframe 不属于当前承诺。

看板以 ETag 查询快照，前后台切换暂停/恢复轮询，网络错误退避并保留旧数据；组合响应的 project_id/revision/source_manifest_sha256 必须相同才能更新页面。

Episode Clip 新增可选 `video_results: [{run_id, attempt, video: MediaRef}]`，为通过本地完整性检查的预览历史；可选 `latest_video_attempt` 只表示最新生成尝试，不替代采用结果。EpisodeSummary 可选 `active_video_attempt_count` 只统计排队或运行中的最新尝试。旧消费者可忽略这些字段，旧快照缺失时继续使用 `latest_video_run` 和 `video_counts`。预览历史不包含远端地址，不表示验收；严格完成计数仍以 `latest_video_run.status=completed` 为准。

`latest_video_attempt.error` 沿用既有可选 `SanitizedError`，仅在算子明确返回失败、超时或取消终态后发布；查询超时、网络错误和限流等恢复异常不写成视频失败。历史终态检查点缺少错误字段时，Compiler 只接受与该操作 ID、Job ID、Clip 和终态全部一致且内容唯一的本地归档轮询响应，不联网、不修改私有操作。错误的密钥、完整 URL、本机路径和内部标识在 Compiler 发布前脱敏。包内看板按最新 attempt 显示排队/生成 Loading 或失败卡；更高 attempt 自动替换旧状态卡，私有历史不删除。失败浮窗只显示脱敏后的 `error.message`，缺失时使用通用说明，不显示错误码。所有状态卡不计入视频结果数、采用、严格完成和交付门禁。Manifest、Envelope、路由及 schema version 保持不变。
