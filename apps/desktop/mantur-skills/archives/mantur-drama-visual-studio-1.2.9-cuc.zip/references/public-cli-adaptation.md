# 公共 CLI 制作入口

接入、登录来源、专属后缀、费用确认、身份与恢复只遵循 [公共合同](cli.md)。业务不读取 Key、不安装私有 CLI、不构造认证 HTTP。platform.mjs check 返回 loginInstructions.command/args/env，保留原指引。

所有阶段通过 scripts/studio.mjs --project <绝对项目目录>。项目绑定 businessCode 与 skillRunId；8 个算子固定步骤，WAN 为 stepCode=wan-compile；恢复原入口与上下文，不回填旧批准。

## 执行环境绑定

首次检查明确当前实际宿主，使用 platform.mjs 的 check；项目目录已确定时必须同时带 --project。检查成功即把返回的非敏感 bindingArgs 写入项目 .pipeline-state/public-cli-binding.json，固定本次宿主来源、CLI 入口、配置目录及业务上下文；不写入凭据、确认令牌或账号全局默认值，也不创建制作任务或流程 ID。相同绑定的重复检查不重写文件。

检查发生在项目创建前时，只保留本次返回的完整 bindingArgs。项目目录确定后，将其原样用于一次 platform.mjs --project <绝对项目目录> <bindingArgs逐项传递> check；成功后各阶段、批量制作和 worker 自动读取项目绑定，不再逐次手补参数。未完成项目绑定且没有明确来源时，静默使用 unknown 继续，不增加来源提醒或制作门禁。

已确认来源不会被后续缺失值或 unknown 默认值覆盖。明确换宿主时，先用实际新来源完成同一项目的 check；CLI/config 和业务仍必须匹配原绑定，不能顺带换账号或站点。失败检查不创建或替换绑定，并发冲突停止本次新动作并重新检查，不抢锁或猜选来源。残留 public-cli-binding.json.check-lock 按原进程核对后人工处理，不自动删除。

旧项目缺少绑定、绑定未记录来源或为 unknown 且当前来源明确时，describe、quote、upload 和不带原确认令牌的 run 会自动完成项目检查，再保存当前已明确的来源；检查失败则返回原检查结果，不继续调用或创建流程。实际宿主由入口显式来源或当前环境变量提供，不能从发行渠道、安装目录或旧 unknown 猜测。当前来源也不明确时静默使用 unknown，经原认证和费用流程继续，不新增来源错误、提醒、确认或额外的来源修复检查。已有明确来源的项目继续直接复用绑定。

来源绑定只约束后续新调用。已有费用确认、已受理、受理未知和恢复记录仍由 CLI 使用原快照，不把历史 unknown 改成当前来源；登录注册入口仍由公共合同生成，不要求用户为补调用归因重新登录。

费用确认与实际提交始终复用同一项目和公共接入上下文，不绕过入口单独取得确认令牌或手动补归因。输出或回执异常时保留原操作，按原受理证据恢复；缺少输出不能证明未提交，也不能据此重新调用。

| 业务名 | 准备动作 | 算子 |
| --- | --- | --- |
| asset-extraction | prepare-asset-extraction | op.drama.asset-extract |
| asset-operation | prepare-asset-operation | op.image.generate、op.video.understand-v2、op.voice.design、op.audio.generate |
| clip-compilation | prepare-clip-compilation | op.drama.clip-seedance-compile、op.drama.clip-wan-compile |
| video-generation | prepare-video-generation | op.video.generate |

每类都有 submit-、resume- 和 <业务名>-status。准备传 --input <项目内描述文件>，后续传 --operation-id <返回值>。prepare 只校验、独立上传、describe 和 quote；已授权制作才 submit。收费时展示 CLI 原信息，获批后传 --confirm <原令牌>；令牌不写项目文件，不用旧 --approval 代替。

准备完成的 `quote/fees` 用于完整费用展示，并附单次查询余额；按[费用展示](quote-and-balance.md)先在聊天正文展示完整报价表，再按[用户选择与确认](../SKILL.md#用户选择与确认)主动调用宿主选择工具请求费用批准。余额查询失败仍显示余额“当前余额暂不可用”和余量“暂无法估算”，不阻断制作；纯询价展示表格后结束。`query-account-balance` 已恢复为公共单次查询；看板沿用原查询与刷新交互，不提供持续账户绑定或持久余额缓存。

prepare 加 --no-write 或 --local-only 只做本地候选检查，返回 read_only=true，不创建操作记录、不上传或询价；预览 ID 不代表操作已准备。需要制作时不带预览标志重新 prepare。

## 阶段状态与继续

- preparing：修正文件、登录或上传错误后 resume 原操作。成功上传按摘要与字节数复用，不删除状态、不批准上传轮次。
- awaiting_manifest_review：展示实际素材绑定，确认后以 --manifest-review <文件> 继续。这不是费用批准。
- ready：可提交已授权操作；报价不等于授权。
- confirmation_required：按公共合同确认费用；令牌过期则重新 submit 取得新确认，不自动同意价格变化。
- accepted / submission_unknown：只 resume 原调用。原 CLI 进程存活时等待；即时保存 CLI 发出的恢复 ID，不另造幂等键。
- result_pending：继续原 Job 的查询、下载或导入。原件已在指定路径时可 --local-only，看板失败只重试刷新。
- terminal：原 Job 已失败、取消或 TIMED_OUT；新授权后 prepare --retry-of <原ID> --attempt <新标签>，先查询原终态。
- completed：结果已接入或候选已保存，继续下一业务步骤；候选不等于已采用。

登录、上下文检查或进程启动在实际派发前失败时，保留原待提交状态，修正后继续；原 CLI 明确返回且绑定匹配的 NOT_SUBMITTED 可重试，REJECTED 按终态后继处理。缺恢复 ID 本身不能证明未提交。中断后沿用同一回执分类，不重复生成。

分镜 PRIMARY_JSON 有效而可选 XLSX 暂不可下载时，先接入分镜并返回 attachment_warnings，不声称附件齐全；实际哈希错误、身份歧义仍阻断。completed 后使用 recover-clip-attachments --operation-id <原ID> 后补原 XLSX；失败可重试，不重新导入或生成，返回 attachment 路径，原报告与 intake 保持不变。视频接入使用原请求归档素材，期间采用新图不会替换原视频的输入证据。音频唯一候选技术接入按 [修复规则](repair-policy.md)，不补造 user_confirmed。看板只投影原操作状态，不创建第二套任务记录。

文件变更需重新 prepare；已形成不可变输入或显式换发上传引用时，传新的 --attempt 标签。原未提交准备保留，不要求删状态解除冲突。只有未提交或明确未受理项允许换发上传引用并重新准备；已提交项保留原输入。结果缺公开下载地址时，保留原任务，把原产物放入返回路径后继续，不能再次生成。理解与参考音频模式接受已有稳定公开 HTTPS URL，核对与本地原件摘要一致，不把 fileId 伪造成 URL 或 mediaRef。

## 原任务查询与结果交接

低层原 CLI 回执使用 platform.mjs --project <项目> status --receipt <原受理回执>，恢复 ID 使用 resume。未知提交没有恢复 ID 时核对原调用或交接稳定版本，不重新 run。

### 旧任务和试用记录

原 Runtime 批准、幂等、上传槽位及未知提交交给匹配稳定版本。新版返回 LEGACY_RECOVERY_REQUIRED，保留原字节；未知版本如实标明未知，不能转成新付费任务。已完成产物仍可严格导入、查看与导出；同目录禁止两种执行器同时写入。

批量素材与视频按[批次合同](video-batch-approval.md)整批询价、授权、预算预留与有限并发；视频询价不等待真实尾帧，生成输入在提交前才补齐。持续账号绑定余额、私有凭证切换和上传槽位查询仍不提供。等待见 [异步继续](async-wait-policy.md)，本地锁见 [锁恢复](lock-and-queue-recovery.md)。

视频状态的 material_warnings 为素材/质量元数据提醒，creative_warnings 为实际成片与创作预期差异；合并反馈，不要求清零。提醒单独保存在可变诊断中，不参与 plan.json、操作 ID、请求摘要或费用确认绑定。旧记录无提醒字段时按空列表读取，原任务恢复不重算历史计划。

仅审核编号变化时复用唯一等价原操作；若存在多个等价记录，返回 PUBLIC_PLAN_AMBIGUOUS，按原 operation-id 核对恢复，不按目录顺序或时间猜选，也不新建付费任务。

已知旧 Job 的公开查询与结果取回使用 recover-legacy-production，参数与严格导入边界见[旧任务交接](legacy-production.md)。此入口不将旧批准转成新 CLI 调用。
