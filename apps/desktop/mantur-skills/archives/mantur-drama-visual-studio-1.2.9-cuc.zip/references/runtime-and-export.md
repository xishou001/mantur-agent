# Agent 视频 Runtime 与导出合同

新版远端制作统一使用[公共入口](public-cli-adaptation.md)。本篇维护本地模板、选片与交付；身份、费用确认和原调用恢复遵循公共工具合同，旧远端任务交匹配稳定版本。

项目准备及续跑时按[看板交接](readonly-http-api.md#项目准备完成后的自动交接)操作；页面失败不撤销生产产物。完整表检查见[WAN 表](wan-asset-table-v3.md)，分镜替换见[版本合同](clip-revisions.md)，需求修订见[资产修订](asset-revisions.md)。

## 视频状态机

远端操作的 ready / confirmation_required / submission_unknown / accepted / result_pending / completed / terminal 及下一动作见[异步继续](async-wait-policy.md)。本地模板和 Run 保持已有协议；不把旧 quoted/approved 字段当作新 CLI 已批准的证明。

同场后续 Clip 必须使用前序验收通过视频的真实尾帧。未知提交只恢复原调用；下载或本地导入失败继续原结果，不重复生成。已完成资产可通过 import-asset-extraction 等严格接入入口恢复，本地校验不补造旧批准。

## 并发

新版恢复公共 CLI 批次报价、预算预留与有限并发，保留场次依赖和操作锁；不读取旧私有并发槽与账本。具体边界见[执行策略](video-batch-approval.md#批次调度与顺序依赖)。

## 编译后的 Seedance 模板

模板由分镜编译初始化，用户授权修改遵循下方写回流程，至少包含：

```json
{
  "model": "doubao-seedance-2-0-260128",
  "prompt": "...不要背景音乐，不要字幕。",
  "duration": 10,
  "metadata": {
    "content": [],
    "resolution": "480p",
    "ratio": "9:16",
    "generate_audio": true,
    "seed": -1,
    "return_last_frame": true
  }
}
```

不得把 `return_last_frame` 移出 `metadata`。图片与音频引用必须与 `metadata.content` 顺序逐项一致。历史直接供应商响应只用于迁移和审计；新项目只接受规范化 ManturHub 算子结果。任务成功但没有官方尾帧时只阻断该场次链，不得伪造完成。

## 请求字段与再次生成

原清单资产在分镜后补图或换图遵守[图片采用合同](image-adoption.md)：后续新视频可在实际请求副本中替换对应资产 Token 的文件引用，基础模板与历史 Run 保留。旧模板没有该资产引用时先重新编译或执行下方显式模板编辑流程，不能猜测插入。

每次构建视频请求，Agent 按 `Clip ID` 定位当前权威分镜报告的 `视频请求体` 行（旧版为 `Seedance2.0请求体`），遵守以下字段职责：

| 字段 | 用途 |
|---|---|
| `请求体模板JSON` | 每次生成唯一的模板来源，保留原始提示词和资产引用；不写入动态前序尾帧或本次追加的连续性段落。 |
| `实际请求体JSON` | 本次模板副本经 `materialize-video` 处理后的完整 JSON；其 `prompt` 保存含连续性描述的本次最终提示词，`metadata.content` 保存对应尾帧引用。 |
| `请求体JSON` | 不作为本流程的输入回退字段。 |

首次、重试和再次生成都从 `请求体模板JSON` 重新复制输入；同场连续镜头仅在该副本上注入一次当前操作已绑定的前序 Clip 真实尾帧（旧操作恢复遵循原记录）和对应 `@ImageN` 提示词。不得将上次实际请求再次送入注入动作，不得覆盖模板。模板缺失、无效或已被历史注入污染时，先核对模板来源并恢复，不从实际请求猜测剥离。场次首镜也从模板构建实际请求，但不注入前序尾帧。

连续性段落、`@ImageX` 占位符替换和尾帧引用顺序只在 [视频生成合同](video-generation.md) 定义；本流程只保证每次从基础模板重新物化，不把上次实际请求或动态尾帧写回模板。

Runtime 的 `materialize-video` 只读取 Agent 提供的文件并输出文件，不会自动选择或回填报告字段。Agent 必须保留每次 attempt 的独立模板副本、实际请求及转换后的算子参数文件；原子更新当前选中报告中该行的 `实际请求体JSON`，同步记录请求体阶段与尾帧注入状态，然后刷新快照。再次生成可更新该行的实际请求字段，但已提交 Run 的请求文件和哈希不可覆盖。最终报价、批准和提交均使用从本次实际请求转换出的精确算子参数文件。

恢复轮询或处理提交状态未知时只查询原任务，不因恢复对话重新构建或提交。修改本次实际请求后仍按原有规则重新报价并取得批准。

## 修改 Clip 提示词的写回流程

用户要求“改一下 EPxx/Cxx 的提示词”“替换某镜头的场景/人物引用”等时执行本流程。这里只修改下一次生成的基础模板；不得因修改而生成、取消或重新提交远端任务。禁止覆盖模板特指禁止写入动态尾帧注入结果，不禁止用户授权修改基础创作内容。

1. **定位与读取**：按 `project.json` 显式指针 → Manifest 指针 → 标准路径选择当前权威报告，以明确的 `Clip ID` 找到唯一的 Clip总表行和统一访问器选中的请求行。目标含糊先询问；模板缺失、无效或记录重复则停止写入。不得改未被选中的旧报告、UI 快照或请求体JSON代替。
2. **记录基线**：只读记录模板、引用、关联状态、项目指针和报告 SHA-256，保留原始数据。备份在第 6 步锁内基线复核通过后独占创建于 `.pipeline-state/runtime/prompt-edits/<唯一修改ID>/`，包括原报告及原有实际请求记录，不在此重复创建。它是私有审计资料，不成为 Compiler 输入，不记录密钥或输出远端 URL 到日志。
3. **修改模板**：文字修改落到 `请求体模板JSON.prompt`；除用户明确要求外不动模型、时长、比例、分辨率、seed 等参数。保留 `不要背景音乐，不要字幕。` 结尾等既有硬约束，不把上次实际请求或前序尾帧写回模板。
4. **同步关联**：新模板 prompt 同步到同一 Clip 的 `Clip总表.最终提示词` 和请求行的 `最终提示词`。改动涉及场景、画面、运镜或台词时同步受影响的结构化字段，不改无关字段。替换/增删资产时一并更新模板 `metadata.content`、图片/音色引用表和 Clip 的人物/群众/场景/道具/音色集合；按图片与音频各自顺序核对全部 Token、URL 和身份。没有唯一素材或编号歧义不得猜测；`请求体JSON` 保留旧值，不作为输入或权威派生字段。
5. **新内容重新校验**：实质修改后，Clip 的 `校验状态=待校验`、`审核状态=待审核`；请求行 `用户批准状态=未报价`、`请求体阶段=请求体模板`。这些原始状态用于兼容旧报告，当前 OpenAPI 由共享技术校验自动判定通过，不再请求用户分镜确认。本次修改使旧报价/批准不能用于新内容。原 `实际请求体JSON` 仅作上次构建记录保留，下一次禁止复用；生成状态、已提交 Run、任务/请求文件、hash 和历史视频均不改写、不取消。不变的修改请求直接报告未发生变化，不重置状态或写入报告。
6. **校验与原子保存**：先检查结构、唯一记录、Token/引用一致性、资产身份、音色、媒体上限及硬约束。结构错误或绑定歧义不提交；素材未就绪写入原有缺失依赖字段，保留门禁，不伪造通过。使用包内 `runtime/project-lock.mjs` 导出的 `withProjectLock`，锁路径为项目现有 `.pipeline-state/runtime/snapshot.lock`。锁内重新解析项目指针并比对原报告 hash；有变化则退出锁、重新读取合并，目标冲突需用户决策，不用旧整份报告覆盖其他 Clip。确认基线一致后独占保存备份，把更新后的整份 JSON 写同目录临时文件、回读校验、原子替换原报告。临时文件使用 `.tmp` 后缀；失败只清理本次临时文件，保留备份。所有目标须在项目内且无符号链接祖先。禁止在持有发布锁时调用 Compiler 或刷新，避免嵌套锁。
7. **发布与回读**：释放锁后主动 `refresh-ui-snapshot`；涉及多文件的修改遵守 Skill 的快照批次协调，只在完整保存后 commit。回读 Manifest 与同一 revision 的 Clip，核对 `prompt_template.prompt` 和引用。失败明确回复“内容已保存，快照刷新失败”，只重试本地刷新，不撤销已保存内容，也不提交远端任务。
8. **交接**：告知 Clip、主要变化、实际技术校验问题和“未重新生成视频”。下一次获授权生成时从新模板重新物化、按需加真实尾帧，转换成独立参数文件，重新 describe/quote 并取得批准。已有任务仍按原任务轮询，不因模板修改改变其内容或重新提交。

本流程是 Agent 写回约定，不是新增 Runtime 编辑命令；行为 eval 用于检查执行一致性，不能保证任意 Agent 总能正确操作。

## 图片生成路线选择与兼容迁移

以下值和命令仅供 Agent 在用户作出对应制作选择后内部执行；不要把命令、内部路线值或算子名直接发给普通用户。新项目只保存 `native_agent_imagegen` 或 `manturhub:op.image.generate`。历史 `codex_imagegen` 仅识别为 Agent 原生能力别名，绝不静默改道。普通流程不根据模型、宿主名称或能力探测自行决定路线：新的独立生图请求未指定方式时，先询问用户；只有用户明确说继续当前批次或沿用刚才方式时复用最近选择。上传或接入用户已有图片不读取、更改或依赖图片生成路线。

```powershell
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" inspect-image-provider-options --native-imagegen
```

此探测动作只保留给历史项目兼容或用户明确要求的技术排障；不能用于新的普通生图请求，也不能据此向用户断言宿主或本机没有内置生图能力。仅在当前 Agent 确有并能实际调用原生生图能力时才传 `--native-imagegen`。两个字段是兼容保留的交互建议，不是 Runtime 生产门禁；缺少选择记录时继续使用项目 `image_provider`。该动作不调用生图、不报价、不提交。

用户选择“Agent 内置生图”后的内部写入（目标值原本就是原生也必须记录）：

```powershell
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" select-image-provider --to native_agent_imagegen --user-selected --confirm-native-imagegen
```

用户选择“ManturHub 平台生图”后的内部写入：

```powershell
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" select-image-provider --to manturhub:op.image.generate --user-selected
```

若以上选择会真实改变已有 provider，再加 `--confirm-provider-change`；用户后续明确选择另一种方式时同样执行这一改道确认。新的普通生图请求始终使用 `--user-selected`，不得改用 `--only-available`。选择写入 `image_provider_selection={provider,mode}` 并追加 `provider_selection_audits`；同一批次中用户已明确说沿用时，检查到相同有效选择可幂等返回。Agent 未记录时，Runtime 不因此阻断，平台路线仍执行独立报价和费用批准。选择 Agent 内置生图后实际无法调用时，不写入虚假成功、不自动改道，等待用户明确选择平台路线。

旧项目仅规范历史别名时仍可使用迁移动作：

```powershell
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" migrate-image-provider --to native_agent_imagegen --confirm-native-imagegen
```

迁移后若尚无选择记录，缺失记录不阻断生产；下一次新的未指定方式的生图请求仍应主动询问用户，而不是探测后代选。旧迁移动作若真实改道且没有新的选择模式，会清除旧 `image_provider_selection` 而保留历史审计；别名规范化只保留与规范化 provider 一致的选择。所有动作只修改固定项目状态并追加审计；未知 provider 失败关闭。Provider 调用失败不得触发自动迁移或静默改道。

## ManturHub 视频算子

新合同使用 [视频生成动作](video-generation.md)。旧 materialize-video-params 仅作本地兼容，poll-checkpoint 已移除，恢复边界详见 [legacy 兼容参考](legacy-production.md)。

## 按集 ZIP 输入合同

两个导出入口共用交付门禁：先核对完整目标，再按交付计划或唯一合规候选确定 Run，校验技术证据、原生产血缘、真实尾帧及当前需求。多候选必须明确选择；不同承接组合须另行明确接受，不能靠输入 completed 放行。路径/SHA 必须与交付选择一致，剪映应用打开验收仍独立。详见 [视频选片合同](video-result-selection.md)。

Seedance／WAN v3 局部接入报告若在 `delivery_scope.incomplete_episodes` 标记某集，即使其中已有可预览或可生成视频的 Clip，该集仍缺完整分镜证据；ZIP 与剪映交付均停止，待补齐并显式切换完整分镜版本后再复核。未标记的剧集仍按原有完整目标、视频和尾帧门禁逐集判断。

打包使用临时文件；发布前在项目发布锁内复核报告、项目配置、交付计划选定 Run 与媒体。`EXPORT_SOURCE_CHANGED` 时丢弃本次暂存，保留之前有效包/索引，重新核对本地输入，不重新生成视频。导出成功但 snapshot_refresh 失败时只运行 refresh-ui-snapshot。没有成功回读不得宣称看板已更新；导出也不替代连接、合同、费用批准、媒体和连续性门禁。

ZIP 导出器只接受完成的本地视频：

```json
[
  {
    "clip_id": "CLIP-EP01-001",
    "episode": 1,
    "order": 1,
    "video_path": ".pipeline-state/results/videos/EP01/CLIP-EP01-001.mp4",
    "status": "completed",
    "sha256": "64-lowercase-hex"
  }
]
```

输入路径必须位于项目内，文件为普通非空视频，真实哈希与声明一致。每个目标 Clip 恰好出现一次；排序只使用 episode/order，不能依赖 JSON 原始顺序。任何缺失、重复、未完成或无效文件都会中止对应集导出。下例 plan_id 来自已就绪的 plan-video-export 交付计划；旧入口省略 --selection-plan 时，仅唯一合规候选且衔接一致可自动导出，旧报告继续使用 Runtime 兼容门禁。

```powershell
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" export-episodes completed-clips.json --output-dir exports --selection-plan <plan_id>
```

每集产生一个 ZIP，默认直接保存在 `exports`，也可用 `--output-dir` 指定项目内目录；不再创建哈希子目录。首次为 `EPxx.zip`，再次导出取该目录内已有最大编号加一，生成 `EPxx（1）.zip`、`EPxx（2）.zip`；不填补已删除的编号，不覆盖用户文件。编号选择受同集锁保护，完整暂存 ZIP 通过独占发布避免并发覆盖。私有 `runtime/export-publications` 记录绑定目录、编号、需求摘要和 ZIP 摘要；索引回写中断时保留完整包并恢复同一编号，篡改或未完成发布的需求变化继续阻断。成功后再导出使用新编号，快照失败仍只刷新。内部摘要及交付门禁保持不变。已存在的历史长哈希文件和目录不自动删除。ZIP 内视频按集内顺序统一命名为 `EPxx-CLIPxx.<原扩展名>`，例如 `EP01-CLIP01.mp4`、`EP01-CLIP02.mp4`；即使 Runtime 本地名称带有 `（n）` 生成轮次或 `-RESULTxx` 候选序号，交付包仍只使用该 Clip 在集内的标准名称，不沿用 Runtime 的本地文件名，也不增加额外排序前缀。交付索引保存项目相对路径、Clip 数、实际总时长、目标配置、验证摘要和包 SHA-256。完成后刷新快照。

## 可选剪映草稿

用户已明确授权剪映交付时调用 `export-jianying-drafts` 并遵循 [jianying-draft-delivery.md](jianying-draft-delivery.md)。这是单独的便携 ZIP 交付，不替代普通按集片段 ZIP；项目初始化和 `run` 不保存交付计划。

草稿使用真实媒体时长、单主视频轨和包内素材。本机原生自动安装在创建输出目录、ZIP、编号、发布／交付记录及快照刷新前，检查默认或 `--drafts-dir` 指定的草稿根目录；不查询 Windows 注册表或 macOS 应用包。目录缺失时停止且不产生本次交付；`--package-only` 或跨平台导出跳过该预检并只生成包。ZIP 和草稿实际目录无哈希，成功后新导出递增（1）、（2）编号；未完成操作与安装重试复用原包，不覆盖用户编辑或根索引。5.9.0 是生成格式而非应用版本门槛；目录存在只代表安装目标可用，包校验、安装状态和应用打开验收仍分别表达。预检通过后的安装竞态失败保留 ZIP，通过 `import-jianying-draft` 重试，不重新生成视频。

## Snapshot 与只读服务边界

Runtime 写入权威业务结果，Snapshot Compiler 读取并脱敏；二者之间通过 `project.json` 指针和 Manifest 建立边界。只读服务只能读取 Manifest 选中的快照和媒体 ID，不能读取本节中的远端请求、响应、task、poll、quote、签名 URL 或凭据，也不能执行生产动作。

导出不改写或降级视频分辨率；支持范围和历史兼容以 [分辨率合同](video-resolution.md) 为准。

## 凭证变化与旧项目兼容

接入已完成结果和导出继续使用原本地证据，不要求重新认证。新的远端准备与剩余费用授权按[凭证变化续跑](legacy-production.md#身份与旧记录)执行；文件修复只创建私有请求副本，不能改写已提交任务。
