# 旧 WAN 项目素材选择恢复

适用情形：旧版 `import-clip-compilation` 将同一素材另一份本地副本登记为 `pending`，覆盖了此前有效选择。视频现在按[实际请求输入](video-generation.md)校验，**不要求先恢复审核才能继续视频**。恢复用于修正原素材来源、验收记录与就绪展示，不是新生图、新审核或重新编译。

用户要求恢复旧项目时，由 Agent 读取本地权威指针、活动导入记录及历史选择版本，整理下列描述文件。所有路径相对项目根目录；同项目的旧匹配报告、库存和资产表必须来自留存文件，不按修改时间猜最新、不手工拼造通过记录。找不到原证据就报告该项缺口，不猜 SHA、不重复提交 `apply-asset-review`。

```json
{
  "schema_version": 1,
  "import_id": "活动 WAN 导入的完整 ID",
  "source_matching": ".pipeline-state/results/asset-selections/原版本/matching.json",
  "source_inventory": ".pipeline-state/results/asset-selections/原版本/inventory.json",
  "source_assets": ".pipeline-state/results/原资产报告.json",
  "items": [{"asset_id": "CHAR-001-V01", "role": "IMAGE"}]
}
```

`role` 为 `IMAGE` 或 `VOICE`；声音目标用基础角色 ID。一份描述文件使用同一历史版本，最多 500 项；不同历史来源分开处理。

通过 `node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>"` 执行：

1. `recover-imported-asset-selections --input <描述文件> --no-write`：只读核验，返回 `plan_sha256` 和各项 `recoverable / already_restored / conflict`。
2. 已获恢复授权时，用返回的精确摘要执行 `recover-imported-asset-selections --input <描述文件> --expected-plan <plan_sha256>`。不再向用户询问内部摘要。没有摘要、摘要过期或文件并发变化时不写入，重新只读检查。
3. 按 `saved`、各项结果及 `snapshot_refresh.ok` 判断。`restored` 表示已恢复；部分冲突时 `ok=false`，其余有证据的项仍可独立恢复，不笼统称全部成功。刷新失败时原选择已保存，仅 `refresh-ui-snapshot` 或重新检查并幂等恢复，不重生成、不重付费。

Runtime 校验活动导入、不可变导入凭据和映射、同一资产需求、原审核与项目绑定、实际媒体内容及库存。平台生成图还须原操作、候选、最后审核和发布摘要一致。仅替换与旧导入原始 `pending` 行完全一致的当前记录；已拒绝、后来换图、来源不明、需求修订、媒体损坏、基座变化或历史采用链不一致返回逐项冲突。原生变体缺少可核验基座证据时不自动恢复。已原样恢复的记录幂等跳过。

写入前受图片阶段与快照锁保护，备份原项目指针／报告，发布新不可变匹配和库存版本，原子切换指针后刷新并回读。保留原审核 ID、任务、费用、已提交请求和历史视频；不制造新的用户采用确认。只读检查、Compiler 和查询状态均不自动迁移。

恢复前将受影响且当前有效的视频输入保存为私有不可变证据。恢复相同内容的原路径后，已有计划和费用批准继续使用原摘要；每次续跑仍核验当前输入和原副本的实际内容、模板、引用身份、需求与连续性，不修改计划、批准或请求。原副本丢失／损坏或实际输入变化时仍停止。旧版已完成恢复但原视频计划失效时，重新执行同一描述的只读检查及恢复，可依据原导入证据补齐兼容记录；素材仍返回 already_restored，不要求新建生成意图或重新批准同一费用。

向创作者说明：“原来的图片和声音还在，是导入分镜时部分确认记录没有保留下来。新版已避免这个误拦；我会核对并恢复能证明的原记录，再沿用已有分镜继续制作。”不把本地合成测试说成用户项目已经恢复。用户电脑上的旧项目须更新到含此修复的完整 Skill，按升级合同重启智能体后在原项目执行；不要求重建项目。
